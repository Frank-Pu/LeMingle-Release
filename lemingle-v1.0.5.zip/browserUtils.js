// Browser Compatibility Utilities
// Handles differences between Chrome and Edge browsers

/**
 * Detect which browser is running the extension
 * @returns {string} 'chrome' or 'edge'
 */
function detectBrowser() {
  const userAgent = navigator.userAgent.toLowerCase();
  
  // Check if running in Edge
  if (userAgent.includes('edg/') || userAgent.includes('edge/')) {
    return 'edge';
  }
  
  // Default to Chrome (includes Chromium-based browsers)
  return 'chrome';
}

/**
 * Get the extension URL with the correct protocol for the current browser
 * This is critical for OAuth redirects and email confirmation links
 * 
 * Chrome uses: chrome-extension://[extension-id]/path
 * Edge uses: extension://[extension-id]/path
 * 
 * @param {string} path - The path within the extension (e.g., 'auth/login.html')
 * @returns {string} Full extension URL with correct protocol
 */
function getExtensionURL(path) {
  // Get the standard URL from chrome.runtime.getURL
  const url = chrome.runtime.getURL(path);
  
  // Detect browser
  const browser = detectBrowser();
  
  // If Edge, replace chrome-extension:// with extension://
  if (browser === 'edge') {
    return url.replace('chrome-extension://', 'extension://');
  }
  
  // For Chrome and other browsers, return as-is
  return url;
}

/**
 * Get the extension ID
 * @returns {string} Extension ID
 */
function getExtensionId() {
  return chrome.runtime.id;
}

/**
 * Check if current browser is Edge
 * @returns {boolean}
 */
function isEdge() {
  return detectBrowser() === 'edge';
}

/**
 * Check if current browser is Chrome
 * @returns {boolean}
 */
function isChrome() {
  return detectBrowser() === 'chrome';
}

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    detectBrowser,
    getExtensionURL,
    getExtensionId,
    isEdge,
    isChrome
  };
}
