// Lingolette Options Page Script

// Initialize i18n
(async function() {
  await initI18n();
  updateAllTexts();
})();

// Update all UI texts
function updateAllTexts() {
  // Use the standard i18n update function to handle all data-i18n attributes
  updatePageTranslations();
}

// Learning mode & categories
const modeRadios = Array.from(document.querySelectorAll('input[name="mode"]'));
const catCollocation = document.getElementById('cat-collocation');
const catIdiom = document.getElementById('cat-idiom');
const catConnector = document.getElementById('cat-connector');
const prefsStatus = document.getElementById('prefsStatus');

function setModeUI(mode){
  for (const r of modeRadios) r.checked = r.value === (mode || 'standard');
}

chrome.storage.sync.get(['lingolette_mode','lingolette_categories'], (r) => {
  setModeUI(r.lingolette_mode || 'standard');
  const cat = r.lingolette_categories || { collocation: true, idiom: true, connector: true };
  catCollocation.checked = cat.collocation !== false;
  catIdiom.checked = cat.idiom !== false;
  catConnector.checked = cat.connector !== false;
});

document.getElementById('savePrefs').addEventListener('click', () => {
  const mode = (modeRadios.find(r => r.checked) || {}).value || 'standard';
  const categories = {
    collocation: !!catCollocation.checked,
    idiom: !!catIdiom.checked,
    connector: !!catConnector.checked,
  };
  chrome.storage.sync.set({ lingolette_mode: mode, lingolette_categories: categories }, () => {
    prefsStatus.textContent = t('options.savedPrefsSuccess');
    prefsStatus.className = 'hint ok';
    setTimeout(() => prefsStatus.textContent = '', 1200);
    
    // Trigger cloud sync
    chrome.runtime.sendMessage({
      type: 'LINGOLETTE_PROFILE_SYNC',
      payload: { learning_mode: mode, focus_categories: categories }
    }).catch(() => {});
  });
});

// Learner profile controls
const learnerLevel = document.getElementById('learner-level');
const learnerGoal = document.getElementById('learner-goal');
const learnerWeakArea = document.getElementById('learner-weak-area');
const targetLanguage = document.getElementById('target-language');
const explanationLang = document.getElementById('explanation-lang');
const learnerProfileStatus = document.getElementById('learnerProfileStatus');

// Load saved settings
chrome.storage.sync.get([
  'lingolette_learner_level',
  'lingolette_learner_goal',
  'lingolette_learner_weak_area',
  'lingolette_target_language',
  'lingolette_explanation_lang'
], (r) => {
  learnerLevel.value = r.lingolette_learner_level || 'intermediate';
  learnerGoal.value = r.lingolette_learner_goal || 'professional';
  learnerWeakArea.value = r.lingolette_learner_weak_area || 'speaking';
  targetLanguage.value = r.lingolette_target_language || 'en';
  explanationLang.value = r.lingolette_explanation_lang || 'zh-simplified';
});

document.getElementById('saveLearnerProfile').addEventListener('click', () => {
  const profile = {
    learner_level: learnerLevel.value,
    learner_goal: learnerGoal.value,
    learner_weak_area: learnerWeakArea.value,
    target_language: targetLanguage.value,
    explanation_lang: explanationLang.value
  };
  
  chrome.storage.sync.set({
    lingolette_learner_level: profile.learner_level,
    lingolette_learner_goal: profile.learner_goal,
    lingolette_learner_weak_area: profile.learner_weak_area,
    lingolette_target_language: profile.target_language,
    lingolette_explanation_lang: profile.explanation_lang,
  }, () => {
    learnerProfileStatus.textContent = t('options.savedProfileSuccess');
    learnerProfileStatus.className = 'status success';
    setTimeout(() => learnerProfileStatus.textContent = '', 1200);
    
    // Trigger cloud sync
    chrome.runtime.sendMessage({
      type: 'LINGOLETTE_PROFILE_SYNC',
      payload: profile
    }).catch(() => {});
  });
});

// UI Language controls
const uiLanguageRadios = Array.from(document.querySelectorAll('input[name="ui-language"]'));
const uiLanguageStatus = document.getElementById('uiLanguageStatus');

// Load saved UI language
chrome.storage.sync.get(['lingolette_ui_language'], (r) => {
  const savedLang = r.lingolette_ui_language || (navigator.language.startsWith('zh') ? 'zh-CN' : 'en');
  for (const radio of uiLanguageRadios) {
    radio.checked = radio.value === savedLang;
  }
});

document.getElementById('saveUILanguage').addEventListener('click', () => {
  const selectedLang = (uiLanguageRadios.find(r => r.checked) || {}).value || 'zh-CN';
  
  chrome.storage.sync.set({ lingolette_ui_language: selectedLang }, () => {
    uiLanguageStatus.textContent = t('options.saved');
    uiLanguageStatus.className = 'status success';
    
    // Reload page to apply new language
    setTimeout(() => {
      window.location.reload();
    }, 500);
  });
});

// ============================================
// Flashcard Review Module
// ============================================

let allPhrases = [];
let filteredPhrases = [];
let currentIndex = 0;
let isFlipped = false;

// Navigation
const navItems = document.querySelectorAll('.nav-item');
const sections = {
  'section-general': document.getElementById('section-general'),
  'section-profile': document.getElementById('section-profile'),
  'section-flashcards': document.getElementById('section-flashcards'),
  'section-about': document.getElementById('section-about')
};

navItems.forEach(item => {
  item.addEventListener('click', (e) => {
    e.preventDefault();
    const targetId = item.getAttribute('href').substring(1);
    navigateToSection(targetId);
  });
});

// Navigate to a specific section
function navigateToSection(targetId) {
  // Update active nav
  navItems.forEach(n => {
    const navTarget = n.getAttribute('href').substring(1);
    if (navTarget === targetId) {
      n.classList.add('active');
    } else {
      n.classList.remove('active');
    }
  });
  
  // Show target section
  Object.keys(sections).forEach(key => {
    if (sections[key]) {
      sections[key].style.display = key === targetId ? 'flex' : 'none';
    }
  });
  
  // Load flashcards if entering flashcard section
  if (targetId === 'section-flashcards') {
    loadFlashcards();
  }
}

// Handle hash navigation on page load
window.addEventListener('DOMContentLoaded', () => {
  const hash = window.location.hash.substring(1); // Remove #
  if (hash && sections[hash]) {
    navigateToSection(hash);
  }
});

// Handle hash changes (when user uses browser back/forward)
window.addEventListener('hashchange', () => {
  const hash = window.location.hash.substring(1);
  if (hash && sections[hash]) {
    navigateToSection(hash);
  }
});

// Load flashcards from storage and cloud
async function loadFlashcards() {
  try {
    // First load from local storage
    const result = await chrome.storage.local.get(['lingolette_items']);
    allPhrases = result.lingolette_items || [];
    
    // Initialize review status for items that don't have it
    allPhrases = allPhrases.map(item => ({
      ...item,
      reviewStatus: item.reviewStatus || 'not_reviewed',
      isStarred: item.isStarred || false,
      lastReviewedAt: item.lastReviewedAt || null,
      reviewCount: item.reviewCount || 0
    }));
    
    // Try to sync from cloud
    await syncFromCloud();
    
    applyFiltersAndSort();
    updateStats();
    renderCurrentCard();
  } catch (error) {
    console.error('[Flashcards] Error loading phrases:', error);
  }
}

// Sync collected items from Supabase cloud
async function syncFromCloud() {
  try {
    // Check if user is logged in
    const localData = await chrome.storage.local.get(['lingolette_user_session']);
    const session = localData.lingolette_user_session;
    
    if (!session || !session.access_token) {
      return;
    }
    
    // Fetch items from Supabase
    const resp = await fetch('https://ebyavvysuogymwktidlx.supabase.co/rest/v1/saved_items?select=*&order=created_at.desc', {
      headers: {
        'Authorization': `Bearer ${session.access_token}`,
        'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVieWF2dnlzdW9neW13a3RpZGx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwMjYzMTUsImV4cCI6MjA3NTYwMjMxNX0.W7stnpPBlPxHy3RH7aWA0DSo7iI7lzsgY-i5tKWHyIw',
        'Content-Type': 'application/json'
      }
    });
    
    if (!resp.ok) {
      console.error('[Flashcards] Failed to fetch from cloud:', resp.status);
      return;
    }
    
    const cloudItems = await resp.json();
    
    // Merge cloud items with local items
    const localMap = new Map(allPhrases.map(item => [item.cloudId || item.text, item]));
    
    cloudItems.forEach(cloudItem => {
      const localItem = localMap.get(cloudItem.id);
      
      if (localItem) {
        // Update local item with cloud data
        localItem.reviewStatus = cloudItem.review_status || 'not_reviewed';
        localItem.isStarred = cloudItem.is_starred || false;
        localItem.lastReviewedAt = cloudItem.last_reviewed_at ? new Date(cloudItem.last_reviewed_at).getTime() : null;
        localItem.reviewCount = cloudItem.review_count || 0;
      } else {
        // Add new item from cloud
        allPhrases.push({
          text: cloudItem.text,
          meaning: cloudItem.meaning,
          type: cloudItem.type,
          url: cloudItem.url,
          title: cloudItem.title,
          ts: new Date(cloudItem.created_at).getTime(),
          cloudId: cloudItem.id,
          reviewStatus: cloudItem.review_status || 'not_reviewed',
          isStarred: cloudItem.is_starred || false,
          lastReviewedAt: cloudItem.last_reviewed_at ? new Date(cloudItem.last_reviewed_at).getTime() : null,
          reviewCount: cloudItem.review_count || 0
        });
      }
    });
    
    // Save merged data back to local storage
    await chrome.storage.local.set({ lingolette_items: allPhrases });
    
  } catch (error) {
    console.error('[Flashcards] Cloud sync error:', error);
  }
}

// Apply filters and sorting
function applyFiltersAndSort() {
  const filterValue = document.getElementById('filterSelect').value;
  const sortValue = document.getElementById('sortSelect').value;
  
  // Filter
  filteredPhrases = allPhrases.filter(item => {
    if (filterValue === 'all') return true;
    if (filterValue === 'starred') return item.isStarred;
    return item.reviewStatus === filterValue;
  });
  
  // Sort
  if (sortValue === 'newest') {
    filteredPhrases.sort((a, b) => (b.ts || 0) - (a.ts || 0));
  } else if (sortValue === 'random') {
    filteredPhrases.sort(() => Math.random() - 0.5);
  } else if (sortValue === 'type') {
    filteredPhrases.sort((a, b) => (a.type || '').localeCompare(b.type || ''));
  }
  
  currentIndex = 0;
  isFlipped = false;
}

// Update statistics
function updateStats() {
  const today = new Date().toDateString();
  const todayReviewed = allPhrases.filter(item => {
    if (!item.lastReviewedAt) return false;
    return new Date(item.lastReviewedAt).toDateString() === today;
  }).length;
  
  const mastered = allPhrases.filter(item => item.reviewStatus === 'mastered').length;
  const masteredRate = allPhrases.length > 0 ? Math.round((mastered / allPhrases.length) * 100) : 0;
  
  document.getElementById('todayCount').textContent = todayReviewed;
  document.getElementById('todayTotal').textContent = allPhrases.length;
  document.getElementById('totalCount').textContent = allPhrases.length;
  document.getElementById('masteredRate').textContent = masteredRate + '%';
  document.getElementById('progressFill').style.width = masteredRate + '%';
  
  // Update export counts
  const notReviewed = allPhrases.filter(item => item.reviewStatus === 'not_reviewed').length;
  const starred = allPhrases.filter(item => item.isStarred).length;
  
  document.getElementById('exportCountAll').textContent = `(${allPhrases.length}个)`;
  document.getElementById('exportCountNotReviewed').textContent = `(${notReviewed}个)`;
  document.getElementById('exportCountStarred').textContent = `(${starred}个)`;
}

// Render current card
function renderCurrentCard() {
  const flashcardEmpty = document.getElementById('flashcardEmpty');
  const flashcardContainer = document.getElementById('flashcardContainer');
  const flashcard = document.getElementById('flashcard');
  
  if (filteredPhrases.length === 0) {
    flashcardEmpty.style.display = 'flex';
    flashcardContainer.style.display = 'none';
    return;
  }
  
  flashcardEmpty.style.display = 'none';
  flashcardContainer.style.display = 'flex';
  
  const item = filteredPhrases[currentIndex];
  
  // Update card content
  document.getElementById('cardPhrase').textContent = item.text;
  document.getElementById('cardPhraseBack').textContent = item.text;
  document.getElementById('cardMeaning').textContent = item.meaning || 'No meaning available';
  document.getElementById('cardType').textContent = getTypeLabel(item.type);
  
  const urlElement = document.getElementById('cardUrl');
  if (item.url) {
    const domain = new URL(item.url).hostname.replace('www.', '');
    urlElement.textContent = domain;
    urlElement.title = item.url;
  } else {
    urlElement.textContent = '';
  }
  
  // Update counter
  document.getElementById('currentIndex').textContent = currentIndex + 1;
  document.getElementById('totalCards').textContent = filteredPhrases.length;
  
  // Update star button
  const starBtn = document.getElementById('starBtn');
  if (item.isStarred) {
    starBtn.classList.add('starred');
  } else {
    starBtn.classList.remove('starred');
  }
  
  // Reset flip state
  flashcard.classList.remove('flipped');
  isFlipped = false;
}

function getTypeLabel(type) {
  const labels = {
    'collocation': '🔗 词组搭配',
    'idiom': '💬 习语俚语',
    'connector': '🔄 逻辑连接',
    'other': '📝 其他'
  };
  return labels[type] || labels['other'];
}

// Card flip
document.getElementById('flashcard').addEventListener('click', () => {
  const flashcard = document.getElementById('flashcard');
  isFlipped = !isFlipped;
  if (isFlipped) {
    flashcard.classList.add('flipped');
  } else {
    flashcard.classList.remove('flipped');
  }
});

// Navigation controls
document.getElementById('prevBtn').addEventListener('click', (e) => {
  e.stopPropagation();
  if (currentIndex > 0) {
    currentIndex--;
    renderCurrentCard();
  }
});

document.getElementById('nextBtn').addEventListener('click', (e) => {
  e.stopPropagation();
  if (currentIndex < filteredPhrases.length - 1) {
    currentIndex++;
    renderCurrentCard();
  }
});

// Speak button
document.getElementById('speakBtn').addEventListener('click', async (e) => {
  e.stopPropagation();
  if (filteredPhrases.length === 0) return;
  
  const item = filteredPhrases[currentIndex];
  await speakPhrase(item.text, item.meaning);
});

// Language codes for TTS
const LANGUAGE_CODES = {
  'en': 'en-US',
  'fr': 'fr-FR',
  'es': 'es-ES',
  'de': 'de-DE',
  'ko': 'ko-KR',
  'ja': 'ja-JP',
  'zh-simplified': 'zh-CN',
  'zh-traditional': 'zh-TW',
  'ru': 'ru-RU'
};

function detectTextLanguage(text) {
  if (!text) return 'en';
  const chineseCount = (text.match(/[\u4e00-\u9fa5]/g) || []).length;
  const englishCount = (text.match(/[a-zA-Z]/g) || []).length;
  
  if (chineseCount > englishCount * 0.3) return 'zh-CN';
  if (text.match(/[àâäéèêëïîôùûüÿç]/i)) return 'fr';
  if (text.match(/[áéíóúñ]/i)) return 'es';
  if (text.match(/[äöüß]/i)) return 'de';
  
  return 'en';
}

async function speakPhrase(text, meaning = null) {
  if (!('speechSynthesis' in window)) return;
  
  try {
    const settings = await new Promise(resolve => {
      chrome.storage.sync.get([
        'lingolette_target_language',
        'lingolette_explanation_lang'
      ], resolve);
    });
    
    const targetLang = settings.lingolette_target_language || 'en';
    const explanationLang = settings.lingolette_explanation_lang || 'zh-simplified';
    const textLang = detectTextLanguage(text);
    
    // 标准化语言代码（去除地区后缀）
    const normalizeLang = (l) => l.split('-')[0].toLowerCase();
    const normalizedTextLang = normalizeLang(textLang);
    const normalizedTargetLang = normalizeLang(targetLang);
    const normalizedExplanationLang = normalizeLang(explanationLang);
    
    // 通用学习模式判断
    let learningMode;
    if (normalizedTextLang === normalizedTargetLang) {
      learningMode = 'forward'; // 正向学习
    } else if (normalizedTextLang === normalizedExplanationLang) {
      learningMode = 'reverse'; // 反向学习
    } else {
      learningMode = 'fallback'; // 兜底
    }
    
    const isForwardLearning = learningMode === 'forward' || learningMode === 'fallback';
    
    let textToSpeak;
    if (isForwardLearning) {
      textToSpeak = text;
    } else {
      textToSpeak = meaning || text;
    }
    
    // 兼容所有语言代码格式
    const langCode = LANGUAGE_CODES[targetLang] || LANGUAGE_CODES[normalizeLang(targetLang)] || 'en-US';
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.lang = langCode;
    utterance.rate = 0.9;
    
    const voices = speechSynthesis.getVoices();
    const preferredVoice = voices.find(voice => 
      voice.lang.startsWith(langCode.split('-')[0]) && voice.localService
    ) || voices.find(voice => 
      voice.lang.startsWith(langCode.split('-')[0])
    );
    
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }
    
    speechSynthesis.speak(utterance);
  } catch (e) {
    console.error('[Flashcards] Speech synthesis error:', e);
  }
}

// Review status buttons
document.getElementById('familiarBtn').addEventListener('click', async (e) => {
  e.stopPropagation();
  await updateReviewStatus('familiar');
});

document.getElementById('masteredBtn').addEventListener('click', async (e) => {
  e.stopPropagation();
  await updateReviewStatus('mastered');
});

document.getElementById('starBtn').addEventListener('click', async (e) => {
  e.stopPropagation();
  await toggleStar();
});

async function updateReviewStatus(status) {
  if (filteredPhrases.length === 0) return;
  
  const item = filteredPhrases[currentIndex];
  item.reviewStatus = status;
  item.lastReviewedAt = Date.now();
  item.reviewCount = (item.reviewCount || 0) + 1;
  
  // Update in allPhrases
  const index = allPhrases.findIndex(p => p.text === item.text && p.ts === item.ts);
  if (index !== -1) {
    allPhrases[index] = item;
  }
  
  // Save to storage
  await chrome.storage.local.set({ lingolette_items: allPhrases });
  
  // Sync to cloud
  syncReviewStatusToCloud(item);
  
  // Update stats
  updateStats();
  
  // Move to next card
  if (currentIndex < filteredPhrases.length - 1) {
    currentIndex++;
    renderCurrentCard();
  }
}

async function toggleStar() {
  if (filteredPhrases.length === 0) return;
  
  const item = filteredPhrases[currentIndex];
  item.isStarred = !item.isStarred;
  
  // Update in allPhrases
  const index = allPhrases.findIndex(p => p.text === item.text && p.ts === item.ts);
  if (index !== -1) {
    allPhrases[index] = item;
  }
  
  // Save to storage
  await chrome.storage.local.set({ lingolette_items: allPhrases });
  
  // Sync to cloud
  syncReviewStatusToCloud(item);
  
  // Update UI with animation
  const starBtn = document.getElementById('starBtn');
  
  // Add animation class
  starBtn.classList.add('animating');
  
  if (item.isStarred) {
    starBtn.classList.add('starred');
  } else {
    starBtn.classList.remove('starred');
  }
  
  // Remove animation class after animation completes
  setTimeout(() => {
    starBtn.classList.remove('animating');
  }, 400);
  
  updateStats();
}

// ============================================
// Batch Sync for Review Status
// ============================================

// Sync queue and timer
const reviewSyncQueue = new Map(); // cloudId -> item data
let reviewSyncTimer = null;
let isSyncing = false;

const SYNC_CONFIG = {
  batchSize: 8,        // 队列达到 5 条时立即同步
  debounceTime: 5000,  // 5 秒防抖
  maxRetries: 2        // 最多重试 2 次
};

// Add item to sync queue (debounced)
function syncReviewStatusToCloud(item) {
  if (!item.cloudId) return;
  
  // Add/update item in queue (newer updates override older ones)
  reviewSyncQueue.set(item.cloudId, {
    cloudId: item.cloudId,
    reviewStatus: item.reviewStatus,
    isStarred: item.isStarred,
    lastReviewedAt: item.lastReviewedAt,
    reviewCount: item.reviewCount
  });
  
  
  // Check if we should sync immediately
  if (reviewSyncQueue.size >= SYNC_CONFIG.batchSize) {
    flushReviewSyncQueue();
  } else {
    // Schedule debounced sync
    scheduleReviewSync();
  }
}

// Schedule sync with debouncing
function scheduleReviewSync() {
  if (reviewSyncTimer) {
    clearTimeout(reviewSyncTimer);
  }
  
  reviewSyncTimer = setTimeout(() => {
    flushReviewSyncQueue();
  }, SYNC_CONFIG.debounceTime);
}

// Flush sync queue (batch update)
async function flushReviewSyncQueue() {
  if (isSyncing || reviewSyncQueue.size === 0) {
    return;
  }
  
  isSyncing = true;
  
  // Clear timer
  if (reviewSyncTimer) {
    clearTimeout(reviewSyncTimer);
    reviewSyncTimer = null;
  }
  
  // Get all items from queue
  const itemsToSync = Array.from(reviewSyncQueue.values());
  
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'LINGOLETTE_BATCH_UPDATE_REVIEW_STATUS',
      payload: { items: itemsToSync }
    });
    
    if (response?.ok) {
      // Clear synced items from queue
      itemsToSync.forEach(item => reviewSyncQueue.delete(item.cloudId));
    } else {
      console.error('[Flashcards] ❌ Batch sync failed:', response?.error);
    }
  } catch (error) {
    console.error('[Flashcards] ❌ Batch sync error:', error);
  } finally {
    isSyncing = false;
    
    // If there are still items in queue (new ones added during sync), schedule another sync
    if (reviewSyncQueue.size > 0) {
      scheduleReviewSync();
    }
  }
}

// Force sync on page unload
window.addEventListener('beforeunload', () => {
  if (reviewSyncQueue.size > 0) {
    // Use synchronous approach for beforeunload
    navigator.sendBeacon(
      'https://ebyavvysuogymwktidlx.supabase.co/rest/v1/rpc/batch_update_review_status',
      JSON.stringify({ items: Array.from(reviewSyncQueue.values()) })
    );
  }
});

// Visibility change handler (sync when user switches tabs)
document.addEventListener('visibilitychange', () => {
  if (document.hidden && reviewSyncQueue.size > 0) {
    flushReviewSyncQueue();
  }
});

// Filter and sort listeners
document.getElementById('filterSelect').addEventListener('change', () => {
  applyFiltersAndSort();
  renderCurrentCard();
});

document.getElementById('sortSelect').addEventListener('change', () => {
  applyFiltersAndSort();
  renderCurrentCard();
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
  // Only handle shortcuts when flashcard section is visible
  if (sections['section-flashcards'].style.display !== 'flex') return;
  if (filteredPhrases.length === 0) return;
  
  switch(e.key) {
    case ' ':
      e.preventDefault();
      document.getElementById('flashcard').click();
      break;
    case 'ArrowLeft':
      e.preventDefault();
      document.getElementById('prevBtn').click();
      break;
    case 'ArrowRight':
      e.preventDefault();
      document.getElementById('nextBtn').click();
      break;
    case 's':
    case 'S':
      e.preventDefault();
      document.getElementById('speakBtn').click();
      break;
    case '1':
      e.preventDefault();
      document.getElementById('familiarBtn').click();
      break;
    case '2':
      e.preventDefault();
      document.getElementById('masteredBtn').click();
      break;
    case '3':
      e.preventDefault();
      document.getElementById('starBtn').click();
      break;
  }
});

// Export functionality
document.getElementById('exportBtn').addEventListener('click', () => {
  document.getElementById('exportModal').style.display = 'block';
  document.getElementById('exportModalBackdrop').style.display = 'block';
});

document.getElementById('cancelExportBtn').addEventListener('click', () => {
  document.getElementById('exportModal').style.display = 'none';
  document.getElementById('exportModalBackdrop').style.display = 'none';
});

document.getElementById('exportModalBackdrop').addEventListener('click', () => {
  document.getElementById('exportModal').style.display = 'none';
  document.getElementById('exportModalBackdrop').style.display = 'none';
});

document.getElementById('confirmExportBtn').addEventListener('click', () => {
  const format = document.querySelector('input[name="export-format"]:checked').value;
  const range = document.querySelector('input[name="export-range"]:checked').value;
  
  let itemsToExport = [];
  if (range === 'all') {
    itemsToExport = allPhrases;
  } else if (range === 'not_reviewed') {
    itemsToExport = allPhrases.filter(item => item.reviewStatus === 'not_reviewed');
  } else if (range === 'starred') {
    itemsToExport = allPhrases.filter(item => item.isStarred);
  }
  
  if (format === 'excel') {
    exportToExcel(itemsToExport);
  } else if (format === 'anki') {
    exportToAnki(itemsToExport);
  }
  
  // Close modal
  document.getElementById('exportModal').style.display = 'none';
  document.getElementById('exportModalBackdrop').style.display = 'none';
});

function exportToExcel(items) {
  // Create CSV format (Excel compatible)
  const headers = ['短语', '释义', '类型', '来源', '收藏时间', '复习状态', '是否标记'];
  const rows = items.map(item => [
    item.text,
    item.meaning || '',
    getTypeLabel(item.type),
    item.url || '',
    item.ts ? new Date(item.ts).toLocaleString('zh-CN') : '',
    item.reviewStatus === 'mastered' ? '已掌握' : item.reviewStatus === 'familiar' ? '不熟悉' : '未复习',
    item.isStarred ? '⭐' : ''
  ]);
  
  const csvContent = [headers, ...rows]
    .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    .join('\n');
  
  // Add BOM for Excel UTF-8 support
  const BOM = '\uFEFF';
  const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `lemingle_phrases_${new Date().toISOString().split('T')[0]}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

function exportToAnki(items) {
  // Anki import format: front\tback\ttags
  const ankiContent = items.map(item => {
    const front = item.text;
    const back = `${item.meaning || ''}<br><br>📝 ${getTypeLabel(item.type)}<br>🔗 ${item.url || ''}`;
    const tags = ['LeMingle', item.type, item.isStarred ? 'starred' : ''].filter(Boolean).join(' ');
    return `${front}\t${back}\t${tags}`;
  }).join('\n');
  
  const blob = new Blob([ankiContent], { type: 'text/plain;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `lemingle_anki_${new Date().toISOString().split('T')[0]}.txt`;
  link.click();
  URL.revokeObjectURL(url);
}
