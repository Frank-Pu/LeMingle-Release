// Lingolette Content Script
// Implements: intelligent highlighting, hover tooltip (meaning, TTS, example),
// selection mini-button, save to local collection.

(function () {
  const HIGHLIGHT_CLASS = 'lingolette-highlight';
  const COLLECTION_HIGHLIGHT_CLASS = 'lingolette-collection-highlight';
  const TOOLTIP_CLASS = 'lingolette-tooltip';
  const SELECT_FAB_CLASS = 'lingolette-select-fab';
  
  // UI Language
  let UI_LANG = 'zh-CN';
  
  // Scroll listener reference for cleanup
  let scrollListener = null;
  
  // Initial highlight timer reference for cleanup
  let initialHighlightTimer = null;
  
  // Error notification throttle (prevent spam)
  let lastErrorNotification = {
    NOT_LOGGED_IN: 0,
    MONTHLY_QUOTA_EXCEEDED: 0,
    QUOTA_EXCEEDED: 0,  // API returns QUOTA_EXCEEDED
    NETWORK_ERROR: 0,
    AI_HIGHLIGHT_FAILED: 0
  };
  const ERROR_NOTIFICATION_COOLDOWN = 60 * 60 * 1000; // 1 hour
  
  // Simple i18n for content script
  const i18nTexts = {
    'zh-CN': {
      translating: '翻译中... ⏳',
      addToCollection: '⭐ 收藏',
      removeFromCollection: '🗑️ 取消收藏',
      addToCollectionTitle: '收藏到列表',
      removeFromCollectionTitle: '从收藏夹中移除',
      saving: '收藏中...',
      removing: '移除中...',
      aiHighlighting: 'AI 高亮中...',
      aiHighlightDisabled: '此网站已关闭 AI 高亮',
      aiFeatureDisabled: 'AI 高亮功能已关闭',
      siteNotSuitable: '此网站不适合 AI 高亮',
      aiHighlightComplete: 'AI 高亮完成',
      found: '找到',
      expressions: '个表达',
      // Error messages
      notLoggedIn: '❌ 您尚未登录，请先登录以使用 AI 高亮功能',
      quotaExceeded: '❌ 本月 AI 配额已用完，请升级套餐或等待下月重置',
      noExpressionsFound: '未找到需要高亮的表达',
      aiHighlightFailed: '❌ AI 高亮失败，请稍后重试',
      networkError: '❌ 网络连接失败，请检查网络',
      // Short messages for throttled notifications
      pleaseLogin: '请先登录',
      pleaseUpgrade: '请升级套餐',
      // Celebration message
      dailyGoalAchieved: '🎉 太棒！今日已收藏 5 个表达',
      keepLearning: '继续加油！',
    },
    'en': {
      translating: 'Translating... ⏳',
      addToCollection: '⭐ Save',
      removeFromCollection: '🗑️ Unsave',
      addToCollectionTitle: 'Save to collection',
      removeFromCollectionTitle: 'Remove from collection',
      saving: 'Saving...',
      removing: 'Removing...',
      aiHighlighting: 'AI Highlighting...',
      aiHighlightDisabled: 'AI highlighting disabled for this site',
      aiFeatureDisabled: 'AI highlighting feature is off',
      siteNotSuitable: 'This site is not suitable for AI highlighting',
      aiHighlightComplete: 'AI Highlighting Complete',
      found: 'Found',
      expressions: 'expressions',
      // Error messages
      notLoggedIn: '❌ Please login to use AI highlighting',
      quotaExceeded: '❌ Monthly AI quota exceeded. Please upgrade or wait for reset.',
      noExpressionsFound: 'No expressions found to highlight',
      aiHighlightFailed: '❌ AI highlighting failed, please try again',
      networkError: '❌ Network error, please check your connection',
      // Short messages for throttled notifications
      pleaseLogin: 'Please login',
      pleaseUpgrade: 'Please upgrade',
      // Celebration message
      dailyGoalAchieved: '🎉 Awesome! You\'ve saved 5 expressions today',
      keepLearning: 'Keep it up!',
    }
  };
  
  function t(key) {
    return i18nTexts[UI_LANG]?.[key] || i18nTexts['en']?.[key] || key;
  }
  
  // Get UI language from storage
  chrome.storage.sync.get(['lingolette_ui_language'], (r) => {
    if (r.lingolette_ui_language) {
      UI_LANG = r.lingolette_ui_language;
    } else {
      UI_LANG = navigator.language.startsWith('zh') ? 'zh-CN' : 'en';
    }
  });
  
  // Hover state to keep tooltip visible while moving cursor
  const hoverState = {
    overSpan: false,
    overTooltip: false,
    hideTimer: null,
    pinned: false,
  };
  // Settings state (synced from options)
  let SETTINGS = {
    mode: 'standard', // 'lite' | 'standard' | 'detailed'
    categories: { collocation: true, idiom: true, connector: true },
    ai: { enabled: false, provider: 'volcengine', language: 'en' },
    collectionHighlight: true, // Enable collection highlighting by default
    targetLanguage: 'en', // 用户学习的目标语言（单一语言）
  };
  
  // Site-specific preferences
  let SITE_PREFERENCES = {}; // { 'domain.com': 'always_on' | 'always_off' | 'auto' }
  // Collection items cache
  let COLLECTION_ITEMS = [];
  let COLLECTION_PHRASES_SET = new Set(); // For fast lookup

  // Data Access Layer - for future cloud sync compatibility
  async function getCollectionItems() {
    // Currently from local storage, will support cloud sync in future
    return new Promise((resolve) => {
      chrome.storage.local.get(['lingolette_items'], (res) => {
        resolve(res.lingolette_items || []);
      });
    });
  }
  
  async function loadCollectionItems() {
    try {
      COLLECTION_ITEMS = await getCollectionItems();
      COLLECTION_PHRASES_SET = new Set(
        COLLECTION_ITEMS.map(item => (item.phrase || item.text)?.toLowerCase()).filter(Boolean)
      );
    } catch (e) {
      console.error('[LeMingle] Failed to load collection items:', e);
    }
  }

  function loadSettings() {
    return new Promise((resolve) => {
      try {
        chrome.storage?.sync.get([
          'lingolette_mode','lingolette_categories','lingolette_ai_enabled',
          'lingolette_ai_provider','lingolette_ai_language','lingolette_site_preferences',
          'lingolette_collection_highlight','lingolette_target_language'
        ], (r) => {
          SETTINGS.mode = r.lingolette_mode || 'standard';
          const cat = r.lingolette_categories;
          SETTINGS.categories = {
            collocation: cat?.collocation !== false,
            idiom: cat?.idiom !== false,
            connector: cat?.connector !== false,
          };
          SETTINGS.ai = {
            enabled: r.lingolette_ai_enabled !== false, // 默认开启
            provider: r.lingolette_ai_provider || 'volcengine',
            language: r.lingolette_ai_language || 'en',
          };
          SETTINGS.collectionHighlight = r.lingolette_collection_highlight !== false;
          SETTINGS.targetLanguage = r.lingolette_target_language || 'en';
          SITE_PREFERENCES = r.lingolette_site_preferences || {};
          
          resolve();
        });
        chrome.storage?.onChanged.addListener((changes, area) => {
          if (area !== 'sync') return;
          if (changes.lingolette_mode) SETTINGS.mode = changes.lingolette_mode.newValue || 'standard';
          if (changes.lingolette_categories) {
            const cat = changes.lingolette_categories.newValue || {};
            SETTINGS.categories = {
              collocation: cat.collocation !== false,
              idiom: cat.idiom !== false,
              connector: cat.connector !== false,
            };
          }
          if (changes.lingolette_ai_enabled) {
            SETTINGS.ai.enabled = changes.lingolette_ai_enabled.newValue !== false;
          }
          if (changes.lingolette_ai_provider) SETTINGS.ai.provider = changes.lingolette_ai_provider.newValue || 'volcengine';
          if (changes.lingolette_ai_language) SETTINGS.ai.language = changes.lingolette_ai_language.newValue || 'en';
          if (changes.lingolette_target_language) SETTINGS.targetLanguage = changes.lingolette_target_language.newValue || 'en';
          if (changes.lingolette_site_preferences) {
            SITE_PREFERENCES = changes.lingolette_site_preferences.newValue || {};
            
            // Re-check if current site should enable/disable highlighting
            const domain = location.hostname;
            const pref = SITE_PREFERENCES[domain];
            
            // If site was explicitly turned off, remove highlights
            if (pref === 'always_off') {
              document.querySelectorAll(`.${HIGHLIGHT_CLASS}`).forEach(span => {
                const text = span.textContent;
                span.replaceWith(document.createTextNode(text));
              });
              AI_BUSY = false;
              
              // Clear all timers
              if (DWELL_TIMER) {
                clearTimeout(DWELL_TIMER);
                DWELL_TIMER = null;
              }
              if (initialHighlightTimer) {
                clearTimeout(initialHighlightTimer);
                initialHighlightTimer = null;
              }
              
              // Remove scroll listener to prevent further highlighting
              if (scrollListener) {
                window.removeEventListener('scroll', scrollListener);
                scrollListener = null;
              }
            }
            // If site was explicitly turned on and AI is enabled, reload to apply highlights
            else if (pref === 'always_on' && SETTINGS.ai.enabled) {
              location.reload();
            }
          }
        });
      } catch (e) {
        console.error('[LeMingle] Failed to load settings:', e);
        resolve();
      }
    });
  }

  // Content detection: determine if page is suitable for learning
  function isReadableContent() {
    // 优先检查语义化标签
    let container = document.querySelector('article, main, [role="main"]');
    
    // 如果没有，尝试其他常见容器
    if (!container) {
      container = document.querySelector('.content, .main-content, #content, #main-content, .article, .post, .container');
    }
    
    // Kaggle 特定：检查 Kaggle 的内容容器
    if (!container && location.hostname.includes('kaggle.com')) {
      container = document.querySelector('[data-testid="notebook-container"], .notebook-container, #site-content, .main-panel');
    }
    
    // Reddit 特定：检查 Reddit 的内容容器
    if (!container && location.hostname.includes('reddit.com')) {
      container = document.querySelector('[data-testid="post-container"], shreddit-post, .Post');
    }
    
    // 最后备选：使用 body
    if (!container) {
      container = document.body;
    }
    
    if (!container) return false;
    
    const textLength = container.innerText?.length || 0;
    const paragraphs = container.querySelectorAll('p').length;
    
    // 降低阈值：>300 字符 或 >2 个段落（更宽松，使用 OR）
    return textLength > 300 || paragraphs > 2;
  }

  // Check if current site should enable highlighting
  function shouldEnableHighlighting() {
    
    if (!SETTINGS.ai.enabled) {
      return false;
    }
    
    const domain = location.hostname;
    const pref = SITE_PREFERENCES[domain];
    
    
    // User preference overrides
    if (pref === 'always_on') {
      return true;
    }
    if (pref === 'always_off') {
      return false;
    }
    
    // Blacklist: known non-learning sites
    const blacklist = [
      'google.com', 'google.co.uk', 'google.ca',
      'youtube.com', 'youtu.be',
      'amazon.com', 'amazon.co.uk', 'instagram.com'// code, not prose
    ];
    
    if (blacklist.some(site => domain.includes(site))) {
      return false;
    }
    
    // Auto-detect: check if content is readable
    const isReadable = isReadableContent();
    return isReadable;
  }

  // Simple lists for MVP categorization
  const CONNECTORS = new Set([
    'in short','in other words','for instance','for example','that said','as a result','in contrast','by contrast','to be clear','on the other hand','as a matter of fact','in addition','moreover','furthermore','to sum up','in summary','in conclusion','from my perspective','from our perspective','in practice','in theory','at the end of the day','all things considered',
    'to put it simply','to be fair','to be honest','to be frank','first and foremost','last but not least','on balance','to a large extent','for the sake of','with that in mind'
  ]);
  const IDIOMS = new Set([
    'rule of thumb','back to square one','a piece of cake','hit the nail on the head','on the same page','think outside the box','cut to the chase','move the needle','in the loop','touch base','ballpark figure','no brainer',
    'raise the bar','hit the ground running','call it a day','make ends meet','break the ice','by the book','on the fly','game changer','silver bullet','low hanging fruit'
  ]);

  // Common phrasal verbs and collocations (exact phrase lookup)
  const COMMON_COLLOCATIONS = new Set([
    'take action','take actions','make a decision','make decisions','make progress','set goals','raise concerns','reach agreement','reach a consensus','pay attention','pay close attention','give a presentation','have a look','have an impact','hold a meeting','set expectations','meet expectations','meet the deadline','take responsibility','gain insights','draw conclusions','address issues','solve problems','seek feedback','build trust','create value','drive growth','reduce costs','increase efficiency'
  ]);
  const PHRASAL_VERBS = new Set([
    'figure out','work out','point out','come up with','end up','set up','look into','look forward to','move on','carry on','get back to','reach out','come across','follow up','take over','go over','bring up','pick up','turn out','roll out'
  ]);

  // Heuristic: collocation detector via regex patterns (verb+noun, adj+noun common patterns)
  const collocationRegexes = [
    /\b(make|take|have|give|set|raise|hold|reach|pay)\s+(a|an|the)?\s*[a-zA-Z]+\b/gi,
    /\b(strong|significant|considerable|substantial|tangible)\s+[a-zA-Z]+\b/gi,
    /\b(highly|widely|closely|strongly|deeply)\s+[a-zA-Z]+\b/gi
  ];

  // Avoid nodes
  const AVOID_TAGS = new Set(['CODE','PRE','NAV','HEADER','FOOTER','ASIDE','SCRIPT','STYLE','TEXTAREA','INPUT','BUTTON','SVG']);

  // Utility: walk text nodes in main content
  function textNodesUnder(el) {
    const walk = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null, false);
    const nodes = [];
    let skipped = { tooShort: 0, noParent: 0, skipTag: 0, skipClass: 0, skipPattern: 0, hidden: 0 };
    let n;
    while (n = walk.nextNode()) {
      const text = n.nodeValue.trim();
      if (text.length < 30 || !/[a-zA-Z]/.test(text)) {
        if (text.length > 0) skipped.tooShort++;
        continue;
      }
      
      // Skip non-content elements
      const parent = n.parentElement;
      if (!parent) continue;
      
      // 优化：跳过不可见元素（折叠的 FAQ、隐藏内容等）
      const style = window.getComputedStyle(parent);
      if (style.display === 'none' || 
          style.visibility === 'hidden' || 
          style.opacity === '0' ||
          parent.offsetWidth === 0 || 
          parent.offsetHeight === 0) {
        skipped.hidden++;
        continue;
      }
      
      const tagName = parent.tagName.toLowerCase();
      // 优化：移除 'a' 和标题标签，允许评论区链接和格式化文本
      const skipTags = ['title', 'nav', 'header', 'footer', 'aside', 'button', 'script', 'style', 'code', 'pre'];
      if (skipTags.includes(tagName)) {
        skipped.skipTag++;
        continue;
      }
      
      // Additional check: skip if parent has contenteditable or is input-like
      if (parent.isContentEditable || parent.tagName === 'TEXTAREA' || parent.tagName === 'INPUT') {
        skipped.skipClass++;
        continue;
      }
      
      // 优化：更精确的过滤模式，避免误杀评论区
      const className = parent.className || '';
      const id = parent.id || '';
      const combinedStr = (className + ' ' + id).toLowerCase();
      
      // 只跳过明确的非内容区域，保留评论区
      const skipPatterns = [
        /^(nav|navigation|menu|sidebar|breadcrumb)$/i,  // 精确匹配导航元素
        /\b(advertisement|ad-container|sponsored)\b/i,   // 广告
        /\b(cookie|gdpr|privacy-banner)\b/i,             // Cookie/隐私横幅
        /\b(footer-legal|copyright-text)\b/i,            // 页脚法律信息
        // Reddit 特定：排除侧边栏
        /\b(sidebar|side-bar|right-sidebar|left-sidebar)\b/i,
        /\b(promotedlink|promoted-link)\b/i,
        // 通用：排除导航和辅助区域
        /\b(complementary|navigation|banner)\b/i
      ];
      
      if (skipPatterns.some(pattern => pattern.test(combinedStr))) {
        skipped.skipPattern++;
        continue;
      }
      
      // Skip text with copyright/legal patterns
      const lowerText = text.toLowerCase();
      if (lowerText.includes('all rights reserved') || 
          lowerText.includes('©') ||
          lowerText.match(/\d{4}\.\s*all rights/) ||
          lowerText.includes('license for publishing') ||
          lowerText.includes('updated:') && lowerText.length < 100) {
        skipped.skipPattern++;
        continue;
      }
      
      nodes.push(n);
    }
    return nodes;
  }

  function detectPhrases(text) {
    const results = [];
    const lowered = text.toLowerCase();

    // connectors and idioms exact lookup
    if (SETTINGS.categories.connector) {
      for (const phrase of CONNECTORS) {
        const idx = lowered.indexOf(phrase);
        if (idx !== -1) results.push({ start: idx, end: idx + phrase.length, type: 'connector', phrase });
      }
    }
    if (SETTINGS.categories.idiom) {
      for (const phrase of IDIOMS) {
        const idx = lowered.indexOf(phrase);
        if (idx !== -1) results.push({ start: idx, end: idx + phrase.length, type: 'idiom', phrase });
      }
    }

    // common collocations & phrasal verbs exact lookup
    if (SETTINGS.categories.collocation) {
      for (const phrase of COMMON_COLLOCATIONS) {
        const idx = lowered.indexOf(phrase);
        if (idx !== -1) results.push({ start: idx, end: idx + phrase.length, type: 'collocation', phrase });
      }
      for (const phrase of PHRASAL_VERBS) {
        const idx = lowered.indexOf(phrase);
        if (idx !== -1) results.push({ start: idx, end: idx + phrase.length, type: 'collocation', phrase });
      }
    }

    // collocations via regex matches
    if (SETTINGS.categories.collocation && SETTINGS.mode !== 'lite') {
      for (const re of collocationRegexes) {
        let m;
        while ((m = re.exec(text)) !== null) {
          const phrase = m[0];
          results.push({ start: m.index, end: m.index + phrase.length, type: 'collocation', phrase });
        }
      }
    }

    // merge overlapping by preferring longer spans
    results.sort((a,b)=> a.start - b.start || b.end - a.end);
    const merged = [];
    for (const r of results) {
      if (!merged.length || r.start >= merged[merged.length-1].end) {
        merged.push(r);
      }
    }
    let cap = 18;
    if (SETTINGS.mode === 'lite') cap = 8;
    else if (SETTINGS.mode === 'advanced') cap = 30;
    return merged.slice(0, cap);
  }

  function wrapHighlights(node) {
    const text = node.nodeValue;
    const matches = detectPhrases(text);
    if (!matches.length) return;
    const frag = document.createDocumentFragment();
    let cursor = 0;
    for (const m of matches) {
      if (m.start > cursor) frag.appendChild(document.createTextNode(text.slice(cursor, m.start)));
      const span = document.createElement('span');
      span.textContent = text.slice(m.start, m.end);
      span.className = `${HIGHLIGHT_CLASS} lingolette-type-${m.type}`;
      span.setAttribute('data-lingolette', '1');
      span.setAttribute('data-type', m.type);
      span.setAttribute('data-phrase', span.textContent);
      span.title = tooltipTitleForType(m.type);
      attachHover(span);
      frag.appendChild(span);
      cursor = m.end;
    }
    if (cursor < text.length) frag.appendChild(document.createTextNode(text.slice(cursor)));
    node.parentNode.replaceChild(frag, node);
  }

  // 自动检测网页主要语言
  function detectPageLanguage() {
    // 1. 优先使用 HTML lang 属性
    const htmlLang = document.documentElement.lang;
    if (htmlLang) {
      if (htmlLang.startsWith('zh-Hans') || htmlLang.startsWith('zh-CN')) return 'zh-CN';
      if (htmlLang.startsWith('zh-Hant') || htmlLang.startsWith('zh-TW') || htmlLang.startsWith('zh-HK')) return 'zh-traditional';
      if (htmlLang.startsWith('zh')) return 'zh-CN'; // 默认简体中文
      if (htmlLang.startsWith('en')) return 'en';
      if (htmlLang.startsWith('fr')) return 'fr';
      if (htmlLang.startsWith('es')) return 'es';
      if (htmlLang.startsWith('de')) return 'de';
      if (htmlLang.startsWith('ko')) return 'ko';
      if (htmlLang.startsWith('ja')) return 'ja';
      if (htmlLang.startsWith('ru')) return 'ru';
    }
    
    // 2. 检测页面文本内容（取前1000字符）
    const bodyText = document.body?.innerText?.slice(0, 2000) || '';
    const chineseCount = (bodyText.match(/[\u4e00-\u9fa5]/g) || []).length;
    const englishCount = (bodyText.match(/[a-zA-Z]/g) || []).length;
    
    // 如果中文字符占比超过30%，判定为中文页面
    if (chineseCount > englishCount * 0.3) {
      return 'zh-CN';
    }
    
    // 3. 默认返回英文
    return 'en';
  }

  async function aiDetect(text) {
    try {
      
      // 自动检测网页语言
      const pageLanguage = detectPageLanguage();
      
      const res = await chrome.runtime.sendMessage({
        type: 'LINGOLETTE_AI_HIGHLIGHT',
        payload: {
          text,
          mode: SETTINGS.mode,
          categories: SETTINGS.categories,
          provider: SETTINGS.ai.provider,
          language: pageLanguage, // 使用检测到的网页语言，而不是固定配置
          context: {
            title: document.title || '',
            url: location.href || '',
            domain: location.hostname || ''
          }
        }
      });
      
      if (res && res.ok && Array.isArray(res.spans)) {
        return res.spans;
      } else {
        console.warn('[LeMingle] ✗ API returned no valid spans:', {
          ok: res?.ok,
          error: res?.error,
          spansType: typeof res?.spans,
          spansLength: res?.spans?.length
        });
        
        // Return error info for special handling
        if (res?.error) {
          return { error: res.error, message: res.message };
        }
      }
    } catch (e) {
      console.error('[LeMingle] ✗ AI request exception:', e);
      
      // Detect error type
      if (e.message && e.message.toLowerCase().includes('network')) {
        return { error: 'NETWORK_ERROR', message: e.message };
      }
      
      return { error: 'AI_HIGHLIGHT_FAILED', message: e.message };
    }
    return null;
  }

  async function wrapHighlightsAsync(node) {
    let text = node.nodeValue || '';
    
    // Clean up text: remove HTML entities, extra whitespace, and non-printable chars
    text = text
      .replace(/&[a-z]+;/gi, ' ')  // Remove HTML entities like &nbsp;
      .replace(/[\u200B-\u200D\uFEFF]/g, '')  // Remove zero-width chars
      .replace(/\s+/g, ' ')  // Normalize whitespace
      .trim();
    
    // Skip if text contains HTML/JS patterns or metadata
    if (/<[^>]+>/.test(text) || /\{[\s\S]*\}/.test(text) || text.includes('function') || text.includes('var ')) {
      return;
    }
    
    // Skip if too short after cleaning
    if (text.length < 30) {
      return;
    }
    
    let matches = [];
    const spans = await aiDetect(text);
    if (spans && spans.length) {
      for (const s of spans) {
        if (!SETTINGS.categories[s.type]) continue;
        matches.push({ start: s.start, end: s.end, type: s.type, phrase: text.slice(s.start, s.end) });
      }
      // Merge and cap similarly
      matches.sort((a,b)=> a.start - b.start || b.end - a.end);
      const merged = [];
      for (const r of matches) {
        if (!merged.length || r.start >= merged[merged.length-1].end) merged.push(r);
      }
      matches = merged;
    } else {
      // fallback to heuristic
      matches = detectPhrases(text);
    }
    if (!matches.length) return;
    const frag = document.createDocumentFragment();
    let cursor = 0;
    for (const m of matches) {
      if (m.start > cursor) frag.appendChild(document.createTextNode(text.slice(cursor, m.start)));
      const span = document.createElement('span');
      span.textContent = text.slice(m.start, m.end);
      span.className = `${HIGHLIGHT_CLASS} lingolette-type-${m.type}`;
      span.setAttribute('data-lingolette', '1');
      span.setAttribute('data-type', m.type);
      span.setAttribute('data-phrase', span.textContent);
      span.title = tooltipTitleForType(m.type);
      attachHover(span);
      frag.appendChild(span);
      cursor = m.end;
    }
    if (cursor < text.length) frag.appendChild(document.createTextNode(text.slice(cursor)));
    node.parentNode.replaceChild(frag, node);
  }

  function tooltipTitleForType(t) {
    switch(t){
      case 'collocation': return '核心词组搭配 (Collocation)';
      case 'idiom': return '地道习语 (Idiom)';
      case 'connector': return '逻辑连接句式 (Connector)';
      default: return 'Lingolette';
    }
  }

  let tooltipEl = null;
  function ensureTooltip() {
    if (!tooltipEl) {
      tooltipEl = document.createElement('div');
      tooltipEl.className = TOOLTIP_CLASS;
      tooltipEl.style.display = 'none';
      tooltipEl.setAttribute('data-lingolette','1');
      tooltipEl.addEventListener('mouseenter', () => {
        hoverState.overTooltip = true;
        if (hoverState.hideTimer) { clearTimeout(hoverState.hideTimer); hoverState.hideTimer = null; }
      });
      tooltipEl.addEventListener('mouseleave', () => {
        hoverState.overTooltip = false;
        scheduleHideTooltip();
      });
      document.body.appendChild(tooltipEl);
    }
    return tooltipEl;
  }

  function showTooltip(target, data) {
    const el = ensureTooltip();
    el.innerHTML = '';
    
    // Apply theme based on background
    if (isBackgroundDark()) {
      el.classList.add('light-theme');
    } else {
      el.classList.remove('light-theme');
    }

    const title = document.createElement('div');
    title.style.display = 'flex';
    title.style.alignItems = 'center';
    title.style.justifyContent = 'space-between';
    title.style.gap = '8px';
    
    const titleLeft = document.createElement('div');
    titleLeft.style.display = 'flex';
    titleLeft.style.alignItems = 'center';
    titleLeft.style.gap = '6px';
    titleLeft.style.flex = '1';
    
    const titleText = document.createElement('div');
    titleText.textContent = data.phrase;
    titleText.style.fontWeight = '600';
    titleLeft.appendChild(titleText);
    
    // Type badge
    const typeBadge = document.createElement('span');
    typeBadge.className = `lingolette-type-badge ${data.type || 'collocation'}`;
    typeBadge.textContent = data.type || 'collocation';
    titleLeft.appendChild(typeBadge);
    
    title.appendChild(titleLeft);
    
    // Pin toggle
    const pinBtn = document.createElement('button');
    pinBtn.textContent = hoverState.pinned ? '📌 已固定' : '📌 固定';
    pinBtn.title = '固定卡片，便于操作 (再次点击可取消)';
    pinBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      hoverState.pinned = !hoverState.pinned;
      pinBtn.textContent = hoverState.pinned ? '📌 已固定' : '📌 固定';
      closeBtn.style.display = hoverState.pinned ? 'inline-block' : 'none';
    });
    title.appendChild(pinBtn);
    el.appendChild(title);

    // meaning (placeholder simple): For MVP, show type + hint
    const meaning = document.createElement('div');
    meaning.className = 'lt-row';
    meaning.textContent = meaningText(data);
    el.appendChild(meaning);

    // actions: TTS, save
    const actions = document.createElement('div');
    actions.className = 'lt-actions';

    const btnTts = document.createElement('button');
    btnTts.textContent = '🔊 发音';
    btnTts.title = '朗读该语料';
    btnTts.addEventListener('click', () => speak(data.phrase, data.meaning));
    actions.appendChild(btnTts);

    // Check if this phrase is already in collection
    const isCollectionItem = target.classList.contains(COLLECTION_HIGHLIGHT_CLASS);
    const isAlreadyCollected = COLLECTION_PHRASES_SET.has(data.phrase.toLowerCase());
    
    const btnSave = document.createElement('button');
    
    if (isCollectionItem || isAlreadyCollected) {
      // Already collected (either blue-green or yellow AI highlight) - show remove button
      btnSave.textContent = t('removeFromCollection');
      btnSave.title = t('removeFromCollectionTitle');
      btnSave.addEventListener('click', async () => {
        btnSave.disabled = true;
        btnSave.textContent = t('removing');
        await removeItem(data.phrase);
        
        // Immediately remove from cache
        COLLECTION_PHRASES_SET.delete(data.phrase.toLowerCase());
        
        btnSave.textContent = '✅ 已移除';
        
        // If it's a collection highlight (blue-green), hide tooltip after removal
        if (isCollectionItem) {
          setTimeout(() => {
            hideTooltip();
            hoverState.pinned = false;
          }, 800);
        } else {
          // If it's an AI highlight, change button to allow re-collection
          setTimeout(() => {
            btnSave.textContent = t('addToCollection');
            btnSave.title = t('addToCollectionTitle');
            btnSave.disabled = false;
            // Re-attach click handler for re-collection
            btnSave.onclick = async () => {
              btnSave.disabled = true;
              btnSave.textContent = t('saving');
              await saveItem({
                text: data.phrase,
                type: data.type,
                meaning: data.meaning || '',
                url: location.href,
                title: document.title,
                ts: Date.now()
              });
              COLLECTION_PHRASES_SET.add(data.phrase.toLowerCase());
              chrome.runtime.sendMessage({ type: 'LINGOLETTE_SAVED_ITEM' });
              btnSave.textContent = t('removeFromCollection');
              btnSave.title = t('removeFromCollectionTitle');
              btnSave.disabled = false;
            };
          }, 1000);
        }
      });
    } else {
      // Not collected - show save button
      btnSave.textContent = t('addToCollection');
      btnSave.title = t('addToCollectionTitle');
      btnSave.addEventListener('click', async () => {
        btnSave.disabled = true;
        btnSave.textContent = t('saving');
        await saveItem({
          text: data.phrase,
          type: data.type,
          meaning: data.meaning || '',
          url: location.href,
          title: document.title,
          ts: Date.now()
        });
        
        // Immediately add to cache
        COLLECTION_PHRASES_SET.add(data.phrase.toLowerCase());
        
        chrome.runtime.sendMessage({ type: 'LINGOLETTE_SAVED_ITEM' });
        btnSave.textContent = t('removeFromCollection');
        btnSave.title = t('removeFromCollectionTitle');
        btnSave.disabled = false;
      });
    }
    actions.appendChild(btnSave);

    el.appendChild(actions);

    const rect = target.getBoundingClientRect();
    // Make visible to measure, then position, then reveal
    el.style.visibility = 'hidden';
    el.style.display = 'block';
    
    const viewportHeight = window.innerHeight;
    const viewportWidth = document.documentElement.clientWidth;
    const tooltipHeight = el.offsetHeight;
    const tooltipWidth = el.offsetWidth;
    
    let top = window.scrollY + rect.top - tooltipHeight - 8;
    let left = window.scrollX + rect.left;
    
    // Smart positioning: prefer above, but check all sides
    const spaceAbove = rect.top;
    const spaceBelow = viewportHeight - rect.bottom;
    const spaceLeft = rect.left;
    const spaceRight = viewportWidth - rect.right;
    
    // Vertical positioning
    if (spaceAbove >= tooltipHeight + 16) {
      // Enough space above
      top = window.scrollY + rect.top - tooltipHeight - 8;
    } else if (spaceBelow >= tooltipHeight + 16) {
      // Place below
      top = window.scrollY + rect.bottom + 8;
    } else {
      // Not enough space either side, center vertically in viewport
      top = window.scrollY + Math.max(8, (viewportHeight - tooltipHeight) / 2);
    }
    
    // Horizontal positioning - keep within viewport
    const maxLeft = window.scrollX + viewportWidth - tooltipWidth - 8;
    left = Math.max(window.scrollX + 8, Math.min(left, maxLeft));
    
    // If tooltip would cover the target, shift it horizontally
    if (top >= window.scrollY + rect.top - 8 && top <= window.scrollY + rect.bottom + 8) {
      if (spaceRight >= tooltipWidth + 16) {
        left = window.scrollX + rect.right + 8;
      } else if (spaceLeft >= tooltipWidth + 16) {
        left = window.scrollX + rect.left - tooltipWidth - 8;
      }
    }
    
    el.style.top = top + 'px';
    el.style.left = left + 'px';
    el.style.visibility = 'visible';
    // Cancel any pending hides while we just opened
    if (hoverState.hideTimer) { clearTimeout(hoverState.hideTimer); hoverState.hideTimer = null; }
  }

  function hideTooltip() {
    if (tooltipEl) tooltipEl.style.display = 'none';
  }

  function scheduleHideTooltip() {
    if (hoverState.hideTimer) { clearTimeout(hoverState.hideTimer); }
    hoverState.hideTimer = setTimeout(() => {
      if (!hoverState.pinned && !hoverState.overSpan && !hoverState.overTooltip) {
        hideTooltip();
      }
    }, 180);
  }

  function attachHover(span) {
    let enterTimer;
    span.addEventListener('mouseenter', () => {
      hoverState.overSpan = true;
      if (hoverState.hideTimer) { clearTimeout(hoverState.hideTimer); hoverState.hideTimer = null; }
      enterTimer = setTimeout(() => {
        showTooltip(span, { 
          phrase: span.getAttribute('data-phrase'), 
          type: span.getAttribute('data-type'),
          meaning: span.getAttribute('data-meaning')
        });
      }, 200);
    });
    span.addEventListener('mouseleave', () => {
      clearTimeout(enterTimer);
      hoverState.overSpan = false;
      scheduleHideTooltip();
    });
  }

  function meaningText(data) {
    // 优先使用 AI 返回的释义
    if (data.meaning) {
      return data.meaning;
    }
    
    // 回退到默认提示
    switch (data.type) {
      case 'translation': return t('translating');
      case 'collocation': return '常见且地道的词组搭配，可优先积累与复用。';
      case 'idiom': return '英语中常用的习语表达，注意语境与语气。';
      case 'connector': return '用于衔接段落与逻辑的框架句式，有助于清晰表达。';
      default: return 'Lingolette 提示';
    }
  }

  // 语言代码映射：从简短代码到完整的 BCP 47 语言标签
  const LANGUAGE_CODES = {
    'en': 'en-US',
    'fr': 'fr-FR',
    'es': 'es-ES',
    'de': 'de-DE',
    'ko': 'ko-KR',
    'ja': 'ja-JP',
    'zh-simplified': 'zh-CN',
    'zh-traditional': 'zh-TW',
    'ru': 'ru-RU'
  };

  // 发音功能：始终使用目标语言发音，但根据学习模式选择发音内容
  // - 正向学习（网页语言 = 目标语言）：朗读短语本身
  // - 反向学习（网页语言 = 释义语言）：朗读翻译/释义
  // - 兜底逻辑：其他情况 → 朗读短语本身
  function speak(phrase, meaning = null) {
    try {
      // 1. 确定学习模式和发音内容（通用逻辑）
      const pageLanguage = detectPageLanguage();
      const targetLang = SETTINGS.targetLanguage || 'en';
      const explanationLang = SETTINGS.explanationLang || 'zh-simplified';
      
      // 标准化语言代码（去除地区后缀）
      const normalizeLang = (l) => l.split('-')[0].toLowerCase();
      const normalizedPageLang = normalizeLang(pageLanguage);
      const normalizedTargetLang = normalizeLang(targetLang);
      const normalizedExplanationLang = normalizeLang(explanationLang);
      
      // 通用学习模式判断
      let learningMode;
      if (normalizedPageLang === normalizedTargetLang) {
        learningMode = 'forward'; // 正向学习
      } else if (normalizedPageLang === normalizedExplanationLang) {
        learningMode = 'reverse'; // 反向学习
      } else {
        learningMode = 'fallback'; // 兜底
      }
      
      const isForwardLearning = learningMode === 'forward' || learningMode === 'fallback';
      
      // 选择发音内容
      let textToSpeak;
      if (isForwardLearning) {
        // 正向学习/兜底：朗读短语本身
        textToSpeak = phrase;
      } else {
        // 反向学习：朗读翻译/释义
        textToSpeak = meaning || phrase;
      }
      
      // 2. 获取完整的语言代码（始终使用目标语言）
      const langCode = LANGUAGE_CODES[targetLang] || LANGUAGE_CODES[normalizeLang(targetLang)] || 'en-US';
      
      // 3. 创建语音合成
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      utterance.lang = langCode;
      
      // 4. 尝试选择最佳语音（优先本地语音）
      const voices = speechSynthesis.getVoices();
      const preferredVoice = voices.find(voice => 
        voice.lang.startsWith(langCode.split('-')[0]) && voice.localService
      ) || voices.find(voice => 
        voice.lang.startsWith(langCode.split('-')[0])
      );
      
      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }
      
      // 5. 播放语音
      speechSynthesis.speak(utterance);
    } catch (e) {
      console.error('[LeMingle] Speech synthesis error:', e);
    }
  }

  async function saveItem(item) {
    return new Promise((resolve) => {
      chrome.storage.local.get(['lingolette_items'], (res) => {
        const items = res.lingolette_items || [];
        items.unshift(item);
        chrome.storage.local.set({ lingolette_items: items.slice(0, 1000) }, () => {
          // Update collection cache and re-highlight
          loadCollectionItems().then(() => {
            if (SETTINGS.collectionHighlight) {
              // Highlight the newly added phrase on current page
              const root = document.querySelector('main, article, .article, .content, [role="main"], body');
              if (root) {
                const nodes = Array.from(textNodesUnder(root));
                applyCollectionHighlighting(nodes);
              }
            }
          });
          
          // Trigger cloud sync via message to background
          chrome.runtime.sendMessage({
            type: 'LINGOLETTE_BATCH_SYNC_ADD',
            payload: item
          }).catch(() => {
            // Ignore if background script is not ready
          });
          
          resolve(true);
        });
      });
    });
  }

  async function removeItem(phrase) {
    return new Promise((resolve) => {
      chrome.storage.local.get(['lingolette_items'], (res) => {
        const items = res.lingolette_items || [];
        const phraseLower = phrase.toLowerCase();
        
        // Find the item to get cloudId before removing
        const itemToRemove = items.find(item => 
          (item.phrase || item.text)?.toLowerCase() === phraseLower
        );
        
        const filtered = items.filter(item => 
          (item.phrase || item.text)?.toLowerCase() !== phraseLower
        );
        chrome.storage.local.set({ lingolette_items: filtered }, () => {
          // Update collection cache and remove highlights
          loadCollectionItems().then(() => {
            if (SETTINGS.collectionHighlight) {
              // Remove highlights for this phrase
              removeCollectionHighlight(phrase);
            }
          });
          
          // Trigger cloud sync deletion if cloudId exists
          if (itemToRemove?.cloudId) {
            chrome.runtime.sendMessage({
              type: 'LINGOLETTE_BATCH_SYNC_DELETE',
              payload: itemToRemove.cloudId
            }).catch(() => {
              // Ignore if background script is not ready
            });
          }
          
          resolve(true);
        });
      });
    });
  }

  function removeCollectionHighlight(phrase) {
    const phraseLower = phrase.toLowerCase();
    document.querySelectorAll(`.${COLLECTION_HIGHLIGHT_CLASS}`).forEach(span => {
      if (span.getAttribute('data-phrase')?.toLowerCase() === phraseLower) {
        const text = span.textContent;
        span.replaceWith(document.createTextNode(text));
      }
    });
  }

  // Extract sentence context around the selected text
  function extractSentenceContext(selection) {
    try {
      if (!selection || !selection.rangeCount) return '';
      
      const range = selection.getRangeAt(0);
      const container = range.commonAncestorContainer;
      
      // Get the text content of the parent element
      const parentElement = container.nodeType === Node.TEXT_NODE 
        ? container.parentElement 
        : container;
      
      if (!parentElement) return '';
      
      const fullText = parentElement.textContent || '';
      const selectedText = selection.toString().trim();
      
      // Find the position of selected text in the full text
      const selectedIndex = fullText.indexOf(selectedText);
      if (selectedIndex === -1) return selectedText; // Fallback
      
      // Sentence boundary markers
      const sentenceEnders = /[.!?。！？\n]/g;
      
      // Find sentence start (look backwards)
      let sentenceStart = 0;
      for (let i = selectedIndex - 1; i >= 0; i--) {
        if (sentenceEnders.test(fullText[i])) {
          sentenceStart = i + 1;
          break;
        }
      }
      
      // Find sentence end (look forwards)
      let sentenceEnd = fullText.length;
      for (let i = selectedIndex + selectedText.length; i < fullText.length; i++) {
        if (sentenceEnders.test(fullText[i])) {
          sentenceEnd = i + 1;
          break;
        }
      }
      
      // Extract the sentence and trim
      let sentence = fullText.substring(sentenceStart, sentenceEnd).trim();
      
      // If sentence is too long (>500 chars), limit context window
      if (sentence.length > 500) {
        const contextWindow = 200;
        const start = Math.max(0, selectedIndex - sentenceStart - contextWindow);
        const end = Math.min(sentence.length, selectedIndex - sentenceStart + selectedText.length + contextWindow);
        sentence = sentence.substring(start, end).trim();
      }
      
      return sentence || selectedText;
    } catch (err) {
      console.error('[LeMingle] Error extracting sentence context:', err);
      return selection.toString().trim();
    }
  }

  // Selection mini-button
  let selectFab = null;
  function ensureFab() {
    if (!selectFab) {
      selectFab = document.createElement('div');
      selectFab.className = 'lingolette-select-fab';
      selectFab.textContent = '✨';
      selectFab.setAttribute('data-lingolette','1');
      selectFab.style.display = 'none';
      document.body.appendChild(selectFab);
      selectFab.addEventListener('click', async () => {
        const sel = window.getSelection();
        const text = (sel && sel.toString().trim()) || '';
        if (!text) return;
        
        // 提取划选词所在的完整句子作为上下文
        const context = extractSentenceContext(sel);
        
        // 显示加载状态
        showTooltip(selectFab, { 
          phrase: text, 
          type: 'translation',
          meaning: t('translating') 
        });
        
        // 调用翻译 API
        try {
          const res = await chrome.runtime.sendMessage({
            type: 'LINGOLETTE_TRANSLATE',
            payload: { text, context }
          });
          
          if (res?.ok && res.translation) {
            // 更新为真实翻译
            showTooltip(selectFab, { 
              phrase: text, 
              type: 'translation',
              meaning: res.translation,
              quota: res.quota
            });
          } else if (res?.error === 'QUOTA_EXCEEDED') {
            // 配额超限
            showTooltip(selectFab, { 
              phrase: text, 
              type: 'translation',
              meaning: '❌ ' + (res.message || '今日配额已用完，请明天再试')
            });
          } else if (res?.error === 'NOT_LOGGED_IN') {
            // 未登录
            showTooltip(selectFab, { 
              phrase: text, 
              type: 'translation',
              meaning: '❌ 请先登录以使用翻译功能'
            });
          } else {
            // 其他错误
            showTooltip(selectFab, { 
              phrase: text, 
              type: 'translation',
              meaning: '❌ 翻译失败，请重试'
            });
          }
        } catch (err) {
          console.error('[LeMingle] Translation error:', err);
          showTooltip(selectFab, { 
            phrase: text, 
            type: 'translation',
            meaning: '❌ 翻译失败，请重试'
          });
        }
      });
    }
    
    // Apply theme based on background
    if (isBackgroundDark()) {
      selectFab.classList.add('light-theme');
    } else {
      selectFab.classList.remove('light-theme');
    }
    
    return selectFab;
  }

  function guessType(text) {
    const t = text.toLowerCase();
    if (CONNECTORS.has(t)) return 'connector';
    if (IDIOMS.has(t)) return 'idiom';
    return 'collocation';
  }

  document.addEventListener('selectionchange', () => {
    const sel = window.getSelection();
    const text = (sel && sel.toString().trim()) || '';
    const fab = ensureFab();
    if (text && /[a-zA-Z]/.test(text) && text.length <= 120) {
      const range = sel.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      fab.style.top = window.scrollY + rect.bottom + 6 + 'px';
      fab.style.left = window.scrollX + rect.right + 6 + 'px';
      fab.style.display = 'block';
    } else {
      fab.style.display = 'none';
    }
  });

  // Detect if background is dark
  function isBackgroundDark() {
    try {
      const bgColor = window.getComputedStyle(document.body).backgroundColor;
      if (!bgColor || bgColor === 'transparent' || bgColor === 'rgba(0, 0, 0, 0)') {
        // Check html element
        const htmlBg = window.getComputedStyle(document.documentElement).backgroundColor;
        if (!htmlBg || htmlBg === 'transparent' || htmlBg === 'rgba(0, 0, 0, 0)') {
          // Default to system preference
          return window.matchMedia('(prefers-color-scheme: dark)').matches;
        }
        return getLuminance(htmlBg) < 0.5;
      }
      return getLuminance(bgColor) < 0.5;
    } catch {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
  }
  
  function getLuminance(color) {
    const rgb = color.match(/\d+/g);
    if (!rgb || rgb.length < 3) return 0.5;
    const [r, g, b] = rgb.map(x => {
      const val = parseInt(x) / 255;
      return val <= 0.03928 ? val / 12.92 : Math.pow((val + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  }

  // Loading indicator
  let loadingIndicator = null;
  function showLoadingIndicator(state, message, count = null) {
    if (!loadingIndicator) {
      loadingIndicator = document.createElement('div');
      loadingIndicator.className = 'lingolette-loading-indicator';
      loadingIndicator.setAttribute('data-lingolette', '1');
      document.body.appendChild(loadingIndicator);
    }
    
    // Apply theme based on background
    if (isBackgroundDark()) {
      loadingIndicator.classList.add('light-theme');
    } else {
      loadingIndicator.classList.remove('light-theme');
    }
    
    let icon = '';
    let clickable = false;
    
    if (state === 'hidden') {
      hideLoadingIndicator();
      return;
    } else if (state === 'processing') {
      icon = '<div class="spinner"></div>';
    } else if (state === 'success') {
      icon = '<span class="icon">✓</span>';
    } else if (state === 'error') {
      icon = '<span class="icon">✗</span>';
      clickable = true;
    } else if (state === 'info') {
      icon = '<span class="icon">ℹ️</span>';
    }
    
    const countText = count !== null ? `<span class="count">${count}</span>` : '';
    loadingIndicator.innerHTML = `${icon}<span class="text">${message}</span>${countText}`;
    loadingIndicator.className = 'lingolette-loading-indicator visible' + (clickable ? ' clickable' : '');
    
    if (clickable) {
      loadingIndicator.onclick = () => hideLoadingIndicator();
    }
  }
  
  function hideLoadingIndicator() {
    if (loadingIndicator) {
      loadingIndicator.classList.remove('visible');
    }
  }

  // Initial highlighting after main content loads, within 5s
  // Maintain lazy processing state for AI highlighting
  let AI_NODES = [];
  let AI_PROCESSED = new Set(); // Track processed node indices
  let AI_BUSY = false;
  const AI_BATCH_SIZE = 20;  // 优化：增加批处理大小，减少请求次数（10 → 20）
  const AI_POOL = 3;    // 优化：增加并发数，加快处理速度（2 → 3）
  const AI_DELAY = 300; // 优化：减少延迟，加快处理速度（600ms → 300ms）
  let AI_START_TIME = 0; // Track processing start time
  let AI_TOTAL_FOUND = 0; // Track total expressions found
  
  // Smart triggering based on user behavior
  let LAST_SCROLL_Y = 0;
  let LAST_SCROLL_TIME = 0;
  let SCROLL_VELOCITY = 0; // px/sec
  let DWELL_TIMER = null;
  let VIEWPORT_STABLE_TIME = 0; // When viewport last became stable
  const DWELL_THRESHOLD = 800; // 优化：减少停留时间，更快触发高亮（1000ms → 800ms）
  const FAST_SCROLL_THRESHOLD = 500; // 优化：提高快速滚动阈值，允许更多滚动时高亮（300 → 500 px/s）
  const MERGE_THRESHOLD = 1500; // 优化：增加合并阈值，减少请求次数（1200 → 1500）
  let SEEN_NODES = new Set(); // Track nodes that have been in viewport

  function viewportDistanceForNode(node) {
    try {
      const el = node.parentElement || node.parentNode;
      if (!el || !el.getBoundingClientRect) return Number.POSITIVE_INFINITY;
      const r = el.getBoundingClientRect();
      const nodeCenter = window.scrollY + r.top + r.height / 2;
      
      // 优化：使用阅读焦点区域（屏幕上方 25%）作为参考点
      // 用户阅读时视线通常聚焦在屏幕上方 1/4 处
      const readingFocusY = window.scrollY + window.innerHeight * 0.25;
      return Math.abs(nodeCenter - readingFocusY);
    } catch { return Number.POSITIVE_INFINITY; }
  }

  // Merge adjacent nodes into groups
  function mergeNodesIntoGroups(nodeIndices) {
    if (nodeIndices.length === 0) return [];
    
    const groups = [];
    let currentGroup = [nodeIndices[0]];
    let currentText = AI_NODES[nodeIndices[0]].nodeValue || '';
    
    for (let i = 1; i < nodeIndices.length; i++) {
      const idx = nodeIndices[i];
      const nodeText = AI_NODES[idx].nodeValue || '';
      
      // If adding this node keeps us under threshold, merge it
      if (currentText.length + nodeText.length < MERGE_THRESHOLD) {
        currentGroup.push(idx);
        currentText += ' ' + nodeText;
      } else {
        // Start new group
        groups.push(currentGroup);
        currentGroup = [idx];
        currentText = nodeText;
      }
    }
    
    // Add last group
    if (currentGroup.length > 0) {
      groups.push(currentGroup);
    }
    
    return groups;
  }

  // Get nodes in current viewport (with lookahead)
  function getViewportNodes(lookahead = 2.0) {  // 优化：增加预加载倍数，提前处理更多内容（1.25 → 2.0）
    const viewportTop = window.scrollY;
    const viewportBottom = window.scrollY + window.innerHeight;
    const lookaheadHeight = window.innerHeight * lookahead;
    
    const candidates = [];
    const seenInViewport = [];
    
    for (let i = 0; i < AI_NODES.length; i++) {
      const node = AI_NODES[i];
      const el = node.parentElement;
      if (!el) continue;
      
      const rect = el.getBoundingClientRect();
      const nodeTop = window.scrollY + rect.top;
      const nodeBottom = window.scrollY + rect.bottom;
      
      // Track nodes that are currently in viewport (no lookahead)
      if (nodeBottom >= viewportTop && nodeTop <= viewportBottom) {
        SEEN_NODES.add(i);
        seenInViewport.push(i);
      }
      
      // Skip already processed
      if (AI_PROCESSED.has(i)) continue;
      
      // In viewport or within lookahead distance
      if (nodeBottom >= viewportTop - lookaheadHeight && 
          nodeTop <= viewportBottom + lookaheadHeight) {
        // 优化：使用阅读焦点区域（屏幕上方 25%）计算距离
        const nodeCenter = (nodeTop + nodeBottom) / 2;
        const readingFocusY = viewportTop + window.innerHeight * 0.25;
        const distance = Math.abs(nodeCenter - readingFocusY);
        candidates.push({ idx: i, distance });
      }
    }
    
    // Prioritize: unprocessed seen nodes first, then by distance
    candidates.sort((a, b) => {
      const aIsSeen = SEEN_NODES.has(a.idx) && !AI_PROCESSED.has(a.idx);
      const bIsSeen = SEEN_NODES.has(b.idx) && !AI_PROCESSED.has(b.idx);
      if (aIsSeen && !bIsSeen) return -1;
      if (!aIsSeen && bIsSeen) return 1;
      return a.distance - b.distance;
    });
    
    const selectedIndices = candidates.slice(0, AI_BATCH_SIZE).map(c => c.idx);
    
    
    // Merge into groups
    return mergeNodesIntoGroups(selectedIndices);
  }

  async function highlightViewportNodes() {
    // Check if AI highlighting should be active
    if (AI_BUSY) return;
    
    // Check if AI is enabled globally
    if (!SETTINGS.ai.enabled) {
      return;
    }
    
    // Check if current site allows highlighting
    if (!shouldEnableHighlighting()) {
      return;
    }
    
    const nodeGroups = getViewportNodes();
    if (nodeGroups.length === 0) {
      return;
    }
    
    AI_BUSY = true;
    AI_START_TIME = Date.now();
    AI_TOTAL_FOUND = 0;
    
    // Show loading indicator
    showLoadingIndicator('processing', t('aiHighlighting'), `0/${nodeGroups.length}`);
    
    // Collect all results for ordered rendering
    const pendingResults = [];
    let criticalError = null; // Track critical errors like NOT_LOGGED_IN
    
    // Process groups with controlled concurrency
    let groupIndex = 0;
    
    async function processGroup(group, originalIndex) {
      const mergedText = group.map(i => AI_NODES[i].nodeValue || '').join(' ').trim();
      
      const result = await aiDetect(mergedText);
      
      // Check for critical errors
      if (result && result.error) {
        if (result.error === 'NOT_LOGGED_IN') {
          criticalError = { error: result.error, message: result.message };
          return; // Stop processing
        } else if (result.error === 'MONTHLY_QUOTA_EXCEEDED' || result.error === 'QUOTA_EXCEEDED') {
          criticalError = { error: result.error, message: result.message };
          return; // Stop processing
        }
      }
      
      const spans = Array.isArray(result) ? result : null;
      
      if (spans === null) {
      } else if (spans.length === 0) {
      }
      
      if (spans && spans.length > 0) {
        AI_TOTAL_FOUND += spans.length;
        for (const idx of group) {
          AI_PROCESSED.add(idx);
          const node = AI_NODES[idx];
          const nodeText = node.nodeValue || '';
          
          const nodeSpans = spans.filter(s => {
            const phrase = s.phrase || mergedText.slice(s.start, s.end);
            return nodeText.includes(phrase);
          }).map(s => {
            const phrase = s.phrase || mergedText.slice(s.start, s.end);
            const localStart = nodeText.indexOf(phrase);
            if (localStart === -1) return null;
            return {
              start: localStart,
              end: localStart + phrase.length,
              phrase: phrase,
              type: s.type,
              meaning: s.meaning
            };
          }).filter(Boolean);
          
          if (nodeSpans.length > 0) {
            // Collect results instead of rendering immediately
            pendingResults.push({
              nodeIndex: idx,
              node: node,
              spans: nodeSpans,
              groupIndex: originalIndex
            });
          }
        }
      } else {
        group.forEach(i => AI_PROCESSED.add(i));
      }
      
      // Update progress
      const processed = Math.min(groupIndex, nodeGroups.length);
      showLoadingIndicator('processing', t('aiHighlighting'), `${processed}/${nodeGroups.length}`);
      
      // Small delay between groups
      await new Promise(r => setTimeout(r, AI_DELAY));
    }
    
    // Worker pool pattern
    async function worker() {
      while (groupIndex < nodeGroups.length) {
        const idx = groupIndex++;
        await processGroup(nodeGroups[idx], idx);
      }
    }
    
    // Start AI_POOL workers
    const workers = [];
    for (let i = 0; i < AI_POOL; i++) {
      workers.push(worker());
    }
    await Promise.all(workers);
    
    // Sort results by node position (top to bottom)
    pendingResults.sort((a, b) => a.nodeIndex - b.nodeIndex);
    
    
    // Render in order with progressive animation
    for (let i = 0; i < pendingResults.length; i++) {
      const result = pendingResults[i];
      applyHighlightsToNode(result.node, result.spans);
      
      // Add fade-in animation to newly created highlights
      const parent = result.node.parentNode;
      if (parent) {
        const highlights = parent.querySelectorAll('.lingolette-highlight');
        highlights.forEach((el, index) => {
          // Only animate if not already animated
          if (!el.dataset.animated) {
            el.dataset.animated = 'true';
            el.style.opacity = '0';
            el.style.transform = 'translateY(-2px)';
            el.style.transition = 'opacity 0.4s ease-out, transform 0.4s ease-out';
            
            // Stagger animation for multiple highlights in same node
            setTimeout(() => {
              el.style.opacity = '1';
              el.style.transform = 'translateY(0)';
            }, index * 50);
          }
        });
      }
      
      // Progressive delay: slower at start, faster later
      if (i < pendingResults.length - 1) {
        const delay = i < 5 ? 80 : i < 15 ? 50 : 30;
        await new Promise(r => setTimeout(r, delay));
      }
    }
    
    AI_BUSY = false;
    
    // Check for critical errors first
    if (criticalError) {
      const now = Date.now();
      const errorType = criticalError.error;
      
      // Check if we should show notification (throttle to prevent spam)
      const lastShown = lastErrorNotification[errorType] || 0;
      const shouldShow = (now - lastShown) > ERROR_NOTIFICATION_COOLDOWN;
      
      if (shouldShow) {
        // Show full error message
        let message = '';
        if (errorType === 'NOT_LOGGED_IN') {
          message = t('notLoggedIn');
        } else if (errorType === 'MONTHLY_QUOTA_EXCEEDED' || errorType === 'QUOTA_EXCEEDED') {
          message = t('quotaExceeded');
        } else if (errorType === 'NETWORK_ERROR') {
          message = t('networkError');
        } else {
          message = t('aiHighlightFailed');
        }
        
        showLoadingIndicator('error', message);
        setTimeout(() => hideLoadingIndicator(), 5000);
        lastErrorNotification[errorType] = now;
      } else {
        // Show brief reminder for throttled notifications
        const remainingTime = Math.ceil((ERROR_NOTIFICATION_COOLDOWN - (now - lastShown)) / 60000);
        
        // Show short hint instead of full error
        let shortMessage = '';
        if (errorType === 'NOT_LOGGED_IN') {
          shortMessage = t('pleaseLogin');
        } else if (errorType === 'MONTHLY_QUOTA_EXCEEDED' || errorType === 'QUOTA_EXCEEDED') {
          shortMessage = t('pleaseUpgrade');
        }
        
        if (shortMessage) {
          showLoadingIndicator('info', shortMessage);
          setTimeout(() => hideLoadingIndicator(), 1500);
        }
      }
      
      return;
    }
    
    // Show completion message
    const elapsed = ((Date.now() - AI_START_TIME) / 1000).toFixed(1);
    if (AI_TOTAL_FOUND > 0) {
      const message = `${t('found')} ${AI_TOTAL_FOUND} ${t('expressions')}`;
      showLoadingIndicator('success', message, `${elapsed}s`);
      setTimeout(() => hideLoadingIndicator(), 3000);
    } else {
      // Use 'info' state and clear message for "no expressions found"
      showLoadingIndicator('info', t('noExpressionsFound'), `${elapsed}s`);
      setTimeout(() => hideLoadingIndicator(), 2500);
    }
    
  }
  
  // Apply highlights to a single node
  function applyHighlightsToNode(node, spans) {
    const text = node.nodeValue;
    if (!text || spans.length === 0) return;
    
    const frag = document.createDocumentFragment();
    let cursor = 0;
    
    for (const s of spans) {
      if (s.start > cursor) {
        frag.appendChild(document.createTextNode(text.slice(cursor, s.start)));
      }
      const span = document.createElement('span');
      span.className = `${HIGHLIGHT_CLASS} lingolette-type-${s.type}`;
      span.textContent = s.phrase;
      span.dataset.phrase = s.phrase;
      span.dataset.type = s.type;
      if (s.meaning) span.dataset.meaning = s.meaning; // 保存 AI 释义
      attachHover(span);
      frag.appendChild(span);
      cursor = s.end;
    }
    
    if (cursor < text.length) {
      frag.appendChild(document.createTextNode(text.slice(cursor)));
    }
    
    node.parentNode.replaceChild(frag, node);
  }

  // Generate flexible matching patterns for a phrase
  function generateMatchPatterns(phrase) {
    // Normalize: lowercase + collapse whitespace
    const normalized = phrase.toLowerCase().replace(/\s+/g, ' ').trim();
    const words = normalized.split(' ');
    
    // Generate patterns for different forms
    const patterns = [normalized]; // Original
    
    // For each word, generate common variations
    const variations = words.map(word => {
      const forms = [word];
      
      // Add -ing form
      if (!word.endsWith('ing')) {
        if (word.endsWith('e')) {
          forms.push(word.slice(0, -1) + 'ing'); // make → making
        } else {
          forms.push(word + 'ing'); // go → going
        }
      }
      
      // Add -ed form
      if (!word.endsWith('ed')) {
        if (word.endsWith('e')) {
          forms.push(word + 'd'); // make → made (simplified)
        } else {
          forms.push(word + 'ed'); // walk → walked
        }
      }
      
      // Add -s/-es form
      if (!word.endsWith('s')) {
        if (word.endsWith('s') || word.endsWith('x') || word.endsWith('ch') || word.endsWith('sh')) {
          forms.push(word + 'es');
        } else {
          forms.push(word + 's');
        }
      }
      
      return forms;
    });
    
    // Generate all combinations (limit to avoid explosion)
    if (words.length === 1) {
      return variations[0];
    } else if (words.length === 2) {
      const result = [];
      for (const w1 of variations[0]) {
        for (const w2 of variations[1]) {
          result.push(`${w1} ${w2}`);
        }
      }
      return result;
    } else {
      // For longer phrases, only use original + simple variations
      return [normalized];
    }
  }

  // Highlight collection items in a text node
  function highlightCollectionInNode(node) {
    if (!node || !node.nodeValue || !SETTINGS.collectionHighlight) return;
    if (COLLECTION_PHRASES_SET.size === 0) return;
    
    const text = node.nodeValue;
    const lowered = text.toLowerCase().replace(/\s+/g, ' '); // Normalize whitespace
    const matches = [];
    
    // Find all collection phrases in this text node
    for (const phrase of COLLECTION_PHRASES_SET) {
      const patterns = generateMatchPatterns(phrase);
      
      for (const pattern of patterns) {
        let idx = 0;
        while ((idx = lowered.indexOf(pattern, idx)) !== -1) {
          // Check word boundaries
          const before = idx > 0 ? text[idx - 1] : ' ';
          const after = idx + pattern.length < text.length ? text[idx + pattern.length] : ' ';
          const isWordStart = /\W/.test(before) || idx === 0;
          const isWordEnd = /\W/.test(after) || idx + pattern.length === text.length;
          
          if (isWordStart && isWordEnd) {
            matches.push({
              start: idx,
              end: idx + pattern.length,
              phrase: text.slice(idx, idx + pattern.length),
              originalPhrase: phrase // Store original for data attribute
            });
          }
          idx += 1;
        }
      }
    }
    
    if (matches.length === 0) return;
    
    // Sort by position and remove overlaps
    matches.sort((a, b) => a.start - b.start);
    const deduped = [];
    for (const m of matches) {
      if (deduped.length === 0 || m.start >= deduped[deduped.length - 1].end) {
        deduped.push(m);
      }
    }
    
    if (deduped.length === 0) return;
    
    // Replace text node with highlighted spans
    const frag = document.createDocumentFragment();
    let cursor = 0;
    for (const m of deduped) {
      if (cursor < m.start) {
        frag.appendChild(document.createTextNode(text.slice(cursor, m.start)));
      }
      
      // Find the full item data using the original phrase
      const itemData = COLLECTION_ITEMS.find(item => 
        (item.phrase || item.text)?.toLowerCase() === m.originalPhrase.toLowerCase()
      );
      
      const span = document.createElement('span');
      span.className = COLLECTION_HIGHLIGHT_CLASS;
      span.textContent = m.phrase; // Display the actual text found in page
      span.setAttribute('data-phrase', m.originalPhrase); // Store original for matching
      span.setAttribute('data-source', 'collection');
      
      // Store item data for tooltip
      if (itemData) {
        span.setAttribute('data-type', itemData.type || 'collocation');
        span.setAttribute('data-meaning', itemData.meaning || '');
      }
      
      // Attach hover tooltip
      attachHover(span);
      
      frag.appendChild(span);
      cursor = m.end;
    }
    if (cursor < text.length) {
      frag.appendChild(document.createTextNode(text.slice(cursor)));
    }
    
    if (node.parentNode) {
      node.parentNode.replaceChild(frag, node);
    }
  }
  
  // Apply collection highlighting to all text nodes
  function applyCollectionHighlighting(nodes) {
    if (!SETTINGS.collectionHighlight || COLLECTION_PHRASES_SET.size === 0) return;
    for (const node of nodes) {
      highlightCollectionInNode(node);
    }
  }

  function runHighlight() {
    // 优化：智能选择主内容区域，排除侧边栏
    // 优先级：
    // 1. 主内容区域（main, article, [role="main"]）
    // 2. Reddit 特定：帖子容器
    // 3. 通用内容区域
    // 4. body（最后备选）
    let root = document.querySelector('main, article, [role="main"]');
    
    // Reddit 特定优化：优先选择帖子容器
    if (!root && location.hostname.includes('reddit.com')) {
      root = document.querySelector('[data-testid="post-container"], shreddit-post, .Post') || 
             document.querySelector('main, article');
    }
    
    // 通用内容区域
    if (!root) {
      root = document.querySelector('.article, .content, .main-content, #main-content');
    }
    
    // 最后备选：body
    if (!root) {
      root = document.body;
    }
    
    if (!root) return;
    const nodes = Array.from(textNodesUnder(root));
    if (nodes.length > 0) {
      console.log('[LeMingle] Sample nodes:', nodes.slice(0, 3).map(n => ({
        text: n.nodeValue?.substring(0, 50),
        parent: n.parentElement?.tagName,
        parentClass: n.parentElement?.className
      })));
    }
    
    // Step 1: Apply collection highlighting first (fast, synchronous)
    if (SETTINGS.collectionHighlight && COLLECTION_PHRASES_SET.size > 0) {
      applyCollectionHighlighting(nodes);
    }
    
    // Step 2: Check if AI highlighting should be enabled for this page
    const shouldHighlight = shouldEnableHighlighting();
    
    if (!shouldHighlight) {
      // Show brief message and close indicator
      const domain = location.hostname;
      const pref = SITE_PREFERENCES[domain];
      let reason = t('aiHighlightDisabled');
      
      if (pref === 'always_off') {
        reason = t('aiHighlightDisabled');
      } else if (!SETTINGS.ai.enabled) {
        reason = t('aiFeatureDisabled');
      } else {
        // Blacklisted or not readable
        reason = t('siteNotSuitable');
      }
      
      
      // Don't show indicator if site is explicitly disabled (avoid spam on refresh)
      if (pref !== 'always_off') {
        showLoadingIndicator('info', reason);
        setTimeout(() => {
          showLoadingIndicator('hidden');
        }, 2500);
      }
      return;
    }
    
    if (shouldHighlight) {
      AI_NODES = nodes;
      AI_PROCESSED.clear();
      SEEN_NODES.clear();
      AI_BUSY = false;
      
      // Clear any existing initial highlight timer
      if (initialHighlightTimer) {
        clearTimeout(initialHighlightTimer);
        initialHighlightTimer = null;
      }
      
      // Initial highlight: process viewport after delay, with state recheck
      initialHighlightTimer = setTimeout(() => {
        // Recheck if highlighting should still be enabled
        if (SETTINGS.ai.enabled && shouldEnableHighlighting()) {
          highlightViewportNodes();
        } else {
        }
        initialHighlightTimer = null;
      }, 1000);
      
      // Remove old scroll listener if exists (prevent multiple listeners)
      if (scrollListener) {
        window.removeEventListener('scroll', scrollListener);
        scrollListener = null;
      }
      
      // Smart scroll handler: highlight on dwell
      scrollListener = () => {
        // Check if AI is enabled globally
        if (!SETTINGS.ai.enabled) return;
        
        // Check if current site allows highlighting
        if (!shouldEnableHighlighting()) return;
        
        const now = Date.now();
        const currentY = window.scrollY;
        const deltaY = Math.abs(currentY - LAST_SCROLL_Y);
        const deltaT = now - LAST_SCROLL_TIME;
        
        // Calculate scroll velocity
        if (deltaT > 0) {
          SCROLL_VELOCITY = (deltaY / deltaT) * 1000; // px/sec
        }
        
        LAST_SCROLL_Y = currentY;
        LAST_SCROLL_TIME = now;
        
        // Clear existing dwell timer
        if (DWELL_TIMER) {
          clearTimeout(DWELL_TIMER);
          DWELL_TIMER = null;
        }
        
        // If scrolling fast, don't trigger highlighting
        if (SCROLL_VELOCITY > FAST_SCROLL_THRESHOLD) {
          return;
        }
        
        // Set dwell timer: highlight after user stops scrolling
        DWELL_TIMER = setTimeout(() => {
          highlightViewportNodes();
        }, DWELL_THRESHOLD);
      };
      
      window.addEventListener('scroll', scrollListener, { passive: true });
    }
  }

  // Confetti animation function for page
  function triggerPageConfetti() {
    // Show celebration message in status indicator
    showLoadingIndicator('success', t('dailyGoalAchieved'));
    setTimeout(() => {
      hideLoadingIndicator();
    }, 3000);
    
    const duration = 3000; // 3 seconds
    const animationEnd = Date.now() + duration;
    const colors = ['#FFD700', '#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8'];
    
    function randomInRange(min, max) {
      return Math.random() * (max - min) + min;
    }
    
    const interval = setInterval(() => {
      const timeLeft = animationEnd - Date.now();
      
      if (timeLeft <= 0) {
        clearInterval(interval);
        return;
      }
      
      const particleCount = 5;
      
      for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'lingolette-confetti-particle';
        particle.setAttribute('data-lingolette', '1');
        particle.style.cssText = `
          position: fixed;
          width: 10px;
          height: 10px;
          background-color: ${colors[Math.floor(Math.random() * colors.length)]};
          left: ${randomInRange(0, 100)}%;
          top: -20px;
          border-radius: ${Math.random() > 0.5 ? '50%' : '0'};
          pointer-events: none;
          z-index: 999999;
          animation: lingolette-confetti-fall ${randomInRange(2, 3)}s linear forwards;
        `;
        
        document.body.appendChild(particle);
        
        setTimeout(() => {
          particle.remove();
        }, 3000);
      }
    }, 80);
    
    // Add CSS animation if not exists
    if (!document.getElementById('lingolette-confetti-style')) {
      const style = document.createElement('style');
      style.id = 'lingolette-confetti-style';
      style.setAttribute('data-lingolette', '1');
      style.textContent = `
        @keyframes lingolette-confetti-fall {
          0% {
            transform: translateY(0) rotate(0deg);
            opacity: 1;
          }
          100% {
            transform: translateY(${window.innerHeight + 50}px) rotate(${randomInRange(0, 720)}deg);
            opacity: 0;
          }
        }
      `;
      document.head.appendChild(style);
    }
    
  }

  // Message listener for popup communication
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // Handle confetti trigger
    if (msg.type === 'TRIGGER_CONFETTI') {
      triggerPageConfetti();
      sendResponse({ ok: true });
      return true;
    }
    
    // Handle user logout
    if (msg.type === 'USER_LOGGED_OUT') {
      
      // Stop any ongoing AI highlighting
      AI_BUSY = false;
      
      // Clear all timers
      if (DWELL_TIMER) {
        clearTimeout(DWELL_TIMER);
        DWELL_TIMER = null;
      }
      if (initialHighlightTimer) {
        clearTimeout(initialHighlightTimer);
        initialHighlightTimer = null;
      }
      
      // Remove scroll listener to prevent further highlighting
      if (scrollListener) {
        window.removeEventListener('scroll', scrollListener);
        scrollListener = null;
      }
      
      // Remove all AI highlights
      document.querySelectorAll(`.${HIGHLIGHT_CLASS}`).forEach(span => {
        const text = span.textContent;
        span.replaceWith(document.createTextNode(text));
      });
      
      // Hide loading indicator if showing
      hideLoadingIndicator();
      
      sendResponse({ ok: true });
      return true;
    }
    
    if (msg.type === 'CHECK_AUTO_DETECT') {
      // Ensure settings are loaded first
      chrome.storage?.sync.get(['lingolette_site_preferences', 'lingolette_ai_enabled'], (r) => {
        SITE_PREFERENCES = r.lingolette_site_preferences || {};
        SETTINGS.ai.enabled = !!r.lingolette_ai_enabled;
        
        const shouldEnable = shouldEnableHighlighting();
        sendResponse({ shouldEnable });
      });
      return true; // Keep channel open for async response
    }
    
    if (msg.type === 'GLOBAL_AI_TOGGLE_CHANGED') {
      // Global AI toggle changed - immediately remove or add highlights
      SETTINGS.ai.enabled = msg.enabled;
      
      if (!msg.enabled) {
        // Remove all AI highlights immediately
        document.querySelectorAll(`.${HIGHLIGHT_CLASS}`).forEach(span => {
          const text = span.textContent;
          span.replaceWith(document.createTextNode(text));
        });
      } else {
        // Re-check if should enable and re-highlight
        const shouldHighlight = shouldEnableHighlighting();
        if (shouldHighlight) {
          location.reload(); // Reload to re-apply highlights
        }
      }
      sendResponse({ ok: true });
      return true;
    }
    
    if (msg.type === 'COLLECTION_HIGHLIGHT_CHANGED') {
      // Update collection highlight setting
      SETTINGS.collectionHighlight = msg.enabled;
      
      if (msg.enabled) {
        // Re-apply collection highlighting
        loadCollectionItems().then(() => {
          const root = document.querySelector('main, article, .article, .content, [role="main"], body');
          if (root) {
            const nodes = Array.from(textNodesUnder(root));
            applyCollectionHighlighting(nodes);
          }
        });
      } else {
        // Remove collection highlights
        document.querySelectorAll(`.${COLLECTION_HIGHLIGHT_CLASS}`).forEach(span => {
          const text = span.textContent;
          span.replaceWith(document.createTextNode(text));
        });
      }
      sendResponse({ ok: true });
      return true;
    }
    
    if (msg.type === 'COLLECTION_ITEM_REMOVED') {
      // Remove highlight for deleted item
      loadCollectionItems().then(() => {
        if (SETTINGS.collectionHighlight) {
          removeCollectionHighlight(msg.phrase);
        }
      });
      sendResponse({ ok: true });
      return true;
    }
  });

  // Initial load - 确保设置加载完成后再执行高亮
  async function initialize() {
    await loadSettings();
    loadCollectionItems();
    
    // 等待 DOM 稳定后执行高亮
    setTimeout(() => {
      runHighlight();
    }, 800);
  }
  
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    initialize();
  } else {
    window.addEventListener('DOMContentLoaded', () => {
      initialize();
    });
  }

  // Monitor URL changes for SPA navigation
  let lastUrl = location.href;
  const urlObserver = new MutationObserver(() => {
    const currentUrl = location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      
      // Reset state
      AI_NODES = [];
      AI_PROCESSED = new Set();
      AI_BUSY = false;
      SEEN_NODES = new Set();
      
      // Re-run after a delay to let content load
      setTimeout(() => {
        runHighlight();
      }, 800);
    }
  });
  
  urlObserver.observe(document, { subtree: true, childList: true });

  // Monitor significant DOM changes (e.g., tab content switching)
  let contentChangeTimer = null;
  const contentObserver = new MutationObserver((mutations) => {
    // Check if there are significant content changes
    const hasSignificantChange = mutations.some(m => {
      return m.addedNodes.length > 0 && 
             Array.from(m.addedNodes).some(node => {
               return node.nodeType === 1 && // Element node
                      (node.tagName === 'ARTICLE' || 
                       node.tagName === 'SECTION' ||
                       node.tagName === 'MAIN' ||
                       (node.querySelector && node.querySelector('p, article, section')));
             });
    });
    
    if (hasSignificantChange) {
      // Debounce to avoid too frequent re-runs
      clearTimeout(contentChangeTimer);
      contentChangeTimer = setTimeout(() => {
        // Re-collect text nodes from the root element
        const root = document.querySelector('main, article, .article, .content, [role="main"], body');
        if (root) {
          const newNodes = Array.from(textNodesUnder(root));
          
          // Update AI_NODES with new nodes (don't clear, just add new ones)
          const existingNodeSet = new Set(AI_NODES);
          const addedNodes = newNodes.filter(n => !existingNodeSet.has(n));
          if (addedNodes.length > 0) {
            AI_NODES.push(...addedNodes);
          }
          
          // Apply collection highlighting to new nodes
          if (SETTINGS.collectionHighlight && COLLECTION_PHRASES_SET.size > 0) {
            applyCollectionHighlighting(addedNodes);
          }
          
          // Trigger AI highlighting for new viewport nodes
          if (SETTINGS.ai.enabled) {
            highlightViewportNodes();
          }
        }
      }, 500);
    }
  });
  
  contentObserver.observe(document.body, { 
    childList: true, 
    subtree: true 
  });

})();
