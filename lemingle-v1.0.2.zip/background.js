// Lingolette background service worker (MV3)
// - Handles badge count and animation
// - Proxies AI highlight requests to Supabase Edge Function or Tencent Cloud
// - Manages cloud sync

const DAY_KEY = () => new Date().toISOString().slice(0, 10);

// ==================== 智能路由配置 ====================
const TENCENT_CLOUD_URL = 'https://1341155583-eq60rqxiog.ap-shanghai.tencentscf.com';
const SUPABASE_EDGE_FUNCTION_URL = 'https://ebyavvysuogymwktidlx.supabase.co/functions/v1/ai-highlight';
const SUPABASE_TRANSLATE_URL = 'https://ebyavvysuogymwktidlx.supabase.co/functions/v1/translate';

// 地理位置检测缓存（24小时）
let geoCache = {
  region: null,
  timestamp: 0,
  ttl: 24 * 60 * 60 * 1000 // 24 hours (优化：用户地理位置不会频繁变化)
};

// 配额缓存（分层 TTL）- 月度配额
let quotaCache = {
  used: 0,
  total: 30, // 默认月度配额 30 次
  reset_at: null, // 下次重置时间（30 天后）
  timestamp: 0,
  ttl: 5 * 60 * 1000 // 默认 5 分钟
};

// 午夜自动失效定时器
let quotaResetTimer = null;
// 计算自适应 TTL（根据配额使用率）
function getAdaptiveTTL(used, total) {
  const ratio = used / (total || 1);
  if (ratio >= 1.0) return 5 * 1000;   // 100%: 5s (已超额)
  if (ratio >= 0.81) return 10 * 1000; // 81-99%: 10s (临界状态)
  if (ratio >= 0.51) return 20 * 1000; // 51-80%: 20s (接近上限)
  return 45 * 1000;                    // 0-50%: 45s (配额充足)
}

// 安排午夜自动失效
function scheduleQuotaReset(resetAt) {
  if (quotaResetTimer) clearTimeout(quotaResetTimer);
  if (!resetAt) return;
  
  try {
    const resetTime = new Date(resetAt).getTime();
    const now = Date.now();
    const delay = Math.max(0, resetTime - now);
    
    if (delay > 0 && delay < 24 * 60 * 60 * 1000) { // 在 24 小时内
      quotaResetTimer = setTimeout(() => {
        quotaCache.timestamp = 0;
      }, delay);
    }
  } catch (err) {
    console.error('[LeMingle] Failed to schedule quota reset:', err);
  }
}

/**
 * 检测用户所在地区
 * @returns {Promise<'china'|'global'>}
 */
async function detectUserRegion() {
  // 检查缓存
  const now = Date.now();
  if (geoCache.region && (now - geoCache.timestamp) < geoCache.ttl) {
    return geoCache.region;
  }

  try {
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);
    
    const resp = await fetch('https://ipapi.co/json/', {
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    if (!resp.ok) {
      throw new Error('IP detection failed');
    }
    
    const data = await resp.json();
    const region = data.country_code === 'CN' ? 'china' : 'global';
    
    // 更新缓存
    geoCache = {
      region,
      timestamp: now,
      ttl: geoCache.ttl
    };
    
    return region;
    
  } catch (error) {
    
    // 默认使用全球端点
    geoCache = {
      region: 'global',
      timestamp: now,
      ttl: 5 * 60 * 1000 // 失败后 5 分钟重试
    };
    
    return 'global';
  }
}

// Load sync managers using importScripts (Service Worker compatible)
try {
  importScripts('sync/syncManager.js');
} catch (error) {
  console.error('[Background] Failed to load sync managers:', error);
}

// Normalize and validate spans
function normalizeSpans(spans, inputText, allow, maxSpans) {
  const MAX_LEN = Math.min(5000, inputText.length);
  function clamp(n, min, max){ return Math.max(min, Math.min(max, n)); }

  spans = Array.isArray(spans) ? spans : [];
  // Basic field validation and clamping
  spans = spans.filter(s => s && typeof s.start==='number' && typeof s.end==='number');
  spans = spans.map(s => {
    let start = clamp(Math.floor(s.start), 0, MAX_LEN);
    let end = clamp(Math.floor(s.end), 0, MAX_LEN);
    if (end < start) { const tmp = start; start = end; end = tmp; }
    // trim overly long spans
    if (end - start > 220) { end = start + 220; }
    let phrase = typeof s.phrase === 'string' ? s.phrase : '';
    const slice = inputText.slice(start, end);
    if (!phrase || phrase !== slice) phrase = slice;
    let type = (s.type || '').toLowerCase();
    if (type !== 'collocation' && type !== 'idiom' && type !== 'connector' && type !== 'other') type = 'collocation';
    let meaning = typeof s.meaning === 'string' ? s.meaning : ''; // 保留 AI 返回的释义
    return { start, end, phrase, type, meaning };
  });
  // Filter disallowed types
  spans = spans.filter(s => !!allow[s.type]);
  // Sort by start asc, then longer first
  spans.sort((a,b)=> a.start - b.start || (b.end - b.start) - (a.end - a.start));
  // De-duplicate overlaps: keep earlier/longer
  const dedup = [];
  for (const s of spans) {
    if (!dedup.length) { dedup.push(s); continue; }
    const last = dedup[dedup.length-1];
    if (s.start < last.end) {
      // overlap: keep the one with larger length
      const lenLast = last.end - last.start;
      const lenS = s.end - s.start;
      if (lenS > lenLast) { dedup[dedup.length-1] = s; }
    } else {
      dedup.push(s);
    }
  }
  return dedup.slice(0, maxSpans);
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeBackgroundColor({ color: '#111' });
  chrome.storage.local.get(['lingolette_day', 'lingolette_count'], (res) => {
    const day = res.lingolette_day;
    if (day !== DAY_KEY()) {
      chrome.storage.local.set({ lingolette_day: DAY_KEY(), lingolette_count: 0 });
      chrome.action.setBadgeText({ text: '' });
    } else if (res.lingolette_count > 0) {
      const count = res.lingolette_count;
      // Only show badge for 1-5, hide for 6+
      if (count > 5) {
        chrome.action.setBadgeText({ text: '' });  // Hide badge
      } else {
        chrome.action.setBadgeText({ text: String(count) });
        chrome.action.setBadgeBackgroundColor({ color: '#111' });  // Dark gray
      }
    }
  });
  
  // Start session refresh timer
  startSessionRefreshTimer();
});

// Start session refresh timer on startup
chrome.runtime.onStartup.addListener(() => {
  startSessionRefreshTimer();
});

// Also start on extension install/update
chrome.runtime.onInstalled.addListener(() => {
  startSessionRefreshTimer();
});

// Auto-refresh session before expiry using chrome.alarms (more reliable than setTimeout)
function startSessionRefreshTimer() {
  chrome.storage.local.get(['lingolette_user_session'], async (result) => {
    const session = result.lingolette_user_session;
    
    if (!session || !session.expires_at) {
      // Clear any existing alarm if no session
      chrome.alarms.clear('sessionRefresh');
      return;
    }
    
    const expiresAt = session.expires_at * 1000; // Convert to milliseconds
    const now = Date.now();
    const timeUntilExpiry = expiresAt - now;
    
    // Refresh 5 minutes before expiry
    const refreshTime = timeUntilExpiry - (5 * 60 * 1000);
    
    if (refreshTime > 0) {
      // Use chrome.alarms instead of setTimeout (more reliable, survives Service Worker suspension)
      const delayInMinutes = refreshTime / (60 * 1000);
      chrome.alarms.create('sessionRefresh', {
        delayInMinutes: Math.max(0.1, delayInMinutes) // Minimum 0.1 minutes (6 seconds)
      });
    } else if (timeUntilExpiry > 0) {
      // Session expires soon, refresh immediately
      await refreshSessionInBackground();
      startSessionRefreshTimer();
    } else {
      // Session already expired
      chrome.storage.local.remove(['lingolette_user_session', 'lingolette_user_id', 'lingolette_user_email']);
      chrome.alarms.clear('sessionRefresh');
    }
  });
}

// Listen for alarm to refresh session
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'sessionRefresh') {
    await refreshSessionInBackground();
    // Schedule next refresh
    startSessionRefreshTimer();
  }
});

async function refreshSessionInBackground() {
  try {
    const result = await chrome.storage.local.get(['lingolette_user_session']);
    const session = result.lingolette_user_session;
    
    if (!session || !session.refresh_token) {
      return;
    }
    
    // Call Supabase refresh endpoint
    const response = await fetch('https://ebyavvysuogymwktidlx.supabase.co/auth/v1/token?grant_type=refresh_token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVieWF2dnlzdW9neW13a3RpZGx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwMjYzMTUsImV4cCI6MjA3NTYwMjMxNX0.W7stnpPBlPxHy3RH7aWA0DSo7iI7lzsgY-i5tKWHyIw'
      },
      body: JSON.stringify({
        refresh_token: session.refresh_token
      })
    });
    
    if (response.ok) {
      const data = await response.json();
      if (data.access_token) {
        const newSession = {
          access_token: data.access_token,
          refresh_token: data.refresh_token,
          expires_at: data.expires_at,
          expires_in: data.expires_in,
          token_type: data.token_type,
          user: data.user
        };
        
        await chrome.storage.local.set({
          lingolette_user_session: newSession,
          lingolette_user_id: data.user.id,
          lingolette_user_email: data.user.email
        });
        
      }
    } else {
      console.error('[Background] Failed to refresh session:', response.status);
      // Clear invalid session
      chrome.storage.local.remove(['lingolette_user_session', 'lingolette_user_id', 'lingolette_user_email']);
    }
  } catch (error) {
    console.error('[Background] Error refreshing session:', error);
  }
}

// Listen for user login to trigger sync
chrome.storage.onChanged.addListener(async (changes, areaName) => {
  if (areaName === 'local' && changes.lingolette_user_session) {
    const newSession = changes.lingolette_user_session.newValue;
    const oldSession = changes.lingolette_user_session.oldValue;
    
    // User just logged in or session updated
    if (newSession && !oldSession) {
      
      // Sync profile and items (syncManager.js is already loaded)
      if (typeof syncOnLogin === 'function') {
        await syncOnLogin();
      }
      
      
      // Start session refresh timer
      startSessionRefreshTimer();
    } else if (newSession && oldSession) {
      // Session was refreshed, restart timer
      startSessionRefreshTimer();
    } else if (!newSession && oldSession) {
      // User logged out
      chrome.alarms.clear('sessionRefresh');
    }
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Handle user logout
  if (msg?.type === 'USER_LOGGED_OUT') {
    
    // Clear quota cache
    quotaCache = {
      used: 0,
      total: 30,
      reset_at: null,
      timestamp: 0,
      ttl: 5 * 60 * 1000
    };
    
    // Clear geo cache (optional, but good for privacy)
    geoCache = {
      region: null,
      timestamp: 0,
      ttl: 24 * 60 * 60 * 1000
    };
    
    // Stop session refresh timer
    if (sessionRefreshTimer) {
      clearTimeout(sessionRefreshTimer);
      sessionRefreshTimer = null;
    }
    
    // Clear quota reset timer
    if (quotaResetTimer) {
      clearTimeout(quotaResetTimer);
      quotaResetTimer = null;
    }
    
    sendResponse({ ok: true });
    return true;
  }
  
  if (msg?.type === 'LINGOLETTE_SAVED_ITEM') {
    // Increment daily count; show firework emoji when > 5
    chrome.storage.local.get(['lingolette_day', 'lingolette_count'], (res) => {
      const today = DAY_KEY();
      let count = res.lingolette_count || 0;
      let day = res.lingolette_day;
      if (day !== today) {
        day = today;
        count = 0;
      }
      count = count + 1;  // No limit on internal count
      
      chrome.storage.local.set({ lingolette_day: day, lingolette_count: count }, () => {
        // Only show badge for 1-5, hide for 6+
        if (count > 5) {
          chrome.action.setBadgeText({ text: '' });  // Hide badge
        } else {
          chrome.action.setBadgeText({ text: String(count) });
          chrome.action.setBadgeBackgroundColor({ color: '#111' });  // Dark gray
        }
        
        if (count === 5) {
          // Flash gold when hitting 5
          chrome.action.setBadgeBackgroundColor({ color: '#FFD700' });
          setTimeout(() => chrome.action.setBadgeBackgroundColor({ color: '#111' }), 700);
          
          // Trigger confetti in all content scripts (on the page)
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
              chrome.tabs.sendMessage(tabs[0].id, { type: 'TRIGGER_CONFETTI' }).catch(() => {
                // Content script might not be ready, that's okay
              });
            }
          });
        }
      });
    });
    sendResponse({ ok: true });
    return true;
  }
  
  // Handle batch sync add
  if (msg?.type === 'LINGOLETTE_BATCH_SYNC_ADD') {
    if (typeof addItemToSyncQueue === 'function') {
      addItemToSyncQueue(msg.payload);
    }
    sendResponse({ ok: true });
    return true;
  }
  
  // Handle batch sync delete
  if (msg?.type === 'LINGOLETTE_BATCH_SYNC_DELETE') {
    if (typeof deleteItemFromSyncQueue === 'function') {
      deleteItemFromSyncQueue(msg.payload);
    }
    sendResponse({ ok: true });
    return true;
  }
  
  // Handle profile sync
  if (msg?.type === 'LINGOLETTE_PROFILE_SYNC') {
    if (typeof syncProfile === 'function') {
      syncProfile(msg.payload);
    }
    sendResponse({ ok: true });
    return true;
  }

  // Handle get quota cache request (from Popup)
  if (msg?.type === 'GET_QUOTA_CACHE') {
    sendResponse({ quota: quotaCache });
    return true;
  }

  // Handle translate request
  if (msg?.type === 'LINGOLETTE_TRANSLATE') {
    (async () => {
      try {
        const { text } = msg.payload || {};
        
        if (!text || text.length === 0) {
          sendResponse({ ok: false, error: 'Text is required' });
          return;
        }

        // Get session from local storage
        const localCfg = await chrome.storage.local.get(['lingolette_user_session', 'lingolette_user_id']);
        let session = localCfg.lingolette_user_session;
        const userId = localCfg.lingolette_user_id;
        
        // Get user language settings from sync storage
        const syncCfg = await chrome.storage.sync.get([
          'lingolette_explanation_lang',
          'lingolette_target_languages'
        ]);
        
        if (!session?.access_token) {
          sendResponse({ ok: false, error: 'NOT_LOGGED_IN', message: 'Please login to use translation' });
          return;
        }

        // 检查配额缓存
        const nowMs = Date.now();
        if (quotaCache.timestamp && (nowMs - quotaCache.timestamp) < quotaCache.ttl) {
          
          // 客户端配额检查
          if (quotaCache.used >= quotaCache.total) {
            sendResponse({ 
              ok: false, 
              error: 'MONTHLY_QUOTA_EXCEEDED',
              message: 'Monthly AI quota exceeded. Please upgrade your plan.',
              quota: {
                used: quotaCache.used,
                total: quotaCache.total
              }
            });
            return;
          }
        }

        // 预刷新 Token
        const expiresAt = session.expires_at || 0;
        const now = Math.floor(Date.now() / 1000);
        const timeUntilExpiry = expiresAt - now;

        if (timeUntilExpiry < 600 && timeUntilExpiry > 60 && session.refresh_token) {
          
          fetch('https://ebyavvysuogymwktidlx.supabase.co/auth/v1/token?grant_type=refresh_token', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVieWF2dnlzdW9neW13a3RpZGx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzM3MzY3MTUsImV4cCI6MjA0OTMxMjcxNX0.Jx2Xz1TQYwZCnLxOxjJVLwYjJqTLSLGPOXlmW_Xvqxw' },
            body: JSON.stringify({ refresh_token: session.refresh_token })
          })
            .then(resp => resp.ok ? resp.json() : null)
            .then(newSession => {
              if (newSession) {
                chrome.storage.local.set({ lingolette_user_session: newSession });
              }
            })
            .catch(err => console.error('[LeMingle] Background token refresh failed:', err));
        }

        // 智能路由：选择最优 API endpoint
        const region = await detectUserRegion();
        
        // 目前翻译只使用 Supabase（未来可以添加腾讯云翻译）
        const endpoint = SUPABASE_TRANSLATE_URL;

        const startTime = Date.now();
        
        const resp = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            text,
            context: msg.payload.context, // 传递句子上下文
            userId, // 优化：传递 userId，跳过 getUser() 调用
            targetLanguages: syncCfg.lingolette_target_languages || ['en'],
            explanationLang: syncCfg.lingolette_explanation_lang || 'zh-simplified'
          })
        });

        const elapsed = Date.now() - startTime;

        if (resp.status === 429) {
          const errorData = await resp.json();
          // 更新缓存（超额状态）
          if (errorData.quota) {
            quotaCache = {
              used: errorData.quota.used,
              total: errorData.quota.total,
              reset_at: errorData.quota.reset_at,
              timestamp: Date.now(),
              ttl: 5 * 1000 // 超额后缩短为 5s
            };
            if (errorData.quota.reset_at) {
              scheduleQuotaReset(errorData.quota.reset_at);
            }
          }
          sendResponse({ 
            ok: false, 
            error: 'QUOTA_EXCEEDED',
            message: errorData.message || 'Daily quota exceeded',
            quota: errorData.quota
          });
          return;
        }

        if (!resp.ok) {
          throw new Error(`API error: ${resp.status}`);
        }

        const data = await resp.json();
        
        // 更新配额缓存
        if (data.quota) {
          quotaCache = {
            used: data.quota.used,
            total: data.quota.total,
            reset_at: data.quota.reset_at,
            timestamp: Date.now(),
            ttl: getAdaptiveTTL(data.quota.used, data.quota.total)
          };
          
          // 安排午夜自动失效
          if (data.quota.reset_at) {
            scheduleQuotaReset(data.quota.reset_at);
          }
          
          // 通知 Popup 更新配额显示
          chrome.runtime.sendMessage({
            type: 'QUOTA_UPDATED',
            quota: {
              used: data.quota.used,
              total: data.quota.total
            }
          }).catch(() => {
            // Popup 可能未打开，忽略错误
          });
        }
        
        sendResponse({ 
          ok: true, 
          translation: data.translation,
          quota: data.quota
        });

      } catch (err) {
        console.error('[LeMingle] Translation error:', err);
        sendResponse({ ok: false, error: err.message || 'Translation failed' });
      }
    })();
    return true;
  }

  if (msg?.type === 'LINGOLETTE_AI_HIGHLIGHT') {
    (async () => {
      try {
        const { text, mode, categories, language } = msg.payload || {};
        const inputText = text?.slice(0, 5000) || '';

        // Get session from local storage
        const localCfg = await chrome.storage.local.get(['lingolette_user_session']);
        let session = localCfg.lingolette_user_session;
        
        // Get user settings from sync storage
        const syncCfg = await chrome.storage.sync.get([
          'lingolette_explanation_lang',
          'lingolette_target_languages',
          'lingolette_learner_level',
          'lingolette_learner_goal',
          'lingolette_learner_weak_area'
        ]);
        
        if (!session?.access_token) {
          sendResponse({ ok: false, error: 'NOT_LOGGED_IN', message: 'Please login to use AI highlighting' });
          return;
        }

        // 检查配额缓存（优化：避免每次查询数据库）
        const nowMs = Date.now();
        if (quotaCache.timestamp && (nowMs - quotaCache.timestamp) < quotaCache.ttl) {
          
          // 客户端配额检查
          if (quotaCache.used >= quotaCache.total) {
            sendResponse({ 
              ok: false, 
              error: 'MONTHLY_QUOTA_EXCEEDED',
              message: 'Monthly AI quota exceeded. Please upgrade your plan.',
              quota: {
                used: quotaCache.used,
                total: quotaCache.total
              }
            });
            return;
          }
        }

        // 优化：预刷新 Token（提前 10 分钟异步刷新，避免阻塞）
        const expiresAt = session.expires_at || 0;
        const now = Math.floor(Date.now() / 1000);
        const timeUntilExpiry = expiresAt - now;

        // 如果 Token 在 10 分钟内过期，后台异步刷新（不阻塞）
        if (timeUntilExpiry < 600 && timeUntilExpiry > 60 && session.refresh_token) {
          
          // 异步刷新，不等待
          fetch('https://ebyavvysuogymwktidlx.supabase.co/auth/v1/token?grant_type=refresh_token', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVieWF2dnlzdW9neW13a3RpZGx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwMjYzMTUsImV4cCI6MjA3NTYwMjMxNX0.W7stnpPBlPxHy3RH7aWA0DSo7iI7lzsgY-i5tKWHyIw'
            },
            body: JSON.stringify({ refresh_token: session.refresh_token })
          })
          .then(resp => resp.ok ? resp.json() : null)
          .then(newSession => {
            if (newSession) {
              chrome.storage.local.set({ lingolette_user_session: newSession });
            }
          })
          .catch(err => console.error('[LeMingle] Background token refresh failed:', err));
        }

        // 只有真正过期（1 分钟内）才阻塞刷新
        if (timeUntilExpiry < 60 && session.refresh_token) {
          try {
            const refreshResp = await fetch('https://ebyavvysuogymwktidlx.supabase.co/auth/v1/token?grant_type=refresh_token', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVieWF2dnlzdW9neW13a3RpZGx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwMjYzMTUsImV4cCI6MjA3NTYwMjMxNX0.W7stnpPBlPxHy3RH7aWA0DSo7iI7lzsgY-i5tKWHyIw'
              },
              body: JSON.stringify({ refresh_token: session.refresh_token })
            });
            if (refreshResp.ok) {
              session = await refreshResp.json();
              await chrome.storage.local.set({ lingolette_user_session: session });
            }
          } catch (err) {
            console.error('[LeMingle] Token refresh failed:', err);
          }
        }

        const lang = language || 'en';
        const learnerProfile = {
          level: syncCfg.lingolette_learner_level || 'intermediate',
          goal: syncCfg.lingolette_learner_goal || 'professional',
          weakArea: syncCfg.lingolette_learner_weak_area || 'speaking',
          targetLanguages: syncCfg.lingolette_target_languages || ['en'],
          explanationLang: syncCfg.lingolette_explanation_lang || 'zh-simplified'
        };

          mode,
          categories,
          language: lang,
          learnerProfile
        });

        // 检测用户地区并选择 API 端点
        const region = await detectUserRegion();
        const primaryUrl = region === 'china' ? TENCENT_CLOUD_URL : SUPABASE_EDGE_FUNCTION_URL;
        const fallbackUrl = region === 'china' ? SUPABASE_EDGE_FUNCTION_URL : null;
        

        const requestOptions = {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.access_token}`
          },
          body: JSON.stringify({
            text: inputText,
            mode,
            categories,
            language: lang,
            learnerProfile,
            userId: session.user.id // 优化：传递 user_id，服务端可跳过 getUser() 调用
          })
        };

        const controller = new AbortController();
        const tid = setTimeout(() => controller.abort(), 65000); // 65s (increased from 60s to avoid premature abort)
        requestOptions.signal = controller.signal;

        let resp;
        try {
          // 尝试主端点
          const startTime = Date.now();
          resp = await fetch(primaryUrl, requestOptions);
          const duration = Date.now() - startTime;
          
          // 如果主端点失败且有降级端点，尝试降级
          if (!resp.ok && fallbackUrl && resp.status !== 429 && resp.status !== 401) {
            resp = await fetch(fallbackUrl, requestOptions);
          }
        } catch (error) {
          console.error('[LeMingle] Primary endpoint error:', error.message);
          // 如果有降级端点，尝试降级
          if (fallbackUrl) {
            resp = await fetch(fallbackUrl, requestOptions);
          } else {
            throw error;
          }
        }

        clearTimeout(tid);

        if (!resp.ok) {
          const errorData = await resp.json().catch(() => ({}));
          
          if (resp.status === 429) {
            // 更新缓存（超额状态）
            if (errorData.quota) {
              quotaCache = {
                used: errorData.quota.used,
                total: errorData.quota.total,
                reset_at: errorData.quota.reset_at,
                timestamp: Date.now(),
                ttl: 5 * 1000 // 超额后缩短为 5s
              };
              if (errorData.quota.reset_at) {
                scheduleQuotaReset(errorData.quota.reset_at);
              }
            }
            sendResponse({ 
              ok: false, 
              error: 'QUOTA_EXCEEDED',
              message: errorData.message || 'Daily quota exceeded',
              quota: errorData.quota
            });
            return;
          }
          
          sendResponse({ ok: false, error: `HTTP ${resp.status}`, message: errorData.error });
          return;
        }

        const data = await resp.json();
        
        // 更新配额缓存
        if (data.quota) {
          quotaCache = {
            used: data.quota.used,
            total: data.quota.total,
            reset_at: data.quota.reset_at,
            timestamp: Date.now(),
            ttl: getAdaptiveTTL(data.quota.used, data.quota.total)
          };
          
          // 安排午夜自动失效
          if (data.quota.reset_at) {
            scheduleQuotaReset(data.quota.reset_at);
          }
          
          // 通知 Popup 更新配额显示
          chrome.runtime.sendMessage({
            type: 'QUOTA_UPDATED',
            quota: {
              used: data.quota.used,
              total: data.quota.total
            }
          }).catch(() => {
            // Popup 可能未打开，忽略错误
          });
        }
        
        // Convert items to spans
        const items = data.items || [];
        const spans = [];
        const lowered = inputText.toLowerCase();
        for (const item of items) {
          const phrase = item.phrase;
          if (!phrase) continue;
          const idx = lowered.indexOf(phrase.toLowerCase());
          if (idx !== -1) {
            spans.push({
              start: idx,
              end: idx + phrase.length,
              phrase: inputText.slice(idx, idx + phrase.length),
              type: item.type || 'collocation',
              meaning: item.meaning || ''
            });
          }
        }
        
        const allow = categories || { collocation: true, idiom: true, connector: true };
        const densityRatio = mode === 'lite' ? 0.005 : mode === 'detailed' ? 0.015 : 0.01;
        const maxSpans = Math.max(3, Math.min(25, Math.floor(inputText.length * densityRatio)));
        const normalized = normalizeSpans(spans, inputText, allow, maxSpans);
        
        sendResponse({ 
          ok: true, 
          spans: normalized,
          quota: data.quota
        });

      } catch (err) {
        console.error('[LeMingle] Edge Function error:', err);
        sendResponse({ ok: false, error: err.message || 'TIMEOUT' });
      }
    })();
    return true; // async
  }
});
