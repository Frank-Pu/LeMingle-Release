// Lingolette Options Page Script

// Initialize i18n
(async function() {
  await initI18n();
  updateAllTexts();
})();

// Update all UI texts
function updateAllTexts() {
  // Use the standard i18n update function to handle all data-i18n attributes
  updatePageTranslations();
}

// Learning mode & categories
const modeRadios = Array.from(document.querySelectorAll('input[name="mode"]'));
const catCollocation = document.getElementById('cat-collocation');
const catIdiom = document.getElementById('cat-idiom');
const catConnector = document.getElementById('cat-connector');
const prefsStatus = document.getElementById('prefsStatus');

function setModeUI(mode){
  for (const r of modeRadios) r.checked = r.value === (mode || 'standard');
}

chrome.storage.sync.get(['lingolette_mode','lingolette_categories'], (r) => {
  setModeUI(r.lingolette_mode || 'standard');
  const cat = r.lingolette_categories || { collocation: true, idiom: true, connector: true };
  catCollocation.checked = cat.collocation !== false;
  catIdiom.checked = cat.idiom !== false;
  catConnector.checked = cat.connector !== false;
});

document.getElementById('savePrefs').addEventListener('click', () => {
  const mode = (modeRadios.find(r => r.checked) || {}).value || 'standard';
  const categories = {
    collocation: !!catCollocation.checked,
    idiom: !!catIdiom.checked,
    connector: !!catConnector.checked,
  };
  chrome.storage.sync.set({ lingolette_mode: mode, lingolette_categories: categories }, () => {
    prefsStatus.textContent = t('options.savedPrefsSuccess');
    prefsStatus.className = 'hint ok';
    setTimeout(() => prefsStatus.textContent = '', 1200);
    
    // Trigger cloud sync
    chrome.runtime.sendMessage({
      type: 'LINGOLETTE_PROFILE_SYNC',
      payload: { learning_mode: mode, focus_categories: categories }
    }).catch(() => {});
  });
});

// Learner profile controls
const learnerLevel = document.getElementById('learner-level');
const learnerGoal = document.getElementById('learner-goal');
const learnerWeakArea = document.getElementById('learner-weak-area');
const targetLanguage = document.getElementById('target-language');
const explanationLang = document.getElementById('explanation-lang');
const learnerProfileStatus = document.getElementById('learnerProfileStatus');

// Load saved settings
chrome.storage.sync.get([
  'lingolette_learner_level',
  'lingolette_learner_goal',
  'lingolette_learner_weak_area',
  'lingolette_target_language',
  'lingolette_explanation_lang'
], (r) => {
  learnerLevel.value = r.lingolette_learner_level || 'intermediate';
  learnerGoal.value = r.lingolette_learner_goal || 'professional';
  learnerWeakArea.value = r.lingolette_learner_weak_area || 'speaking';
  targetLanguage.value = r.lingolette_target_language || 'en';
  explanationLang.value = r.lingolette_explanation_lang || 'zh-simplified';
});

document.getElementById('saveLearnerProfile').addEventListener('click', () => {
  const profile = {
    learner_level: learnerLevel.value,
    learner_goal: learnerGoal.value,
    learner_weak_area: learnerWeakArea.value,
    target_language: targetLanguage.value,
    explanation_lang: explanationLang.value
  };
  
  chrome.storage.sync.set({
    lingolette_learner_level: profile.learner_level,
    lingolette_learner_goal: profile.learner_goal,
    lingolette_learner_weak_area: profile.learner_weak_area,
    lingolette_target_language: profile.target_language,
    lingolette_explanation_lang: profile.explanation_lang,
  }, () => {
    learnerProfileStatus.textContent = t('options.savedProfileSuccess');
    learnerProfileStatus.className = 'status success';
    setTimeout(() => learnerProfileStatus.textContent = '', 1200);
    
    // Trigger cloud sync
    chrome.runtime.sendMessage({
      type: 'LINGOLETTE_PROFILE_SYNC',
      payload: profile
    }).catch(() => {});
  });
});

// UI Language controls
const uiLanguageRadios = Array.from(document.querySelectorAll('input[name="ui-language"]'));
const uiLanguageStatus = document.getElementById('uiLanguageStatus');

// Load saved UI language
chrome.storage.sync.get(['lingolette_ui_language'], (r) => {
  const savedLang = r.lingolette_ui_language || (navigator.language.startsWith('zh') ? 'zh-CN' : 'en');
  for (const radio of uiLanguageRadios) {
    radio.checked = radio.value === savedLang;
  }
});

document.getElementById('saveUILanguage').addEventListener('click', () => {
  const selectedLang = (uiLanguageRadios.find(r => r.checked) || {}).value || 'zh-CN';
  
  chrome.storage.sync.set({ lingolette_ui_language: selectedLang }, () => {
    uiLanguageStatus.textContent = t('options.saved');
    uiLanguageStatus.className = 'status success';
    
    // Reload page to apply new language
    setTimeout(() => {
      window.location.reload();
    }, 500);
  });
});
