// Lingolette Popup: list, delete, export, refresh

// Initialize i18n
let UI_LANG = 'zh-CN';
let i18nReady = false;
(async function() {
  UI_LANG = await initI18n();
  updateUITexts();
  i18nReady = true;
})();

// Supabase configuration
const SUPABASE_URL = 'https://ebyavvysuogymwktidlx.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVieWF2dnlzdW9neW13a3RpZGx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwMjYzMTUsImV4cCI6MjA3NTYwMjMxNX0.W7stnpPBlPxHy3RH7aWA0DSo7iI7lzsgY-i5tKWHyIw';

let supabase = null;

function formatDate(ts){
  try {
    if (!ts) return '';
    const now = new Date();
    const date = new Date(ts);
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    const lang = window.CURRENT_UI_LANG || UI_LANG || 'zh-CN';
    const isEnglish = lang === 'en';
    
    // 今天：显示时间
    if (diffDays === 0) {
      return date.toLocaleTimeString(isEnglish ? 'en-US' : 'zh-CN', { hour: '2-digit', minute: '2-digit' });
    }
    
    // 昨天
    if (diffDays === 1) {
      return t('popup.yesterday');
    }
    
    // 本周内：显示星期
    if (diffDays < 7) {
      const weekdays = t('popup.weekdays');
      return weekdays[date.getDay()];
    }
    
    // 上周
    if (diffDays < 14) {
      const weekdays = t('popup.weekdays');
      return t('popup.lastWeek') + weekdays[date.getDay()];
    }
    
    // 本月内：显示日期
    if (now.getMonth() === date.getMonth() && now.getFullYear() === date.getFullYear()) {
      if (isEnglish) {
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      }
      return `${date.getMonth() + 1}月${date.getDate()}日`;
    }
    
    // 本年内：显示月日
    if (now.getFullYear() === date.getFullYear()) {
      if (isEnglish) {
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      }
      return `${date.getMonth() + 1}月${date.getDate()}日`;
    }
    
    // 6个月内：显示"X个月前"
    const diffMonths = (now.getFullYear() - date.getFullYear()) * 12 + (now.getMonth() - date.getMonth());
    if (diffMonths < 6) {
      if (isEnglish) {
        return `${diffMonths}${t('popup.monthsAgo')}`;
      }
      return `${diffMonths}${t('popup.monthsAgo')}`;
    }
    
    // 更早：显示年月
    if (isEnglish) {
      return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
    }
    return `${date.getFullYear()}年${date.getMonth() + 1}月`;
  } catch { 
    return '' 
  }
}

function speak(text) {
  if ('speechSynthesis' in window) {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = 0.9;
    speechSynthesis.speak(utterance);
  }
}

function render(items){
  const list = document.getElementById('list');
  const empty = document.getElementById('empty');
  list.innerHTML = '';
  if (!items || !items.length){
    empty.style.display = 'block';
    return;
  }
  empty.style.display = 'none';
  for (const [idx, it] of items.entries()){
    const div = document.createElement('div');
    div.className = 'item';
    
    // Text
    const textRow = document.createElement('div');
    textRow.className = 'item-text';
    textRow.textContent = it.text;
    div.appendChild(textRow);
    
    // Meaning (always show if exists)
    if (it.meaning && it.meaning.trim()) {
      const meaningDiv = document.createElement('div');
      meaningDiv.className = 'item-meaning';
      meaningDiv.textContent = it.meaning;
      div.appendChild(meaningDiv);
    }
    
    // Meta row with actions
    const meta = document.createElement('div');
    meta.className = 'item-meta';
    
    const tag = document.createElement('span');
    tag.className = 'tag';
    // Translate tag type
    const tagType = it.type || 'phrase';
    if (tagType === 'collocation') {
      tag.textContent = t('popup.tagCollocation');
    } else if (tagType === 'idiom') {
      tag.textContent = t('popup.tagIdiom');
    } else if (tagType === 'connector') {
      tag.textContent = t('popup.tagConnector');
    } else {
      tag.textContent = tagType;
    }
    meta.appendChild(tag);
    
    const time = document.createElement('span');
    time.textContent = formatDate(it.ts);
    meta.appendChild(time);
    
    const a = document.createElement('a');
    a.href = it.url;
    a.textContent = t('popup.source');
    a.className = 'item-link';
    a.target = '_blank';
    meta.appendChild(a);
    
    // TTS button
    const ttsBtn = document.createElement('button');
    ttsBtn.textContent = '🔊';
    ttsBtn.className = 'btn-icon';
    ttsBtn.title = t('popup.pronounce');
    ttsBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      speak(it.text);
    });
    meta.appendChild(ttsBtn);
    
    // Delete button
    const del = document.createElement('button');
    del.textContent = '🗑️';
    del.className = 'btn-icon';
    del.title = t('popup.delete');
    del.addEventListener('click', async () => {
      const items = await getItems();
      const itemToRemove = items[idx]; // Save full item before removing
      const removedPhrase = itemToRemove.text;
      
      items.splice(idx, 1);
      await setItems(items);
      
      // Trigger cloud sync deletion if cloudId exists
      if (itemToRemove.cloudId) {
        chrome.runtime.sendMessage({
          type: 'LINGOLETTE_BATCH_SYNC_DELETE',
          payload: itemToRemove.cloudId
        }).catch(() => {
          // Ignore if background script is not ready
        });
      }
      
      // Notify all tabs to remove the highlight
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, {
            type: 'COLLECTION_ITEM_REMOVED',
            phrase: removedPhrase
          }).catch(() => {}); // Ignore errors for tabs without content script
        });
      });
      
      load();
    });
    meta.appendChild(del);

    div.appendChild(meta);
    list.appendChild(div);
  }
}

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'}[c]));
}

function getItems(){
  return new Promise(res=>{
    chrome.storage.local.get(['lingolette_items'], r => res(r.lingolette_items || []));
  });
}
function setItems(items){
  return new Promise(res=>{
    chrome.storage.local.set({ lingolette_items: items }, () => res(true));
  });
}

async function load(){
  const items = await getItems();
  render(items);
}

function formatLocalDateTime(ts) {
  if (!ts) return '';
  const date = new Date(ts);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

function exportCSV(rows){
  const lines = ['text,type,meaning,title,url,time'];
  for (const r of rows){
    const timeStr = r.ts ? formatLocalDateTime(r.ts) : '';
    const cols = [
      r.text || '',
      r.type || '',
      r.meaning || '',
      r.title || '',
      r.url || '',
      timeStr
    ].map(v => '"' + String(v).replace(/"/g,'""') + '"');
    lines.push(cols.join(','));
  }
  const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const now = new Date();
  const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  a.download = `LeMingle_${dateStr}.csv`;
  a.click();
  setTimeout(()=>URL.revokeObjectURL(url), 1000);
}

// Load Supabase SDK from local file
async function loadSupabaseSDK() {
  if (window.supabase) return;
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('supabase.js');
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

// Check user authentication status
async function checkAuthStatus() {
  const loggedOutState = document.getElementById('loggedOutState');
  const loggedInState = document.getElementById('loggedInState');
  
  try {
    // CRITICAL FIX: Check chrome.storage.local (same source as background.js)
    // This ensures popup and background use the same session data
    const localData = await chrome.storage.local.get(['lingolette_user_session']);
    const storedSession = localData.lingolette_user_session;
    
    // Validate stored session
    if (storedSession && storedSession.access_token) {
      // Check if token is expired or expiring soon
      const expiresAt = storedSession.expires_at || 0;
      const now = Math.floor(Date.now() / 1000);
      const expiresInSeconds = expiresAt - now;
      
      // If token expires within 10 minutes or already expired, try to refresh
      if (expiresInSeconds < 600) {
        const refreshed = await refreshSessionInPopup(storedSession);
        
        if (refreshed) {
          // Use the new session
          const newData = await chrome.storage.local.get(['lingolette_user_session']);
          storedSession = newData.lingolette_user_session;
        } else {
          // Refresh failed - clear session and show logged out state
          await chrome.storage.local.remove(['lingolette_user_session', 'lingolette_user_id', 'lingolette_user_email']);
          loggedOutState.style.display = 'block';
          loggedInState.style.display = 'none';
          return;
        }
      }
      
      // Session is valid - show logged in state
      loggedOutState.style.display = 'none';
      loggedInState.style.display = 'block';
      
      // Update user info
      const userEmail = storedSession.user?.email || 'User';
      document.getElementById('userName').textContent = userEmail;
      
      // Load Supabase SDK for profile fetching
      await loadSupabaseSDK();
      supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
        auth: {
          persistSession: false,
          autoRefreshToken: false
        }
      });
      
      // Set the session for authenticated requests
      await supabase.auth.setSession({
        access_token: storedSession.access_token,
        refresh_token: storedSession.refresh_token
      });
      
      
      // Fetch user profile
      const userId = storedSession.user?.id;
      if (userId) {
        const { data: profile, error: profileError } = await supabase
          .from('user_profiles')
          .select('*')
          .eq('id', userId)
          .single();
        
        if (profileError) {
          console.error('[Popup] Profile fetch error:', profileError);
          console.error('[Popup] Error details:', {
            code: profileError.code,
            message: profileError.message,
            details: profileError.details,
            hint: profileError.hint
          });
          // Show error in UI
          document.getElementById('userTier').textContent = 'Error: ' + profileError.message;
          document.getElementById('quotaText').textContent = '无法加载配额';
          return;
        }
        
        if (profile) {
            subscription_tier: profile.subscription_tier,
            monthly_ai_used: profile.monthly_ai_used,
            monthly_ai_quota: profile.monthly_ai_quota
          });
          const tierText = profile.subscription_tier === 'free' ? t('popup.freeTier') : 
                          profile.subscription_tier === 'pro' ? t('popup.proTier') : t('popup.teamTier');
          document.getElementById('userTier').textContent = tierText;
          
          // Update monthly quota - 始终使用数据库的最新配额
          const used = profile.monthly_ai_used || 0;
          const total = profile.monthly_ai_quota || 30; // 默认月度配额 30 次
          const percentage = (used / total) * 100;
          
          const quotaText = t('popup.quotaMonthly', { used, total });
            used,
            total,
            percentage: percentage.toFixed(1) + '%',
            translatedText: quotaText,
            UI_LANG,
            i18nReady
          });
          
          document.getElementById('quotaFill').style.width = `${percentage}%`;
          document.getElementById('quotaText').textContent = quotaText;
          
          // Show upgrade prompt for free users at 75% usage
          const tier = profile.subscription_tier || 'free';
          if (tier === 'free') {
            showUpgradePrompt(used, total, percentage);
          }
          
          // Show upgrade button for free users OR subscription info for paid users
          if (profile.subscription_tier === 'free') {
            document.getElementById('btnUpgrade').style.display = 'block';
          } else if (profile.subscription_tier === 'pro' || profile.subscription_tier === 'team') {
            // Show subscription management for paid users
            displaySubscriptionInfo(profile);
          }
        } else {
          // Profile is null but no error - user profile doesn't exist in database
          document.getElementById('userTier').textContent = 'Profile not found';
          document.getElementById('quotaText').textContent = '请联系支持';
        }
      }
      return; // Exit early - user is logged in
    }
    
    // If we reach here, user is not logged in or session is invalid
    loggedOutState.style.display = 'block';
    loggedInState.style.display = 'none';
    
  } catch (error) {
    console.error('[Popup] Auth check failed:', error);
    loggedOutState.style.display = 'block';
    loggedInState.style.display = 'none';
  }
}

// Refresh session in popup (when token is expiring or expired)
async function refreshSessionInPopup(oldSession) {
  if (!oldSession || !oldSession.refresh_token) {
    return false;
  }
  
  try {
    // Load Supabase SDK if not already loaded
    if (!window.supabase) {
      await loadSupabaseSDK();
    }
    
    // Create a temporary Supabase client for refreshing
    const tempSupabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: {
        persistSession: false,
        autoRefreshToken: false
      }
    });
    
    // Refresh session using Supabase SDK
    const { data, error } = await tempSupabase.auth.refreshSession({
      refresh_token: oldSession.refresh_token
    });
    
    if (error) throw error;
    
    if (data.session) {
      // Save new session to chrome.storage.local
      await chrome.storage.local.set({
        lingolette_user_session: data.session,
        lingolette_user_id: data.session.user.id,
        lingolette_user_email: data.session.user.email
      });
      
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('[Popup] Failed to refresh session:', error);
    return false;
  }
}

// Confetti animation function
function triggerConfetti() {
  const duration = 2000; // 2 seconds
  const animationEnd = Date.now() + duration;
  const colors = ['#FFD700', '#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8'];
  
  function randomInRange(min, max) {
    return Math.random() * (max - min) + min;
  }
  
  const interval = setInterval(() => {
    const timeLeft = animationEnd - Date.now();
    
    if (timeLeft <= 0) {
      clearInterval(interval);
      return;
    }
    
    const particleCount = 3;
    
    for (let i = 0; i < particleCount; i++) {
      const particle = document.createElement('div');
      particle.className = 'confetti-particle';
      particle.style.cssText = `
        position: fixed;
        width: 8px;
        height: 8px;
        background-color: ${colors[Math.floor(Math.random() * colors.length)]};
        left: ${randomInRange(0, 100)}%;
        top: -10px;
        border-radius: ${Math.random() > 0.5 ? '50%' : '0'};
        pointer-events: none;
        z-index: 10000;
        animation: confetti-fall ${randomInRange(1, 2)}s linear forwards;
      `;
      
      document.body.appendChild(particle);
      
      setTimeout(() => {
        particle.remove();
      }, 2000);
    }
  }, 50);
  
  // Add CSS animation if not exists
  if (!document.getElementById('confetti-style')) {
    const style = document.createElement('style');
    style.id = 'confetti-style';
    style.textContent = `
      @keyframes confetti-fall {
        0% {
          transform: translateY(0) rotate(0deg);
          opacity: 1;
        }
        100% {
          transform: translateY(400px) rotate(${randomInRange(0, 360)}deg);
          opacity: 0;
        }
      }
    `;
    document.head.appendChild(style);
  }
  
}

// Listen for quota updates and confetti trigger from background
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'QUOTA_UPDATED' && msg.quota) {
    
    // Update quota display
    const used = msg.quota.used;
    const total = msg.quota.total;
    const percentage = (used / total) * 100;
    
    const quotaFill = document.getElementById('quotaFill');
    const quotaText = document.getElementById('quotaText');
    
    if (quotaFill && quotaText) {
      const translatedText = t('popup.quotaMonthly', { used, total });
        used,
        total,
        percentage: percentage.toFixed(1) + '%',
        translatedText,
        UI_LANG
      });
      quotaFill.style.width = `${percentage}%`;
      quotaText.textContent = translatedText;
    }
  }
  
  // Trigger confetti when user reaches 5 saved items
  if (msg.type === 'TRIGGER_CONFETTI') {
    triggerConfetti();
  }
});

// Handle logout
async function handleLogout() {
  if (!supabase) return;
  
  
  // 1. Sign out from Supabase
  await supabase.auth.signOut();
  
  // 2. Clear all user-related data from local storage
  await chrome.storage.local.remove([
    'lingolette_user_session',
    'lingolette_user_id',
    'lingolette_user_email'
  ]);
  
  // 3. Notify background to clear quota cache and stop session refresh
  chrome.runtime.sendMessage({ type: 'USER_LOGGED_OUT' }, (response) => {
  });
  
  // 4. Notify all content scripts to stop AI highlighting
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      if (tab.id) {
        chrome.tabs.sendMessage(tab.id, { type: 'USER_LOGGED_OUT' }, () => {
          // Ignore errors for tabs that don't have content script
          if (chrome.runtime.lastError) {
          }
        });
      }
    });
  });
  
  
  // 5. Refresh UI
  await checkAuthStatus();
}

// Update status hint based on current state
function updateStatusHint(state, globalEnabled, sitePref) {
  const statusHint = document.getElementById('statusHint');
  if (!statusHint) return;
  
  // Priority 1: Global disabled
  if (state === 'global_off' || globalEnabled === false) {
    statusHint.className = 'status-hint status-global-off';
    statusHint.textContent = t('popup.statusGlobalOff');
    statusHint.style.display = 'block';
    return;
  }
  
  // Priority 2: Site manually enabled
  if (state === 'site_on' || sitePref === 'always_on') {
    statusHint.className = 'status-hint status-site-on';
    statusHint.textContent = t('popup.statusSiteOn');
    statusHint.style.display = 'block';
    return;
  }
  
  // Priority 3: Site manually disabled
  if (state === 'site_off' || sitePref === 'always_off') {
    statusHint.className = 'status-hint status-site-off';
    statusHint.textContent = t('popup.statusSiteOff');
    statusHint.style.display = 'block';
    return;
  }
  
  // Priority 4: Auto-detect suitable
  if (state === 'auto_on') {
    statusHint.className = 'status-hint status-auto-on';
    statusHint.textContent = t('popup.statusAutoOn');
    statusHint.style.display = 'block';
    return;
  }
  
  // Priority 5: Auto-detect not suitable
  if (state === 'auto_off') {
    statusHint.className = 'status-hint status-auto-off';
    statusHint.textContent = t('popup.statusAutoOff');
    statusHint.style.display = 'block';
    return;
  }
  
  // Default: hide
  statusHint.style.display = 'none';
}

async function init(){
  // Wait for i18n to be ready
  while (!i18nReady) {
    await new Promise(resolve => setTimeout(resolve, 10));
  }
  
  // Check authentication status
  await checkAuthStatus();
  
  // Auth button handlers
  document.getElementById('btnLogin')?.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('auth/login.html') });
  });
  
  document.getElementById('btnSignup')?.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('auth/signup.html') });
  });
  
  document.getElementById('btnLogout')?.addEventListener('click', handleLogout);
  
  document.getElementById('btnUpgrade')?.addEventListener('click', () => {
    // Open pricing page in new tab
    chrome.tabs.create({ url: 'https://lemingle.com/pricing' });
  });
  
  // Manage subscription link
  document.getElementById('btnManageSubscription')?.addEventListener('click', async (e) => {
    e.preventDefault(); // Prevent default link behavior
    
    try {
      const localData = await chrome.storage.local.get(['lingolette_user_session']);
      const session = localData.lingolette_user_session;
      
      if (!session?.access_token) {
        alert('请先登录');
        return;
      }
      
      // Call Edge Function to create Customer Portal session
      const response = await fetch('https://ebyavvysuogymwktidlx.supabase.co/functions/v1/create-portal-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`
        },
        body: JSON.stringify({
          return_url: 'https://lemingle.com'
        })
      });
      
      const data = await response.json();
      
      if (data.success && data.url) {
        // Open Stripe Customer Portal in new tab
        chrome.tabs.create({ url: data.url });
      } else {
        console.error('Failed to create portal session:', data);
        alert('无法打开订阅管理页面，请稍后重试');
      }
    } catch (error) {
      console.error('Error opening customer portal:', error);
      alert('无法打开订阅管理页面，请稍后重试');
    }
  });
  
  document.getElementById('btnRefresh').addEventListener('click', load);
  document.getElementById('btnExport').addEventListener('click', async ()=>{
    const items = await getItems();
    exportCSV(items);
  });

  // Collection highlight toggle
  const collectionToggle = document.getElementById('collectionHighlightToggle');
  const collectionHint = document.getElementById('collectionHint');
  
  // Load collection highlight setting
  chrome.storage.sync.get(['lingolette_collection_highlight'], (r) => {
    const enabled = r.lingolette_collection_highlight !== false; // default true
    collectionToggle.checked = enabled;
    collectionHint.style.display = enabled ? 'block' : 'none';
  });
  
  // Handle toggle change
  collectionToggle.addEventListener('change', () => {
    const enabled = collectionToggle.checked;
    chrome.storage.sync.set({ lingolette_collection_highlight: enabled }, () => {
      collectionHint.style.display = enabled ? 'block' : 'none';
      
      // Notify all tabs to update collection highlighting
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, { 
            type: 'COLLECTION_HIGHLIGHT_CHANGED', 
            enabled 
          }).catch(() => {}); // Ignore errors for tabs without content script
        });
      });
    });
  });

  // Global AI toggle control
  const globalAiToggle = document.getElementById('globalAiToggle');
  const statusHint = document.getElementById('statusHint');
  const currentPageCard = document.getElementById('currentPageCard');
  
  // Load global AI setting
  chrome.storage.sync.get(['lingolette_ai_enabled'], (r) => {
    const aiEnabled = r.lingolette_ai_enabled !== false; // 默认开启
    globalAiToggle.checked = aiEnabled;
    
    // Update site control state
    if (aiEnabled) {
      currentPageCard.classList.remove('disabled');
    } else {
      currentPageCard.classList.add('disabled');
      updateStatusHint('global_off', null, null);
    }
  });
  
  // Global AI toggle handler
  globalAiToggle.addEventListener('change', () => {
    const enabled = globalAiToggle.checked;
    chrome.storage.sync.set({ lingolette_ai_enabled: enabled }, () => {
      
      // Update site control state
      if (enabled) {
        currentPageCard.classList.remove('disabled');
      } else {
        currentPageCard.classList.add('disabled');
        updateStatusHint('global_off', null, null);
      }
      
      // Notify all tabs to remove/add highlights immediately
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, {
            type: 'GLOBAL_AI_TOGGLE_CHANGED',
            enabled: enabled
          }).catch(() => {}); // Ignore errors for tabs without content script
        });
      });
      
      // Sync to cloud
      chrome.runtime.sendMessage({
        type: 'LINGOLETTE_PROFILE_SYNC',
        payload: { ai_enabled: enabled }
      }).catch(() => {});
    });
  });
  
  // Site highlighting control
  const btnEnable = document.getElementById('btnEnableHighlight');
  const btnDisable = document.getElementById('btnDisableHighlight');
  const rememberSite = document.getElementById('rememberSite');
  const currentDomain = document.getElementById('currentDomain');
  const autoDetectHint = document.getElementById('autoDetectHint');
  const autoDetectResult = document.getElementById('autoDetectResult');
  
  // Debounce timer for site preferences sync
  let sitePrefsDebounceTimer = null;
  
  // Sync site preferences to cloud (debounced)
  function syncSitePreferencesToCloud(prefs) {
    if (sitePrefsDebounceTimer) {
      clearTimeout(sitePrefsDebounceTimer);
    }
    
    sitePrefsDebounceTimer = setTimeout(() => {
      chrome.runtime.sendMessage({
        type: 'LINGOLETTE_PROFILE_SYNC',
        payload: { site_preferences: prefs }
      }).catch(() => {
        // Ignore if background script is not ready
      });
    }, 2000); // 2 second debounce
  }

  chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    if (!tabs[0]) return;
    const url = new URL(tabs[0].url);
    const domain = url.hostname;
    currentDomain.textContent = domain;

    // Load site preferences and global setting
    chrome.storage.sync.get(['lingolette_site_preferences', 'lingolette_ai_enabled'], (r) => {
      const prefs = r.lingolette_site_preferences || {};
      const pref = prefs[domain];
      const globalEnabled = r.lingolette_ai_enabled !== false;

      // Update UI based on current preference
      if (pref === 'always_on') {
        btnEnable.classList.add('active');
        btnDisable.classList.remove('active');
        rememberSite.checked = true;
        updateStatusHint('site_on', globalEnabled, pref);
      } else if (pref === 'always_off') {
        btnEnable.classList.remove('active');
        btnDisable.classList.add('active');
        rememberSite.checked = true;
        updateStatusHint('site_off', globalEnabled, pref);
      } else {
        // Auto mode - check with content script
        chrome.tabs.sendMessage(tabs[0].id, { type: 'CHECK_AUTO_DETECT' }, (response) => {
          if (response && response.shouldEnable !== undefined) {
            if (response.shouldEnable) {
              btnEnable.classList.add('active');
              btnDisable.classList.remove('active');
              updateStatusHint('auto_on', globalEnabled, pref);
            } else {
              btnEnable.classList.remove('active');
              btnDisable.classList.add('active');
              updateStatusHint('auto_off', globalEnabled, pref);
            }
          }
        });
      }
    });

    // Enable button
    btnEnable.addEventListener('click', () => {
      btnEnable.classList.add('active');
      btnDisable.classList.remove('active');
      
      // Save preference if remember is checked
      if (rememberSite.checked) {
        chrome.storage.sync.get(['lingolette_site_preferences'], (r) => {
          const prefs = r.lingolette_site_preferences || {};
          prefs[domain] = 'always_on';
          chrome.storage.sync.set({ lingolette_site_preferences: prefs }, () => {
            updateStatusHint('site_on', true, 'always_on');
            // Trigger cloud sync (debounced)
            syncSitePreferencesToCloud(prefs);
            
            // Reload page to apply
            chrome.tabs.reload(tabs[0].id);
          });
        });
      } else {
        // Just reload without saving
        chrome.tabs.reload(tabs[0].id);
      }
    });

    // Disable button
    btnDisable.addEventListener('click', () => {
      btnEnable.classList.remove('active');
      btnDisable.classList.add('active');
      
      // Save preference if remember is checked
      if (rememberSite.checked) {
        chrome.storage.sync.get(['lingolette_site_preferences'], (r) => {
          const prefs = r.lingolette_site_preferences || {};
          prefs[domain] = 'always_off';
          chrome.storage.sync.set({ lingolette_site_preferences: prefs }, () => {
            updateStatusHint('site_off', true, 'always_off');
            // Trigger cloud sync (debounced)
            syncSitePreferencesToCloud(prefs);
            
            // Reload page to apply
            chrome.tabs.reload(tabs[0].id);
          });
        });
      } else {
        // Just reload without saving
        chrome.tabs.reload(tabs[0].id);
      }
    });

    // Remember checkbox
    rememberSite.addEventListener('change', () => {
      if (!rememberSite.checked) {
        // Clear preference for this domain
        chrome.storage.sync.get(['lingolette_site_preferences'], (r) => {
          const prefs = r.lingolette_site_preferences || {};
          delete prefs[domain];
          chrome.storage.sync.set({ lingolette_site_preferences: prefs }, () => {
            // Trigger cloud sync (debounced)
            syncSitePreferencesToCloud(prefs);
          });
        });
        autoDetectHint.style.display = 'block';
      } else {
        // Save current state when checking "remember"
        const currentState = btnEnable.classList.contains('active') ? 'always_on' : 'always_off';
        chrome.storage.sync.get(['lingolette_site_preferences'], (r) => {
          const prefs = r.lingolette_site_preferences || {};
          prefs[domain] = currentState;
          chrome.storage.sync.set({ lingolette_site_preferences: prefs }, () => {
            // Trigger cloud sync (debounced)
            syncSitePreferencesToCloud(prefs);
          });
        });
        autoDetectHint.style.display = 'none';
      }
    });
  });

  // Quick learning prefs in popup
  const modeRadios = Array.from(document.querySelectorAll('input[name="mode"]'));
  const catCollocation = document.getElementById('cat-collocation');
  const catIdiom = document.getElementById('cat-idiom');
  const catConnector = document.getElementById('cat-connector');
  const prefsHint = document.getElementById('prefsHint');

  function setModeUI(mode){
    for (const r of modeRadios) r.checked = r.value === (mode || 'standard');
  }

  if (modeRadios.length) {
    chrome.storage.sync.get(['lingolette_mode','lingolette_categories'], (r) => {
      setModeUI(r.lingolette_mode || 'standard');
      const cat = r.lingolette_categories || { collocation: true, idiom: true, connector: true };
      if (catCollocation) catCollocation.checked = cat.collocation !== false;
      if (catIdiom) catIdiom.checked = cat.idiom !== false;
      if (catConnector) catConnector.checked = cat.connector !== false;
    });

    function savePrefs(){
      const mode = (modeRadios.find(r => r.checked) || {}).value || 'standard';
      const categories = {
        collocation: !!(catCollocation && catCollocation.checked),
        idiom: !!(catIdiom && catIdiom.checked),
        connector: !!(catConnector && catConnector.checked),
      };
      chrome.storage.sync.set({ lingolette_mode: mode, lingolette_categories: categories }, () => {
        if (prefsHint) {
          prefsHint.textContent = t('popup.prefsSaved');
          setTimeout(() => prefsHint.textContent = t('popup.prefsHint'), 1500);
        }
        
        // Trigger cloud sync
        chrome.runtime.sendMessage({
          type: 'LINGOLETTE_PROFILE_SYNC',
          payload: { 
            learning_mode: mode, 
            focus_categories: categories 
          }
        }).catch(() => {
          // Ignore if background script is not ready
        });
      });
    }

    for (const r of modeRadios) r.addEventListener('change', savePrefs);
    if (catCollocation) catCollocation.addEventListener('change', savePrefs);
    if (catIdiom) catIdiom.addEventListener('change', savePrefs);
    if (catConnector) catConnector.addEventListener('change', savePrefs);
  }

  load();
}

// Update UI texts based on current language
function updateUITexts() {
  // Use the standard i18n update function to handle all data-i18n attributes
  updatePageTranslations();
  
  // Handle logout button title (icon button)
  const btnLogout = document.getElementById('btnLogout');
  if (btnLogout) btnLogout.setAttribute('title', t('popup.logout'));
}

// Display subscription information for Pro/Team users - Minimal Design
function displaySubscriptionInfo(profile) {
  const userTier = document.getElementById('userTier');
  const subscriptionRow = document.getElementById('subscriptionRow');
  const subscriptionDate = document.getElementById('subscriptionDate');
  
  if (!userTier || !subscriptionRow || !subscriptionDate) return;
  
  // Validate subscription data - must have stripe_customer_id
  if (!profile.stripe_customer_id) {
    return;
  }
  
  // Get current language
  const lang = window.CURRENT_UI_LANG || 'zh-CN';
  const isEnglish = lang === 'en';
  
  // Get subscription details
  const tier = profile.subscription_tier || 'free';
  const billingInterval = profile.billing_interval || 'month';
  const willCancel = profile.cancel_at_period_end;
  
  // 1. Update Tier display with billing interval
  let tierText = tier === 'pro' ? t('popup.proTier') : 
                 tier === 'team' ? t('popup.teamTier') : 
                 t('popup.freeTier');
  
  if (tier !== 'free' && billingInterval === 'month') {
    tierText = t('popup.proMonthly');
    
    // Add canceling status
    if (willCancel) {
      userTier.classList.add('canceling');
    } else {
      userTier.classList.remove('canceling');
    }
  }
  
  userTier.textContent = tierText;
  
  // 2. Display subscription info row
  // 强制显示管理入口：只要是付费用户（有 Stripe 客户 ID），就始终显示管理订阅行
  subscriptionRow.style.display = 'flex';
  
  if (profile.current_period_end) {
    // 如果有续订日期，显示日期信息
    const date = new Date(profile.current_period_end);
    const dateStr = isEnglish
      ? date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
      : date.toISOString().split('T')[0]; // YYYY-MM-DD format
    
    const dateLabel = willCancel 
      ? t('popup.serviceUntil')
      : t('popup.nextBilling');
    
    subscriptionDate.textContent = `${dateLabel} ${dateStr}`;
    subscriptionDate.style.display = 'inline';
  } else {
    // 如果没有日期，隐藏日期文字但保留管理链接
    subscriptionDate.textContent = '';
    subscriptionDate.style.display = 'none';
  }
}

// Show upgrade prompt for free users based on quota usage
function showUpgradePrompt(used, total, percentage) {
  let promptElement = document.getElementById('upgradePrompt');
  if (!promptElement) {
    // Create upgrade prompt section if it doesn't exist
    const quotaInfo = document.getElementById('quotaInfo');
    if (quotaInfo) {
      promptElement = document.createElement('div');
      promptElement.id = 'upgradePrompt';
      promptElement.style.marginTop = '12px';
      quotaInfo.appendChild(promptElement);
    } else {
      return; // No quota info section found
    }
  }
  
  if (!promptElement) return;
  
  // Get current language
  const lang = window.CURRENT_UI_LANG || 'zh-CN';
  const isEnglish = lang === 'en';
  
  if (percentage >= 100) {
    // 配额用尽 - 强烈升级提示
    const title = isEnglish ? '🚫 Quota Exhausted' : '🚫 配额已用完';
    const highlight = isEnglish ? '3,100 uses/month' : '3,100 次/月';
    const price = isEnglish ? 'Only HKD 49/month' : '仅需 HKD 49/月';
    const btnText = isEnglish ? '🚀 Upgrade to Pro' : '🚀 升级到 Pro';
    
    promptElement.innerHTML = `
      <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 16px; border-radius: 12px; box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);">
        <p style="margin: 0 0 4px 0; font-weight: 700; font-size: 15px; color: white; text-align: center;">${title}</p>
        <p style="margin: 0 0 12px 0; font-size: 12px; color: rgba(255,255,255,0.9); text-align: center;">
          <span style="font-weight: 600; font-size: 20px; display: block; margin: 8px 0;">${highlight}</span>
          ${price}
        </p>
        <button class="upgrade-prompt-btn" data-type="exhausted"
                style="width: 100%; padding: 12px; background: white; color: #667eea; border: none; border-radius: 8px; cursor: pointer; font-weight: 700; font-size: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.15); transition: transform 0.2s;">
          ${btnText}
        </button>
      </div>
    `;
    promptElement.style.display = 'block';
    
    // Add event listener to the button
    const btn = promptElement.querySelector('.upgrade-prompt-btn');
    if (btn) {
      btn.addEventListener('click', () => {
        chrome.tabs.create({ url: 'https://lemingle.com/pricing' });
      });
      btn.addEventListener('mouseover', () => {
        btn.style.transform = 'scale(1.02)';
      });
      btn.addEventListener('mouseout', () => {
        btn.style.transform = 'scale(1)';
      });
    }
  } else if (percentage >= 75) {
    // 即将用尽 - 温和提醒
    const remaining = total - used;
    const title = isEnglish ? `⚠️ Only ${remaining} uses left` : `⚠️ 仅剩 ${remaining} 次`;
    const highlight = isEnglish ? '100x more' : '100 倍配额';
    const desc = isEnglish ? 'Pro: 3,100/month' : 'Pro: 3,100 次/月';
    const btnText = isEnglish ? '✨ Upgrade Now' : '✨ 立即升级';
    
    promptElement.innerHTML = `
      <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); padding: 14px; border-radius: 10px; box-shadow: 0 3px 10px rgba(245, 87, 108, 0.25);">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
          <div>
            <p style="margin: 0; font-weight: 700; font-size: 14px; color: white;">${title}</p>
            <p style="margin: 4px 0 0 0; font-size: 12px; color: rgba(255,255,255,0.95);">
              <span style="font-weight: 600; font-size: 16px;">${highlight}</span> · ${desc}
            </p>
          </div>
        </div>
        <button class="upgrade-prompt-btn" data-type="warning"
                style="width: 100%; padding: 10px; background: white; color: #f5576c; border: none; border-radius: 6px; cursor: pointer; font-weight: 700; font-size: 13px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); transition: transform 0.2s;">
          ${btnText}
        </button>
      </div>
    `;
    promptElement.style.display = 'block';
    
    // Add event listener to the button
    const btn = promptElement.querySelector('.upgrade-prompt-btn');
    if (btn) {
      btn.addEventListener('click', () => {
        chrome.tabs.create({ url: 'https://lemingle.com/pricing' });
      });
      btn.addEventListener('mouseover', () => {
        btn.style.transform = 'scale(1.02)';
      });
      btn.addEventListener('mouseout', () => {
        btn.style.transform = 'scale(1)';
      });
    }
  } else {
    promptElement.style.display = 'none';
  }
}

document.addEventListener('DOMContentLoaded', init);
