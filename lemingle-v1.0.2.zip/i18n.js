// i18n 国际化工具
// 支持中文和英文界面语言

const translations = {
  'zh-CN': {
    // Popup
    'popup.brandSlogan': '无感积累，畅快表达',
    'popup.brandBadge': 'Beta',
    'popup.notLoggedIn': '未登录',
    'popup.loginToSync': '同步您的收藏和进度',
    'popup.login': '登录',
    'popup.signup': '注册',
    'popup.username': '用户名',
    'popup.freeTier': 'Free',
    'popup.proTier': 'Pro',
    'popup.proMonthly': 'Pro · Monthly',
    'popup.teamTier': 'Team',
    'popup.quotaLabel': 'AI 配额',
    'popup.quotaToday': '今日使用：{used}/{total}',
    'popup.quotaMonthly': '本月使用：{used}/{total}',
    'popup.monthlyUsage': '月度用量：{used}/{total}',
    'popup.quotaResetAt': '配额将在 {time} 重置',
    'popup.upgradePro': '升级 Pro',
    'popup.quotaExhausted': '已达上限',
    'popup.logout': '退出登录',
    'popup.manageSubscription': '管理订阅',
    'popup.nextBilling': '下次续订',
    'popup.serviceUntil': '服务至',
    'popup.globalHighlight': '智能高亮',
    'popup.globalHighlightHint': '自动发现地道表达',
    'popup.currentSite': '当前网站',
    'popup.currentPageHighlight': '当前页面高亮',
    'popup.enable': '学习',
    'popup.disable': '忽略',
    'popup.rememberSite': '记住设定',
    'popup.autoDetect': '自动检测：',
    'popup.collectionHighlight': '收藏高亮',
    'popup.collectionHighlightHint': '自动标记收藏词组',
    'popup.collectionEnabled': '已启用：自动标记收藏词组',
    'popup.statusGlobalOff': '⚠️ 功能已关闭',
    'popup.statusSiteOn': '✅ 已开启学习',
    'popup.statusSiteOff': '🚫 已忽略',
    'popup.statusAutoOn': '💡 推荐学习',
    'popup.statusAutoOff': '💡 已自动忽略',
    'popup.statusSkipped': 'Skipped',
    'popup.learningPrefs': '学习偏好',
    'popup.modeLite': '精简',
    'popup.modeStandard': '标准',
    'popup.modeDetailed': '详细',
    'popup.modeLiteDesc': '只提示最关键表达',
    'popup.modeStandardDesc': '平衡提示与不打扰',
    'popup.modeDetailedDesc': '全面高亮，深度学习',
    'popup.catCollocation': '词组搭配',
    'popup.catIdiom': '习语俚语',
    'popup.catConnector': '逻辑连接',
    'popup.catCollocationDesc': '词组搭配',
    'popup.catIdiomDesc': '习语俚语',
    'popup.catConnectorDesc': '逻辑连接',
    'popup.prefsHint': '刷新页面生效',
    'popup.prefsSaved': '已保存偏好。刷新网页以应用到新的页面高亮。',
    'popup.export': '导出',
    'popup.refresh': '刷新',
    'popup.settings': '设置',
    'popup.noCollection': '暂无收藏',
    'popup.noCollectionHint': '去网页里试试悬浮卡片的"⭐ 收藏"吧',
    'popup.autoDetectEnabled': '建议开启',
    'popup.autoDetectDisabled': '建议关闭',
    
    // Collection item tags
    'popup.tagCollocation': '词组',
    'popup.tagIdiom': '习语',
    'popup.tagConnector': '连接',
    
    // Collection item meta
    'popup.source': '来源',
    'popup.pronounce': '发音',
    'popup.delete': '删除该条',
    'popup.yesterday': '昨天',
    'popup.lastWeek': '上',
    'popup.monthsAgo': '个月前',
    'popup.weekdays': ['周日', '周一', '周二', '周三', '周四', '周五', '周六'],
    
    // Options
    'options.navGeneral': '通用设置',
    'options.navProfile': '学习档案',
    'options.navAbout': '关于',
    'options.title': '设置',
    'options.subtitle': '个性化你的语言学习体验',
    'options.learningMode': '学习模式',
    'options.learningModeDesc': '控制高亮详略程度。不同模式影响每段文本的高亮数量与识别策略。',
    'options.modeLite': '精简 (Lite)',
    'options.modeStandard': '标准 (Standard)',
    'options.modeDetailed': '详细 (Detailed)',
    'options.modeLiteTitle': '只提示最关键表达',
    'options.modeStandardTitle': '平衡提示与不打扰',
    'options.modeDetailedTitle': '全面高亮，深度学习',
    'options.focusContent': '关注内容',
    'options.focusContentDesc': '选择你此阶段更关注的表达类型。',
    'options.catCollocation': '词组搭配',
    'options.catIdiom': '习语俚语',
    'options.catConnector': '逻辑连接',
    'options.catCollocationTitle': '地道且高频的词组搭配',
    'options.catIdiomTitle': '固定说法与习语',
    'options.catConnectorTitle': '承上启下的逻辑连接',
    'options.save': '保存',
    'options.savePrefs': '保存偏好',
    'options.saveSettings': '保存设置',
    'options.learnerProfile': '学习者画像',
    'options.learnerProfileDesc': '配置你的学习背景，AI 将根据这些信息筛选合适的表达。',
    'options.currentLevel': '当前水平',
    'options.learningGoal': '学习目标',
    'options.weakArea': '重点提升',
    'options.targetLanguage': '学习语言',
    'options.explanationLang': '母语/释义语言',
    'options.levelBeginner': '初级 (A1-A2)',
    'options.levelIntermediate': '中级 (B1-B2, 雅思6-7)',
    'options.levelAdvanced': '高级 (C1-C2, 雅思8+)',
    'options.goalProfessional': '职场沟通',
    'options.goalAcademic': '学术写作',
    'options.goalDaily': '日常交流',
    'options.goalTravel': '旅行交流',
    'options.weakSpeaking': '口语表达',
    'options.weakWriting': '写作能力',
    'options.weakListening': '听力理解',
    'options.weakReading': '阅读速度',
    'options.langEnglish': '英语',
    'options.langFrench': '法语',
    'options.langSpanish': '西班牙语',
    'options.langGerman': '德语',
    'options.langKorean': '韩语',
    'options.langJapanese': '日语',
    'options.langChineseTraditional': '中文繁体',
    'options.langChineseSimplified': '中文简体',
    'options.langRussian': '俄语',
    'options.saveLearnerProfile': '保存学习者画像',
    'options.uiLanguage': '界面语言',
    'options.uiLanguageDesc': '选择产品界面显示的语言',
    'options.saved': '已保存',
    'options.savedPrefsSuccess': '已保存学习模式与关注内容',
    'options.savedProfileSuccess': '已保存学习者画像',
    'options.legalNotice': 'By using LeMingle, you agree to our legal terms',
    'options.privacyPolicy': '隐私政策',
    'options.termsOfService': '服务条款',
    'options.github': 'GitHub',
    
    // Content Script
    'content.translating': '翻译中... ⏳',
    'content.addToCollection': '收藏',
    'content.removeFromCollection': '取消收藏',
    'content.aiHighlighting': 'AI 高亮中...',
    'content.aiHighlightDisabled': '此网站已关闭 AI 高亮',
    'content.aiFeatureDisabled': 'AI 高亮功能已关闭',
    'content.siteNotSuitable': '此网站不适合 AI 高亮',
    'content.aiHighlightComplete': 'AI 高亮完成',
    'content.found': '找到',
    'content.expressions': '个表达',
  },
  'en': {
    // Popup
    'popup.brandSlogan': 'Enrich Daily Expressions Unconsciously',
    'popup.brandBadge': 'Beta',
    'popup.notLoggedIn': 'Not Logged In',
    'popup.loginToSync': 'Sync your collections and progress',
    'popup.login': 'Login',
    'popup.signup': 'Sign Up',
    'popup.username': 'Username',
    'popup.freeTier': 'Free',
    'popup.proTier': 'Pro',
    'popup.proMonthly': 'Pro · Monthly',
    'popup.teamTier': 'Team',
    'popup.quotaLabel': 'AI Quota',
    'popup.quotaToday': 'Daily Usage: {used}/{total}',
    'popup.quotaMonthly': 'Monthly Usage: {used}/{total}',
    'popup.monthlyUsage': 'Monthly Usage: {used}/{total}',
    'popup.quotaResetAt': 'Resets at {time}',
    'popup.upgradePro': 'Upgrade to Pro',
    'popup.quotaExhausted': 'Limit Reached',
    'popup.logout': 'Logout',
    'popup.manageSubscription': 'Manage Subscription',
    'popup.nextBilling': 'Next billing',
    'popup.serviceUntil': 'Service until',
    'popup.globalHighlight': 'Smart Highlighting',
    'popup.globalHighlightHint': 'Discover native expressions',
    'popup.currentSite': 'Current Site',
    'popup.currentPageHighlight': 'Current Page Highlight',
    'popup.enable': 'Learn',
    'popup.disable': 'Skip',
    'popup.rememberSite': 'Remember',
    'popup.autoDetect': 'Auto-detect: ',
    'popup.collectionHighlight': 'Collection Highlight',
    'popup.collectionHighlightHint': 'Auto-mark saved phrases',
    'popup.collectionEnabled': 'Enabled: Auto-mark saved phrases',
    'popup.statusGlobalOff': '⚠️ Feature Disabled',
    'popup.statusSiteOn': '✅ Learning Enabled',
    'popup.statusSiteOff': '🚫 Skipped',
    'popup.statusAutoOn': '💡 Recommended',
    'popup.statusAutoOff': '💡 Auto-skipped',
    'popup.statusSkipped': 'Skipped',
    'popup.learningPrefs': 'Learning Preferences',
    'popup.modeLite': 'Lite',
    'popup.modeStandard': 'Standard',
    'popup.modeDetailed': 'Detailed',
    'popup.modeLiteDesc': 'Only key expressions',
    'popup.modeStandardDesc': 'Balanced highlighting',
    'popup.modeDetailedDesc': 'Comprehensive, deep learning',
    'popup.catCollocation': 'Collocations',
    'popup.catIdiom': 'Idioms & Slang',
    'popup.catConnector': 'Connectors',
    'popup.catCollocationDesc': 'Collocations',
    'popup.catIdiomDesc': 'Idioms & Slang',
    'popup.catConnectorDesc': 'Logical Connectors',
    'popup.prefsHint': 'Refresh to apply',
    'popup.prefsSaved': 'Preferences saved. Refresh pages to apply new highlighting.',
    'popup.export': 'Export',
    'popup.refresh': 'Refresh',
    'popup.settings': 'Settings',
    'popup.noCollection': 'No Collections',
    'popup.noCollectionHint': 'Try the "⭐ Save" button on hover cards',
    'popup.autoDetectEnabled': 'Recommended: Enable',
    'popup.autoDetectDisabled': 'Recommended: Disable',
    
    // Collection item tags
    'popup.tagCollocation': 'collocation',
    'popup.tagIdiom': 'idiom',
    'popup.tagConnector': 'connector',
    
    // Collection item meta
    'popup.source': 'Source',
    'popup.pronounce': 'Speak',
    'popup.delete': 'Delete this',
    'popup.yesterday': 'Yesterday',
    'popup.lastWeek': 'Last ',
    'popup.monthsAgo': ' months ago',
    'popup.weekdays': ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    
    // Options
    'options.navGeneral': 'General',
    'options.navProfile': 'Learner Profile',
    'options.navAbout': 'About',
    'options.title': 'Settings',
    'options.subtitle': 'Personalize your language learning experience',
    'options.learningMode': 'Learning Mode',
    'options.learningModeDesc': 'Control highlighting density. Different modes affect the number and strategy of highlights.',
    'options.modeLite': 'Lite',
    'options.modeStandard': 'Standard',
    'options.modeDetailed': 'Detailed',
    'options.modeLiteTitle': 'Only key expressions',
    'options.modeStandardTitle': 'Balanced highlighting',
    'options.modeDetailedTitle': 'Comprehensive, deep learning',
    'options.focusContent': 'Focus Content',
    'options.focusContentDesc': 'Choose expression types you want to focus on.',
    'options.catCollocation': 'Collocations',
    'options.catIdiom': 'Idioms & Slang',
    'options.catConnector': 'Connectors',
    'options.catCollocationTitle': 'Natural and frequent word combinations',
    'options.catIdiomTitle': 'Fixed expressions and idioms',
    'options.catConnectorTitle': 'Logical connectors for structuring ideas',
    'options.save': 'Save',
    'options.savePrefs': 'Save Preferences',
    'options.saveSettings': 'Save Settings',
    'options.learnerProfile': 'Learner Profile',
    'options.learnerProfileDesc': 'Configure your learning background. AI will filter suitable expressions based on this.',
    'options.currentLevel': 'Current Level',
    'options.learningGoal': 'Learning Goal',
    'options.weakArea': 'Focus Area',
    'options.targetLanguage': 'Learning Language',
    'options.explanationLang': 'Native/Explanation Language',
    'options.levelBeginner': 'Beginner (A1-A2)',
    'options.levelIntermediate': 'Intermediate (B1-B2, IELTS 6-7)',
    'options.levelAdvanced': 'Advanced (C1-C2, IELTS 8+)',
    'options.goalProfessional': 'Professional Communication',
    'options.goalAcademic': 'Academic Writing',
    'options.goalDaily': 'Daily Conversation',
    'options.goalTravel': 'Travel Communication',
    'options.weakSpeaking': 'Speaking Fluency',
    'options.weakWriting': 'Writing Clarity',
    'options.weakListening': 'Listening Comprehension',
    'options.weakReading': 'Reading Speed',
    'options.langEnglish': 'English',
    'options.langFrench': 'French',
    'options.langSpanish': 'Spanish',
    'options.langGerman': 'German',
    'options.langKorean': 'Korean',
    'options.langJapanese': 'Japanese',
    'options.langChineseTraditional': 'Traditional Chinese',
    'options.langChineseSimplified': 'Simplified Chinese',
    'options.langRussian': 'Russian',
    'options.saveLearnerProfile': 'Save Learner Profile',
    'options.uiLanguage': 'Interface Language',
    'options.uiLanguageDesc': 'Choose the language for the product interface',
    'options.saved': 'Saved',
    'options.savedPrefsSuccess': 'Learning mode and focus content saved',
    'options.savedProfileSuccess': 'Learner profile saved',
    'options.legalNotice': 'By using LeMingle, you agree to our legal terms',
    'options.privacyPolicy': 'Privacy Policy',
    'options.termsOfService': 'Terms of Service',
    'options.github': 'GitHub',
    
    // Content Script
    'content.translating': 'Translating... ⏳',
    'content.addToCollection': 'Save',
    'content.removeFromCollection': 'Unsave',
    'content.aiHighlighting': 'AI Highlighting...',
    'content.aiHighlightDisabled': 'AI highlighting disabled for this site',
    'content.aiFeatureDisabled': 'AI highlighting feature is off',
    'content.siteNotSuitable': 'This site is not suitable for AI highlighting',
    'content.aiHighlightComplete': 'AI Highlighting Complete',
    'content.found': 'Found',
    'content.expressions': 'expressions',
  }
};

// 获取当前界面语言
function getUILanguage() {
  // 从 storage 读取用户设置
  return new Promise((resolve) => {
    chrome.storage.sync.get(['lingolette_ui_language'], (result) => {
      if (result.lingolette_ui_language) {
        resolve(result.lingolette_ui_language);
      } else {
        // 自动检测系统语言
        const systemLang = navigator.language || navigator.userLanguage;
        const uiLang = systemLang.startsWith('zh') ? 'zh-CN' : 'en';
        resolve(uiLang);
      }
    });
  });
}

// 翻译函数
function t(key, params = {}) {
  const lang = window.CURRENT_UI_LANG || 'zh-CN';
  let text = translations[lang]?.[key] || translations['en']?.[key] || key;
  
  // 替换参数 {param}
  Object.keys(params).forEach(param => {
    text = text.replace(new RegExp(`\\{${param}\\}`, 'g'), params[param]);
  });
  
  return text;
}

// 初始化 i18n
async function initI18n() {
  const lang = await getUILanguage();
  window.CURRENT_UI_LANG = lang;
  return lang;
}

// 更新页面所有翻译
function updatePageTranslations() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    const params = el.getAttribute('data-i18n-params');
    const parsedParams = params ? JSON.parse(params) : {};
    el.textContent = t(key, parsedParams);
  });
  
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    el.placeholder = t(key);
  });
  
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    const key = el.getAttribute('data-i18n-title');
    el.title = t(key);
  });
}

// 导出
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { t, initI18n, updatePageTranslations, getUILanguage };
}
