// Lingolette Sync Manager - Service Worker Compatible
// Unified sync manager for batch operations and profile sync

const SUPABASE_URL = 'https://ebyavvysuogymwktidlx.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVieWF2dnlzdW9neW13a3RpZGx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwMjYzMTUsImV4cCI6MjA3NTYwMjMxNX0.W7stnpPBlPxHy3RH7aWA0DSo7iI7lzsgY-i5tKWHyIw';

// Sync queue
const syncQueue = {
  toAdd: [],
  toDelete: [],
  lastFlush: Date.now()
};

// Sync state
let syncing = false;
let syncTimer = null;
let retryCount = 0;

// Configuration
const config = {
  batchThreshold: 10,
  timeInterval: 15000,
  retryDelay: 5000,
  maxRetries: 3
};

// Profile sync debounce timer
let profileSyncTimer = null;

// Token refresh state
let tokenRefreshing = false;
let tokenRefreshPromise = null;

/**
 * Get user session from chrome storage
 */
function getUserSession() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['lingolette_user_session'], (result) => {
      resolve(result.lingolette_user_session || null);
    });
  });
}

/**
 * Refresh token if expired or expiring soon
 */
async function refreshTokenIfNeeded(session) {
  if (!session || !session.refresh_token) {
    return session;
  }
  
  const expiresAt = session.expires_at || 0;
  const now = Math.floor(Date.now() / 1000);
  const needsRefresh = expiresAt - now < 300; // Refresh if expiring within 5 minutes
  
  if (!needsRefresh) {
    return session;
  }
  
  // If already refreshing, wait for the existing refresh to complete
  if (tokenRefreshing && tokenRefreshPromise) {
    return await tokenRefreshPromise;
  }
  
  // Start refreshing
  tokenRefreshing = true;
  
  tokenRefreshPromise = (async () => {
    try {
      const response = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': SUPABASE_ANON_KEY
        },
        body: JSON.stringify({ refresh_token: session.refresh_token })
      });
      
      if (response.ok) {
        const newSession = await response.json();
        await new Promise((resolve) => {
          chrome.storage.local.set({ lingolette_user_session: newSession }, resolve);
        });
        return newSession;
      } else {
        const errorText = await response.text();
        console.error('[SyncManager] Token refresh failed:', errorText);
        
        // If refresh token is invalid/expired, check storage for updated session
        if (errorText.includes('refresh_token_already_used') || errorText.includes('Invalid Refresh Token')) {
          
          // Wait a bit for other refresh to complete
          await new Promise(resolve => setTimeout(resolve, 200));
          
          // Get the latest session from storage (might have been refreshed by another call)
          const latestSession = await getUserSession();
          
          // Check if we got a different session (updated by another call)
          if (latestSession && latestSession.access_token !== session.access_token) {
            // Verify the new token is not expired
            const newExpiresAt = latestSession.expires_at || 0;
            const now = Math.floor(Date.now() / 1000);
            
            if (newExpiresAt - now > 60) { // At least 1 minute valid
              return latestSession;
            } else {
              console.error('[SyncManager] ❌ Updated session also expired');
            }
          } else {
            console.error('[SyncManager] ❌ No updated session found in storage');
          }
          
          console.error('[SyncManager] 🔐 Session expired. Please logout and login again to continue syncing.');
          return null; // Return null to indicate sync should be skipped
        }
        
        return session;
      }
    } catch (error) {
      console.error('[SyncManager] Token refresh error:', error);
      return session;
    } finally {
      tokenRefreshing = false;
      tokenRefreshPromise = null;
    }
  })();
  
  return await tokenRefreshPromise;
}

/**
 * Add item to sync queue
 */
function addItemToSyncQueue(item) {
  syncQueue.toAdd.push(item);
  scheduleSync();
}

/**
 * Add delete operation to sync queue
 */
function deleteItemFromSyncQueue(cloudId) {
  if (cloudId) {
    syncQueue.toDelete.push(cloudId);
    scheduleSync();
  }
}

/**
 * Schedule sync based on queue size and time
 */
function scheduleSync() {
  const queueSize = syncQueue.toAdd.length + syncQueue.toDelete.length;
  const timeSinceLastFlush = Date.now() - syncQueue.lastFlush;
  
  if (queueSize >= config.batchThreshold) {
    flushSync();
    return;
  }
  
  if (timeSinceLastFlush > config.timeInterval) {
    flushSync();
    return;
  }
  
  if (syncTimer) {
    clearTimeout(syncTimer);
  }
  
  syncTimer = setTimeout(() => {
    flushSync();
  }, config.timeInterval);
}

/**
 * Flush sync queue
 */
async function flushSync() {
  if (syncing) {
    return;
  }
  
  const queueSize = syncQueue.toAdd.length + syncQueue.toDelete.length;
  if (queueSize === 0) {
    return;
  }
  
  syncing = true;
  
  try {
    let session = await getUserSession();
    if (!session) {
      syncing = false;
      return;
    }
    
    // Refresh token if needed
    session = await refreshTokenIfNeeded(session);
    
    // Check if session is still valid after refresh attempt
    if (!session) {
      console.error('[SyncManager] Session invalid after refresh, skipping batch sync');
      syncing = false;
      return;
    }
    
    const operations = {
      added: 0,
      deleted: 0,
      errors: []
    };
    
    // Batch insert
    if (syncQueue.toAdd.length > 0) {
      const itemsToAdd = [...syncQueue.toAdd];
      
      const response = await fetch(`${SUPABASE_URL}/rest/v1/saved_items`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${session.access_token}`,
          'Prefer': 'return=representation'
        },
        body: JSON.stringify(itemsToAdd.map(item => ({
          user_id: session.user.id,
          text: item.text,
          type: item.type,
          meaning: item.meaning,
          url: item.url,
          title: item.title
        })))
      });
      
      if (response.ok) {
        const data = await response.json();
        operations.added = itemsToAdd.length;
        
        // Update local items with cloud IDs
        if (data && data.length > 0) {
          await updateLocalItemsWithCloudIds(itemsToAdd, data);
        }
        
        syncQueue.toAdd = [];
      } else {
        const error = await response.text();
        console.error('[SyncManager] Insert error:', error);
        operations.errors.push({ type: 'insert', error });
      }
    }
    
    // Batch delete
    if (syncQueue.toDelete.length > 0) {
      const idsToDelete = [...syncQueue.toDelete];
      
      const response = await fetch(`${SUPABASE_URL}/rest/v1/saved_items?id=in.(${idsToDelete.join(',')})&user_id=eq.${session.user.id}`, {
        method: 'DELETE',
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${session.access_token}`
        }
      });
      
      if (response.ok) {
        operations.deleted = idsToDelete.length;
        syncQueue.toDelete = [];
      } else {
        const error = await response.text();
        console.error('[SyncManager] Delete error:', error);
        operations.errors.push({ type: 'delete', error });
      }
    }
    
    syncQueue.lastFlush = Date.now();
    
    if (operations.errors.length === 0) {
      retryCount = 0;
    }
    
    
  } catch (error) {
    console.error('[SyncManager] Sync failed:', error);
    
    if (retryCount < config.maxRetries) {
      retryCount++;
      setTimeout(() => {
        flushSync();
      }, config.retryDelay);
    } else {
      console.error('[SyncManager] Max retries reached, giving up');
      retryCount = 0;
    }
  } finally {
    syncing = false;
  }
}

/**
 * Update local items with cloud IDs
 */
async function updateLocalItemsWithCloudIds(localItems, cloudItems) {
  return new Promise((resolve) => {
    chrome.storage.local.get(['lingolette_items'], (res) => {
      const items = res.lingolette_items || [];
      
      cloudItems.forEach((cloudItem, index) => {
        const localItem = localItems[index];
        const itemIndex = items.findIndex(item => 
          item.text.toLowerCase() === localItem.text.toLowerCase()
        );
        
        if (itemIndex !== -1) {
          items[itemIndex].cloudId = cloudItem.id;
        }
      });
      
      chrome.storage.local.set({ lingolette_items: items }, resolve);
    });
  });
}

/**
 * Sync profile (debounced)
 */
function syncProfile(profile) {
  if (profileSyncTimer) {
    clearTimeout(profileSyncTimer);
  }
  
  profileSyncTimer = setTimeout(async () => {
    try {
      let session = await getUserSession();
      if (!session) {
        return;
      }
      
      // Refresh token if needed
      session = await refreshTokenIfNeeded(session);
      
      // Check if session is still valid after refresh attempt
      if (!session) {
        console.error('[SyncManager] Session invalid after refresh, skipping profile sync');
        return;
      }
      
      
      // Build update payload with only provided fields
      const updateData = {
        updated_at: new Date().toISOString()
      };
      
      // Add fields that are provided
      if (profile.learning_mode !== undefined) updateData.learning_mode = profile.learning_mode;
      if (profile.focus_categories !== undefined) updateData.focus_categories = profile.focus_categories;
      if (profile.learner_level !== undefined) updateData.learner_level = profile.learner_level;
      if (profile.learner_goal !== undefined) updateData.learner_goal = profile.learner_goal;
      if (profile.learner_weak_area !== undefined) updateData.learner_weak_area = profile.learner_weak_area;
      if (profile.target_languages !== undefined) updateData.target_languages = profile.target_languages;
      if (profile.explanation_lang !== undefined) updateData.explanation_lang = profile.explanation_lang;
      if (profile.site_preferences !== undefined) updateData.site_preferences = profile.site_preferences;
      if (profile.collection_highlight !== undefined) updateData.collection_highlight = profile.collection_highlight;
      
      const response = await fetch(`${SUPABASE_URL}/rest/v1/user_profiles?id=eq.${session.user.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${session.access_token}`,
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify(updateData)
      });
      
      if (response.ok) {
      } else {
        const error = await response.text();
        console.error('[SyncManager] Profile sync error:', error);
      }
    } catch (error) {
      console.error('[SyncManager] Profile sync failed:', error);
    }
  }, 1000);
}

/**
 * Sync on login
 */
async function syncOnLogin() {
  try {
    
    let session = await getUserSession();
    if (!session) {
      return;
    }
    
    // Refresh token if needed
    session = await refreshTokenIfNeeded(session);
    
    // Check if session is still valid after refresh attempt
    if (!session) {
      console.error('[SyncManager] Session invalid after refresh, skipping login sync');
      return;
    }
    
    // Pull profile
    const profileResponse = await fetch(`${SUPABASE_URL}/rest/v1/user_profiles?id=eq.${session.user.id}`, {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${session.access_token}`
      }
    });
    
    if (profileResponse.ok) {
      const profiles = await profileResponse.json();
      if (profiles && profiles.length > 0) {
        const cloudProfile = profiles[0];
        
        // Save to local storage
        await new Promise((resolve) => {
          chrome.storage.sync.set({
            lingolette_mode: cloudProfile.learning_mode,
            lingolette_categories: cloudProfile.focus_categories,
            lingolette_learner_level: cloudProfile.learner_level,
            lingolette_learner_goal: cloudProfile.learner_goal,
            lingolette_learner_weak_area: cloudProfile.learner_weak_area,
            lingolette_target_languages: cloudProfile.target_languages || ['en'],
            lingolette_explanation_lang: cloudProfile.explanation_lang || 'zh-simplified',
            lingolette_site_preferences: cloudProfile.site_preferences || {},
            lingolette_collection_highlight: cloudProfile.collection_highlight !== false
          }, resolve);
        });
      }
    }
    
    // Pull items (paginated)
    let allItems = [];
    let page = 0;
    const pageSize = 100;
    
    
    while (true) {
      const itemsResponse = await fetch(
        `${SUPABASE_URL}/rest/v1/saved_items?user_id=eq.${session.user.id}&order=created_at.desc&limit=${pageSize}&offset=${page * pageSize}`,
        {
          headers: {
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${session.access_token}`
          }
        }
      );
      
      if (!itemsResponse.ok) break;
      
      const data = await itemsResponse.json();
      if (!data || data.length === 0) break;
      
      allItems = allItems.concat(data.map(item => ({
        text: item.text,
        type: item.type,
        meaning: item.meaning,
        url: item.url,
        title: item.title,
        ts: new Date(item.created_at).getTime(),
        cloudId: item.id
      })));
      
      
      if (data.length < pageSize) break;
      page++;
    }
    
    
    // Merge with local items
    const localItems = await new Promise((resolve) => {
      chrome.storage.local.get(['lingolette_items'], (res) => {
        resolve(res.lingolette_items || []);
      });
    });
    
    const merged = mergeItems(localItems, allItems);
    
    await new Promise((resolve) => {
      chrome.storage.local.set({ lingolette_items: merged }, resolve);
    });
    
    
  } catch (error) {
    console.error('[SyncManager] Login sync failed:', error);
  }
}

/**
 * Merge local and cloud items
 */
function mergeItems(localItems, cloudItems) {
  const merged = new Map();
  
  localItems.forEach(item => {
    const key = item.text.toLowerCase();
    merged.set(key, item);
  });
  
  cloudItems.forEach(item => {
    const key = item.text.toLowerCase();
    if (!merged.has(key)) {
      merged.set(key, item);
    } else {
      const existing = merged.get(key);
      if (item.ts > existing.ts) {
        merged.set(key, item);
      } else if (!existing.cloudId && item.cloudId) {
        existing.cloudId = item.cloudId;
        merged.set(key, existing);
      }
    }
  });
  
  return Array.from(merged.values())
    .sort((a, b) => b.ts - a.ts)
    .slice(0, 1000);
}

