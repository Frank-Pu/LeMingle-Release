// Lingolette Items Sync Module
// Handles saved items synchronization with cloud

class ItemsSyncManager {
  constructor() {
    this.syncing = false;
  }
  
  /**
   * Pull all items from cloud (paginated)
   */
  async pullAllItems() {
    try {
      const session = await this.getUserSession();
      if (!session) {
        return [];
      }
      
      const supabase = await this.getSupabaseClient();
      if (!supabase) {
        throw new Error('Supabase client not available');
      }
      
      let allItems = [];
      let page = 0;
      const pageSize = 100;
      
      
      while (true) {
        const { data, error } = await supabase
          .from('saved_items')
          .select('*')
          .eq('user_id', session.user.id)
          .order('created_at', { ascending: false })
          .range(page * pageSize, (page + 1) * pageSize - 1);
        
        if (error) {
          console.error('[ItemsSync] Failed to pull items:', error);
          break;
        }
        
        if (!data || data.length === 0) break;
        
        // Convert cloud items to local format
        allItems = allItems.concat(data.map(item => ({
          text: item.text,
          type: item.type,
          meaning: item.meaning,
          url: item.url,
          title: item.title,
          ts: new Date(item.created_at).getTime(),
          cloudId: item.id // Store cloud ID for deletion
        })));
        
        
        if (data.length < pageSize) break;
        page++;
      }
      
      return allItems;
      
    } catch (error) {
      console.error('[ItemsSync] Failed to pull items:', error);
      return [];
    }
  }
  
  /**
   * Sync items on login
   */
  async syncOnLogin() {
    try {
      
      // Pull cloud items
      const cloudItems = await this.pullAllItems();
      
      // Get local items
      const localItems = await this.getLocalItems();
      
      // Merge items
      const mergedItems = this.mergeItems(localItems, cloudItems);
      
      // Save merged items locally
      await this.saveLocalItems(mergedItems);
      
      return mergedItems;
      
    } catch (error) {
      console.error('[ItemsSync] Login sync failed:', error);
      return [];
    }
  }
  
  /**
   * Merge local and cloud items (deduplicate)
   */
  mergeItems(localItems, cloudItems) {
    const merged = new Map();
    
    // Add local items
    localItems.forEach(item => {
      const key = item.text.toLowerCase();
      merged.set(key, item);
    });
    
    // Merge cloud items (deduplicate by text)
    cloudItems.forEach(item => {
      const key = item.text.toLowerCase();
      if (!merged.has(key)) {
        // New item from cloud
        merged.set(key, item);
      } else {
        // Item exists locally, keep the newer one
        const existing = merged.get(key);
        if (item.ts > existing.ts) {
          merged.set(key, item);
        } else if (!existing.cloudId && item.cloudId) {
          // Update cloud ID if missing
          existing.cloudId = item.cloudId;
          merged.set(key, existing);
        }
      }
    });
    
    // Convert back to array and sort by timestamp
    return Array.from(merged.values())
      .sort((a, b) => b.ts - a.ts)
      .slice(0, 1000); // Limit to 1000 items
  }
  
  /**
   * Get local items
   */
  async getLocalItems() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['lingolette_items'], (result) => {
        resolve(result.lingolette_items || []);
      });
    });
  }
  
  /**
   * Save items to local storage
   */
  async saveLocalItems(items) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ lingolette_items: items }, resolve);
    });
  }
  
  /**
   * Get user session
   */
  async getUserSession() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['lingolette_user_session'], (result) => {
        resolve(result.lingolette_user_session || null);
      });
    });
  }
  
  /**
   * Get Supabase client
   */
  async getSupabaseClient() {
    if (typeof window !== 'undefined' && window.supabase) {
      const SUPABASE_URL = 'https://ebyavvysuogymwktidlx.supabase.co';
      const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVieWF2dnlzdW9neW13a3RpZGx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwMjYzMTUsImV4cCI6MjA3NTYwMjMxNX0.W7stnpPBlPxHy3RH7aWA0DSo7iI7lzsgY-i5tKWHyIw';
      return window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    }
    return null;
  }
}

// Create singleton instance
const itemsSyncManager = new ItemsSyncManager();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = itemsSyncManager;
}
