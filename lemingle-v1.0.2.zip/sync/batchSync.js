// Lingolette Batch Sync Module
// Optimized for high-frequency operations with minimal network overhead

class BatchSyncManager {
  constructor() {
    // Sync queue
    this.queue = {
      toAdd: [],      // Items to add
      toDelete: [],   // Cloud IDs to delete
      lastFlush: Date.now()
    };
    
    // Sync state
    this.syncing = false;
    this.syncTimer = null;
    
    // Configuration
    this.config = {
      batchThreshold: 10,    // Sync when queue reaches 10 items
      timeInterval: 15000,   // Sync every 15 seconds
      retryDelay: 5000,      // Retry after 5 seconds on failure
      maxRetries: 3          // Max retry attempts
    };
    
    // Retry queue
    this.retryQueue = [];
    this.retryCount = 0;
    
    // Listen for page unload to flush pending items
    if (typeof window !== 'undefined') {
      window.addEventListener('beforeunload', () => {
        this.flushSync(true); // Synchronous flush on unload
      });
    }
  }
  
  /**
   * Add item to sync queue
   */
  addItem(item) {
    this.queue.toAdd.push(item);
    this.scheduleSync();
  }
  
  /**
   * Add delete operation to sync queue
   */
  deleteItem(cloudId) {
    if (cloudId) {
      this.queue.toDelete.push(cloudId);
      this.scheduleSync();
    }
  }
  
  /**
   * Schedule sync based on queue size and time
   */
  scheduleSync() {
    const queueSize = this.queue.toAdd.length + this.queue.toDelete.length;
    const timeSinceLastFlush = Date.now() - this.queue.lastFlush;
    
    // Strategy 1: Queue reaches threshold, sync immediately
    if (queueSize >= this.config.batchThreshold) {
      this.flushSync();
      return;
    }
    
    // Strategy 2: Time interval exceeded, sync all pending items
    if (timeSinceLastFlush > this.config.timeInterval) {
      this.flushSync();
      return;
    }
    
    // Strategy 3: Debounce - wait for more items
    if (this.syncTimer) {
      clearTimeout(this.syncTimer);
    }
    
    this.syncTimer = setTimeout(() => {
      this.flushSync();
    }, this.config.timeInterval);
  }
  
  /**
   * Flush sync queue
   */
  async flushSync(synchronous = false) {
    if (this.syncing) {
      return;
    }
    
    const queueSize = this.queue.toAdd.length + this.queue.toDelete.length;
    if (queueSize === 0) {
      return;
    }
    
    this.syncing = true;
    
    try {
      // Get user session
      const session = await this.getUserSession();
      if (!session) {
        this.syncing = false;
        return;
      }
      
      // Load Supabase client
      const supabase = await this.getSupabaseClient();
      if (!supabase) {
        throw new Error('Supabase client not available');
      }
      
      const operations = {
        added: 0,
        deleted: 0,
        errors: []
      };
      
      // Batch insert
      if (this.queue.toAdd.length > 0) {
        const itemsToAdd = [...this.queue.toAdd];
        
        const { data, error } = await supabase
          .from('saved_items')
          .insert(itemsToAdd.map(item => ({
            user_id: session.user.id,
            text: item.text,
            type: item.type,
            meaning: item.meaning,
            url: item.url,
            title: item.title
          })))
          .select();
        
        if (error) {
          console.error('[BatchSync] Insert error:', error);
          operations.errors.push({ type: 'insert', error });
          
          // Add to retry queue
          this.retryQueue.push(...itemsToAdd);
        } else {
          operations.added = itemsToAdd.length;
          
          // Update local items with cloud IDs
          if (data && data.length > 0) {
            await this.updateLocalItemsWithCloudIds(itemsToAdd, data);
          }
          
          // Clear successfully synced items
          this.queue.toAdd = [];
        }
      }
      
      // Batch delete
      if (this.queue.toDelete.length > 0) {
        const idsToDelete = [...this.queue.toDelete];
        
        const { error } = await supabase
          .from('saved_items')
          .delete()
          .in('id', idsToDelete)
          .eq('user_id', session.user.id);
        
        if (error) {
          console.error('[BatchSync] Delete error:', error);
          operations.errors.push({ type: 'delete', error });
          
          // Add to retry queue
          this.retryQueue.push(...idsToDelete.map(id => ({ cloudId: id, action: 'delete' })));
        } else {
          operations.deleted = idsToDelete.length;
          this.queue.toDelete = [];
        }
      }
      
      // Update last flush time
      this.queue.lastFlush = Date.now();
      
      // Notify sync complete
      this.notifySyncComplete(operations);
      
      // Reset retry count on success
      if (operations.errors.length === 0) {
        this.retryCount = 0;
      }
      
      
    } catch (error) {
      console.error('[BatchSync] Sync failed:', error);
      
      // Schedule retry
      if (this.retryCount < this.config.maxRetries) {
        this.retryCount++;
        setTimeout(() => {
          this.flushSync();
        }, this.config.retryDelay);
      } else {
        console.error('[BatchSync] Max retries reached, giving up');
        this.retryCount = 0;
      }
    } finally {
      this.syncing = false;
    }
  }
  
  /**
   * Get user session from chrome storage
   */
  async getUserSession() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['lingolette_user_session'], (result) => {
        resolve(result.lingolette_user_session || null);
      });
    });
  }
  
  /**
   * Get Supabase client
   */
  async getSupabaseClient() {
    // Check if Supabase is already loaded
    if (typeof window !== 'undefined' && window.supabase) {
      const SUPABASE_URL = 'https://ebyavvysuogymwktidlx.supabase.co';
      const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVieWF2dnlzdW9neW13a3RpZGx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwMjYzMTUsImV4cCI6MjA3NTYwMjMxNX0.W7stnpPBlPxHy3RH7aWA0DSo7iI7lzsgY-i5tKWHyIw';
      return window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    }
    
    // For background script, use message passing
    return null;
  }
  
  /**
   * Update local items with cloud IDs
   */
  async updateLocalItemsWithCloudIds(localItems, cloudItems) {
    return new Promise((resolve) => {
      chrome.storage.local.get(['lingolette_items'], (res) => {
        const items = res.lingolette_items || [];
        
        // Match local items with cloud items by text
        cloudItems.forEach((cloudItem, index) => {
          const localItem = localItems[index];
          const itemIndex = items.findIndex(item => 
            item.text.toLowerCase() === localItem.text.toLowerCase()
          );
          
          if (itemIndex !== -1) {
            items[itemIndex].cloudId = cloudItem.id;
          }
        });
        
        chrome.storage.local.set({ lingolette_items: items }, resolve);
      });
    });
  }
  
  /**
   * Notify sync complete
   */
  notifySyncComplete(operations) {
    // Send message to update UI
    chrome.runtime.sendMessage({
      type: 'LINGOLETTE_SYNC_COMPLETE',
      payload: operations
    }).catch(() => {
      // Ignore errors if no listeners
    });
  }
  
  /**
   * Get queue status
   */
  getStatus() {
    return {
      pending: this.queue.toAdd.length + this.queue.toDelete.length,
      syncing: this.syncing,
      retryQueue: this.retryQueue.length,
      lastFlush: this.queue.lastFlush
    };
  }
  
  /**
   * Force sync immediately
   */
  forceSyncNow() {
    if (this.syncTimer) {
      clearTimeout(this.syncTimer);
    }
    return this.flushSync();
  }
}

// Create singleton instance
const batchSyncManager = new BatchSyncManager();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = batchSyncManager;
}
