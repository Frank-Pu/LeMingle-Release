// Lingolette Profile Sync Module
// Handles user profile and settings synchronization

class ProfileSyncManager {
  constructor() {
    this.syncing = false;
    this.debounceTimer = null;
    this.debounceDelay = 1000; // 1 second debounce
  }
  
  /**
   * Pull user profile from cloud
   */
  async pullProfile() {
    try {
      const session = await this.getUserSession();
      if (!session) {
        return null;
      }
      
      const supabase = await this.getSupabaseClient();
      if (!supabase) {
        throw new Error('Supabase client not available');
      }
      
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', session.user.id)
        .single();
      
      if (error) {
        // If profile doesn't exist, create it
        if (error.code === 'PGRST116') {
          return await this.createProfile(session.user.id);
        }
        throw error;
      }
      
      return data;
      
    } catch (error) {
      console.error('[ProfileSync] Failed to pull profile:', error);
      return null;
    }
  }
  
  /**
   * Create user profile
   */
  async createProfile(userId) {
    try {
      const supabase = await this.getSupabaseClient();
      if (!supabase) {
        throw new Error('Supabase client not available');
      }
      
      const { data, error } = await supabase
        .from('user_profiles')
        .insert({
          id: userId,
          learning_mode: 'standard',
          focus_categories: { collocation: true, idiom: true, connector: true },
          learner_level: 'intermediate',
          learner_goal: 'professional',
          learner_weak_area: 'speaking',
          explanation_lang: 'zh',
          site_preferences: {},
          collection_highlight: true
        })
        .select()
        .single();
      
      if (error) throw error;
      
      return data;
      
    } catch (error) {
      console.error('[ProfileSync] Failed to create profile:', error);
      return null;
    }
  }
  
  /**
   * Push profile to cloud
   */
  async pushProfile(profile) {
    try {
      const session = await this.getUserSession();
      if (!session) {
        return false;
      }
      
      const supabase = await this.getSupabaseClient();
      if (!supabase) {
        throw new Error('Supabase client not available');
      }
      
      const { error } = await supabase
        .from('user_profiles')
        .upsert({
          id: session.user.id,
          learning_mode: profile.learning_mode || 'standard',
          focus_categories: profile.focus_categories || { collocation: true, idiom: true, connector: true },
          learner_level: profile.learner_level || 'intermediate',
          learner_goal: profile.learner_goal || 'professional',
          learner_weak_area: profile.learner_weak_area || 'speaking',
          explanation_lang: profile.explanation_lang || 'zh',
          site_preferences: profile.site_preferences || {},
          collection_highlight: profile.collection_highlight !== false,
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'id'
        });
      
      if (error) throw error;
      
      return true;
      
    } catch (error) {
      console.error('[ProfileSync] Failed to push profile:', error);
      return false;
    }
  }
  
  /**
   * Debounced sync - waits for user to stop making changes
   */
  debouncedSync(profile) {
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
    }
    
    this.debounceTimer = setTimeout(() => {
      this.pushProfile(profile);
    }, this.debounceDelay);
  }
  
  /**
   * Sync profile on login
   */
  async syncOnLogin() {
    try {
      
      // Pull cloud profile
      const cloudProfile = await this.pullProfile();
      
      // Get local profile
      const localProfile = await this.getLocalProfile();
      
      // Merge profiles
      const mergedProfile = this.mergeProfiles(localProfile, cloudProfile);
      
      // Save merged profile locally
      await this.saveLocalProfile(mergedProfile);
      
      return mergedProfile;
      
    } catch (error) {
      console.error('[ProfileSync] Login sync failed:', error);
      return null;
    }
  }
  
  /**
   * Merge local and cloud profiles
   */
  mergeProfiles(local, cloud) {
    if (!cloud) return local;
    if (!local) return cloud;
    
    // Use cloud data if it's newer
    const localTime = new Date(local.updated_at || 0).getTime();
    const cloudTime = new Date(cloud.updated_at || 0).getTime();
    
    if (cloudTime > localTime) {
      return cloud;
    } else {
      return local;
    }
  }
  
  /**
   * Get local profile from chrome storage
   */
  async getLocalProfile() {
    return new Promise((resolve) => {
      chrome.storage.sync.get([
        'lingolette_mode',
        'lingolette_categories',
        'lingolette_learner_level',
        'lingolette_learner_goal',
        'lingolette_learner_weak_area',
        'lingolette_explanation_lang',
        'lingolette_site_preferences',
        'lingolette_collection_highlight'
      ], (result) => {
        resolve({
          learning_mode: result.lingolette_mode || 'standard',
          focus_categories: result.lingolette_categories || { collocation: true, idiom: true, connector: true },
          learner_level: result.lingolette_learner_level || 'intermediate',
          learner_goal: result.lingolette_learner_goal || 'professional',
          learner_weak_area: result.lingolette_learner_weak_area || 'speaking',
          explanation_lang: result.lingolette_explanation_lang || 'zh',
          site_preferences: result.lingolette_site_preferences || {},
          collection_highlight: result.lingolette_collection_highlight !== false
        });
      });
    });
  }
  
  /**
   * Save profile to local storage
   */
  async saveLocalProfile(profile) {
    return new Promise((resolve) => {
      chrome.storage.sync.set({
        lingolette_mode: profile.learning_mode,
        lingolette_categories: profile.focus_categories,
        lingolette_learner_level: profile.learner_level,
        lingolette_learner_goal: profile.learner_goal,
        lingolette_learner_weak_area: profile.learner_weak_area,
        lingolette_explanation_lang: profile.explanation_lang,
        lingolette_site_preferences: profile.site_preferences,
        lingolette_collection_highlight: profile.collection_highlight
      }, resolve);
    });
  }
  
  /**
   * Get user session
   */
  async getUserSession() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['lingolette_user_session'], (result) => {
        resolve(result.lingolette_user_session || null);
      });
    });
  }
  
  /**
   * Get Supabase client
   */
  async getSupabaseClient() {
    if (typeof window !== 'undefined' && window.supabase) {
      const SUPABASE_URL = 'https://ebyavvysuogymwktidlx.supabase.co';
      const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVieWF2dnlzdW9neW13a3RpZGx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwMjYzMTUsImV4cCI6MjA3NTYwMjMxNX0.W7stnpPBlPxHy3RH7aWA0DSo7iI7lzsgY-i5tKWHyIw';
      return window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    }
    return null;
  }
}

// Create singleton instance
const profileSyncManager = new ProfileSyncManager();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = profileSyncManager;
}
