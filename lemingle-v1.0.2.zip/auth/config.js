// Supabase Configuration
// Lingolette Project - ap-southeast-1

export const SUPABASE_CONFIG = {
  url: 'https://ebyavvysuogymwktidlx.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVieWF2dnlzdW9neW13a3RpZGx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwMjYzMTUsImV4cCI6MjA3NTYwMjMxNX0.W7stnpPBlPxHy3RH7aWA0DSo7iI7lzsgY-i5tKWHyIw'
};
