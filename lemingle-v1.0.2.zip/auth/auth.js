// Lingolette Auth - Supabase Integration

const SUPABASE_URL = 'https://ebyavvysuogymwktidlx.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVieWF2dnlzdW9neW13a3RpZGx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwMjYzMTUsImV4cCI6MjA3NTYwMjMxNX0.W7stnpPBlPxHy3RH7aWA0DSo7iI7lzsgY-i5tKWHyIw';

// Initialize Supabase client (will be loaded from CDN)
let supabase = null;

// Signup state management
let signupStep = 1; // 1: input info, 2: verify OTP
let tempSignupData = null;
let resendCountdown = 60;
let resendTimer = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', async () => {
  // Load Supabase SDK from CDN
  await loadSupabaseSDK();
  
  // Initialize client with persistSession: false (we manage session ourselves)
  supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: {
      persistSession: false,
      autoRefreshToken: false
    }
  });
  
  // CRITICAL FIX: Check chrome.storage.local (same source as popup.js and background.js)
  // This ensures consistent login state across all components
  const localData = await chrome.storage.local.get(['lingolette_user_session']);
  const storedSession = localData.lingolette_user_session;
  
  // Validate stored session
  if (storedSession && storedSession.access_token) {
    // Check if token is expired
    const expiresAt = storedSession.expires_at || 0;
    const now = Math.floor(Date.now() / 1000);
    
    if (expiresAt > now) {
      // Session is valid - close auth tab and return to browsing
      window.close();
      return;
    } else {
      // Token expired - try to refresh it
      const refreshed = await refreshSession(storedSession);
      if (refreshed) {
        window.close();
        return;
      } else {
        // Refresh failed - clear session
        await chrome.storage.local.remove(['lingolette_user_session', 'lingolette_user_id', 'lingolette_user_email']);
      }
    }
  }
  
  // Setup form handlers
  setupFormHandlers();
  
  // Setup password toggle
  setupPasswordToggle();
});

// Load Supabase SDK from local file
function loadSupabaseSDK() {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('supabase.js');
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

// Setup form event handlers
function setupFormHandlers() {
  const loginForm = document.getElementById('loginForm');
  const signupForm = document.getElementById('signupForm');
  const requestOtpForm = document.getElementById('requestOtpForm');
  const resetPasswordForm = document.getElementById('resetPasswordForm');
  const updatePasswordForm = document.getElementById('updatePasswordForm');
  const backBtn = document.getElementById('backBtn');
  
  if (loginForm) {
    loginForm.addEventListener('submit', handleLogin);
  }
  
  if (signupForm) {
    signupForm.addEventListener('submit', handleSignup);
  }
  
  // Add resend OTP button listener
  const resendOtpBtn = document.getElementById('resendOtpBtn');
  if (resendOtpBtn) {
    resendOtpBtn.addEventListener('click', handleResendOtp);
  }
  
  if (requestOtpForm) {
    requestOtpForm.addEventListener('submit', handleRequestOtp);
  }
  
  if (resetPasswordForm) {
    resetPasswordForm.addEventListener('submit', handleResetPasswordWithOtp);
  }
  
  if (backBtn) {
    backBtn.addEventListener('click', (e) => {
      e.preventDefault();
      document.getElementById('resetPasswordForm').style.display = 'none';
      document.getElementById('requestOtpForm').style.display = 'block';
      document.getElementById('backBtnContainer').style.display = 'none';
      document.getElementById('loginLinkContainer').style.display = 'block';
      document.getElementById('requestOtpBtn').disabled = false;
      document.getElementById('requestOtpBtn').classList.remove('loading');
    });
  }
  
  if (updatePasswordForm) {
    handleUpdatePasswordPage();
  }
}

// Handle login
async function handleLogin(e) {
  e.preventDefault();
  
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const btn = document.getElementById('loginBtn');
  const errorMsg = document.getElementById('errorMessage');
  
  // Clear previous errors
  errorMsg.style.display = 'none';
  
  // Show loading state
  btn.disabled = true;
  btn.classList.add('loading');
  
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    
    if (error) throw error;
    
    // Save user session
    await saveUserSession(data.session);
    
    // Close auth tab and return to browsing
    window.close();
    
  } catch (error) {
    errorMsg.textContent = error.message || 'Login failed. Please try again.';
    errorMsg.style.display = 'block';
    btn.disabled = false;
    btn.classList.remove('loading');
  }
}

// Handle signup
async function handleSignup(e) {
  e.preventDefault();
  
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirmPassword').value;
  const btn = document.getElementById('signupBtn');
  const errorMsg = document.getElementById('errorMessage');
  
  // Clear previous errors
  errorMsg.style.display = 'none';
  
  if (signupStep === 1) {
    // Step 1: Validate input and create account with email confirmation
    
    // Validate passwords match
    if (password !== confirmPassword) {
      errorMsg.textContent = 'Passwords do not match';
      errorMsg.style.display = 'block';
      return;
    }
    
    // Validate password length
    if (password.length < 6) {
      errorMsg.textContent = 'Password must be at least 6 characters';
      errorMsg.style.display = 'block';
      return;
    }
    
    // Show loading state
    btn.disabled = true;
    btn.classList.add('loading');
    
    try {
      // Create account and send confirmation email with OTP
      const { data, error } = await supabase.auth.signUp({
        email: email,
        password: password,
        options: {
          emailRedirectTo: chrome.runtime.getURL('auth/login.html'),
          // This will send a confirmation email with a token
          data: {
            email_confirm: true
          }
        }
      });
      
      if (error) throw error;
      
      // Save signup data temporarily
      tempSignupData = { email, password, userId: data.user?.id };
      
      // Show OTP input section
      document.getElementById('otpSection').style.display = 'block';
      document.getElementById('emailDisplay').textContent = email;
      
      // Disable email and password inputs
      document.getElementById('email').disabled = true;
      document.getElementById('password').disabled = true;
      document.getElementById('confirmPassword').disabled = true;
      
      // Change button text
      btn.textContent = 'Verify Email';
      btn.disabled = false;
      btn.classList.remove('loading');
      
      // Move to step 2
      signupStep = 2;
      
      // Start countdown
      startResendCountdown();
      
      
    } catch (error) {
      errorMsg.textContent = error.message || 'Failed to send verification code';
      errorMsg.style.display = 'block';
      btn.disabled = false;
      btn.classList.remove('loading');
    }
    
  } else if (signupStep === 2) {
    // Step 2: Verify email confirmation token
    
    const otp = document.getElementById('otp').value;
    
    if (!otp || otp.length !== 6) {
      errorMsg.textContent = 'Please enter a valid 6-digit code';
      errorMsg.style.display = 'block';
      return;
    }
    
    btn.disabled = true;
    btn.classList.add('loading');
    
    try {
      // Verify email confirmation token
      const { data, error } = await supabase.auth.verifyOtp({
        email: tempSignupData.email,
        token: otp,
        type: 'signup'  // Use 'signup' type for email confirmation
      });
      
      if (error) throw error;
      
      
      // Email verified, user is now confirmed
      // Save session
      if (data.session) {
        await saveUserSession(data.session);
        
        // Create user profile
        await createUserProfile(data.user.id);
        
        
        // Close auth tab
        window.close();
      } else {
        errorMsg.textContent = 'Email verified! Please login.';
        errorMsg.className = 'success-message';
        errorMsg.style.display = 'block';
        
        // Redirect to login after 3 seconds
        setTimeout(() => {
          window.location.href = 'login.html';
        }, 3000);
      }
      
    } catch (error) {
      console.error('[Auth] Verification error:', error);
      errorMsg.textContent = error.message || 'Verification failed. Please try again.';
      errorMsg.style.display = 'block';
      btn.disabled = false;
      btn.classList.remove('loading');
    }
  }
}

// Handle OTP request for password reset
async function handleRequestOtp(e) {
  e.preventDefault();
  
  const email = document.getElementById('email').value;
  const btn = document.getElementById('requestOtpBtn');
  const errorMsg = document.getElementById('requestError');
  
  errorMsg.style.display = 'none';
  btn.disabled = true;
  btn.classList.add('loading');
  
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: chrome.runtime.getURL('auth/reset-password.html')
    });
    
    if (error) throw error;
    
    // Show OTP form
    document.getElementById('requestOtpForm').style.display = 'none';
    document.getElementById('resetPasswordForm').style.display = 'block';
    document.getElementById('loginLinkContainer').style.display = 'none';
    document.getElementById('backBtnContainer').style.display = 'block';
    
    // Store email for later use
    window.resetEmail = email;
    
  } catch (error) {
    errorMsg.textContent = error.message || 'Failed to send verification code.';
    errorMsg.style.display = 'block';
    btn.disabled = false;
    btn.classList.remove('loading');
  }
}

// Handle password reset with OTP
async function handleResetPasswordWithOtp(e) {
  e.preventDefault();
  
  const email = window.resetEmail;
  const otp = document.getElementById('otp').value;
  const newPassword = document.getElementById('newPassword').value;
  const confirmPassword = document.getElementById('confirmPassword').value;
  const btn = document.getElementById('resetPasswordBtn');
  const errorMsg = document.getElementById('resetError');
  const successMsg = document.getElementById('resetSuccess');
  
  errorMsg.style.display = 'none';
  successMsg.style.display = 'none';
  
  // Validate passwords match
  if (newPassword !== confirmPassword) {
    errorMsg.textContent = 'Passwords do not match';
    errorMsg.style.display = 'block';
    return;
  }
  
  btn.disabled = true;
  btn.classList.add('loading');
  
  try {
    // Verify OTP and update password
    const { error } = await supabase.auth.verifyOtp({
      email,
      token: otp,
      type: 'recovery'
    });
    
    if (error) throw error;
    
    // Update password
    const { error: updateError } = await supabase.auth.updateUser({
      password: newPassword
    });
    
    if (updateError) throw updateError;
    
    successMsg.textContent = 'Password updated successfully! Redirecting...';
    successMsg.style.display = 'block';
    
    setTimeout(() => {
      window.location.href = 'login.html';
    }, 2000);
    
  } catch (error) {
    errorMsg.textContent = error.message || 'Invalid verification code or failed to update password.';
    errorMsg.style.display = 'block';
    btn.disabled = false;
    btn.classList.remove('loading');
  }
}

// Handle update password page
async function handleUpdatePasswordPage() {
  const form = document.getElementById('updatePasswordForm');
  const errorMsg = document.getElementById('errorMessage');
  const successMsg = document.getElementById('successMessage');
  
  // Check if we have access token in URL hash
  const hashParams = new URLSearchParams(window.location.hash.substring(1));
  const accessToken = hashParams.get('access_token');
  
  if (!accessToken) {
    errorMsg.textContent = 'Invalid or expired reset link. Please request a new one.';
    errorMsg.style.display = 'block';
    form.querySelector('button').disabled = true;
    return;
  }
  
  // Set session from URL
  try {
    const { error } = await supabase.auth.setSession({
      access_token: accessToken,
      refresh_token: hashParams.get('refresh_token')
    });
    
    if (error) throw error;
  } catch (error) {
    errorMsg.textContent = 'Failed to verify reset link. Please try again.';
    errorMsg.style.display = 'block';
    form.querySelector('button').disabled = true;
    return;
  }
  
  // Handle form submission
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const btn = document.getElementById('updateBtn');
    
    // Clear messages
    errorMsg.style.display = 'none';
    successMsg.style.display = 'none';
    
    // Validate passwords match
    if (newPassword !== confirmPassword) {
      errorMsg.textContent = 'Passwords do not match';
      errorMsg.style.display = 'block';
      return;
    }
    
    // Show loading
    btn.disabled = true;
    btn.classList.add('loading');
    
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });
      
      if (error) throw error;
      
      successMsg.textContent = 'Password updated successfully! Redirecting...';
      successMsg.style.display = 'block';
      
      // Close tab after 2 seconds
      setTimeout(() => {
        window.close();
      }, 2000);
      
    } catch (error) {
      errorMsg.textContent = error.message || 'Failed to update password.';
      errorMsg.style.display = 'block';
      btn.disabled = false;
      btn.classList.remove('loading');
    }
  });
}

// Save user session to chrome storage
async function saveUserSession(session) {
  return new Promise((resolve) => {
    chrome.storage.local.set({
      lingolette_user_session: session,
      lingolette_user_id: session.user.id,
      lingolette_user_email: session.user.email
    }, resolve);
  });
}

// Get current user session
async function getUserSession() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['lingolette_user_session'], (result) => {
      resolve(result.lingolette_user_session || null);
    });
  });
}

// Refresh expired session
async function refreshSession(oldSession) {
  if (!oldSession || !oldSession.refresh_token) {
    return false;
  }
  
  try {
    const { data, error } = await supabase.auth.refreshSession({
      refresh_token: oldSession.refresh_token
    });
    
    if (error) throw error;
    
    if (data.session) {
      await saveUserSession(data.session);
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('[Auth] Failed to refresh session:', error);
    return false;
  }
}

// Logout
async function logout() {
  await supabase.auth.signOut();
  await new Promise((resolve) => {
    chrome.storage.local.remove([
      'lingolette_user_session',
      'lingolette_user_id',
      'lingolette_user_email'
    ], resolve);
  });
  window.location.href = 'auth/login.html';
}

// Handle resend OTP for signup
async function handleResendOtp() {
  const btn = document.getElementById('resendOtpBtn');
  const errorMsg = document.getElementById('errorMessage');
  
  if (!tempSignupData) return;
  
  btn.disabled = true;
  btn.textContent = 'Sending...';
  
  try {
    // Resend confirmation email by calling signUp again
    const { error } = await supabase.auth.resend({
      type: 'signup',
      email: tempSignupData.email
    });
    
    if (error) throw error;
    
    // Show success message
    errorMsg.textContent = 'Verification code resent!';
    errorMsg.className = 'success-message';
    errorMsg.style.display = 'block';
    
    setTimeout(() => {
      errorMsg.style.display = 'none';
      errorMsg.className = 'error-message';
    }, 3000);
    
    // Restart countdown
    startResendCountdown();
    
    
  } catch (error) {
    errorMsg.textContent = error.message || 'Failed to resend code';
    errorMsg.style.display = 'block';
    btn.disabled = false;
    btn.textContent = 'Resend';
  }
}

// Start countdown for resend button
function startResendCountdown() {
  const btn = document.getElementById('resendOtpBtn');
  btn.disabled = true;
  resendCountdown = 60;
  
  if (resendTimer) clearInterval(resendTimer);
  
  resendTimer = setInterval(() => {
    resendCountdown--;
    btn.textContent = `Resend (${resendCountdown}s)`;
    
    if (resendCountdown <= 0) {
      clearInterval(resendTimer);
      btn.disabled = false;
      btn.textContent = 'Resend';
    }
  }, 1000);
}

// Create user profile in database
async function createUserProfile(userId) {
  try {
    // Check if profile already exists
    const { data: existingProfile } = await supabase
      .from('user_profiles')
      .select('id')
      .eq('id', userId)
      .single();
    
    if (existingProfile) {
      return;
    }
    
    // Create new profile
    const { error } = await supabase
      .from('user_profiles')
      .insert({
        id: userId,
        subscription_tier: 'free',
        monthly_ai_quota: 30,
        monthly_ai_used: 0,
        learning_mode: 'standard',
        learning_categories: ['collocation', 'idiom', 'connector'],
        site_preferences: {},
        collection_highlight: false
      });
    
    if (error) {
      console.error('[Auth] Failed to create profile:', error);
    } else {
    }
  } catch (error) {
    console.error('[Auth] Error creating profile:', error);
  }
}

// Setup password visibility toggle
function setupPasswordToggle() {
  const toggleButtons = document.querySelectorAll('.toggle-password');
  
  toggleButtons.forEach(button => {
    button.addEventListener('click', () => {
      const targetId = button.getAttribute('data-target');
      const input = document.getElementById(targetId);
      const eyeIcon = button.querySelector('.eye-icon');
      const eyeOffIcon = button.querySelector('.eye-off-icon');
      
      if (input.type === 'password') {
        input.type = 'text';
        eyeIcon.style.display = 'none';
        eyeOffIcon.style.display = 'block';
      } else {
        input.type = 'password';
        eyeIcon.style.display = 'block';
        eyeOffIcon.style.display = 'none';
      }
    });
  });
}
